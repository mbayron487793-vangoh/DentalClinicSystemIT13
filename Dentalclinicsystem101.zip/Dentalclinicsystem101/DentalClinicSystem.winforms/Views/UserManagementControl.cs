using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class UserManagementControl : UserControl
    {
        private DataGridView gridUsers = null!;
        private TextBox txtSearch = null!;
        private ComboBox cmbRoleFilter = null!;

        public UserManagementControl()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "User Management & System Access Control",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Manage practice accounts, role assignments (SuperAdmin, Admin, Staff, Dentist, Tenants), and security permissions",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(180, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadUsers();

            var lblRole = new Label { Text = "Role:", Location = new Point(260, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbRoleFilter = new ComboBox { Location = new Point(305, 11), Size = new Size(130, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbRoleFilter.Items.AddRange(new object[] { "All Roles", "SuperAdmin", "Admin", "Staff", "Dentist", "TenantA", "TenantB", "TenantC" });
            cmbRoleFilter.SelectedIndex = 0;
            cmbRoleFilter.SelectedIndexChanged += (s, e) => LoadUsers();

            var btnAdd = new Button
            {
                Text = "+ Add New User",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(450, 9),
                Size = new Size(130, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowUserDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit User",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(590, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedUser();

            var btnToggle = new Button
            {
                Text = "Toggle Status",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(710, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnToggle.FlatAppearance.BorderSize = 0;
            btnToggle.Click += (s, e) => ToggleSelectedUserStatus();

            var btnDelete = new Button
            {
                Text = "Delete User",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(840, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedUser();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblRole, cmbRoleFilter, btnAdd, btnEdit, btnToggle, btnDelete });

            gridUsers = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridUsers.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridUsers.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridUsers.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridUsers.EnableHeadersVisualStyles = false;
            gridUsers.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridUsers.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridUsers });
        }

        private void LoadUsers()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();
                string roleFilter = cmbRoleFilter.SelectedItem?.ToString() ?? "All Roles";

                var query = db.Users.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(u => u.FullName.ToLower().Contains(search) || u.Email.ToLower().Contains(search) || (u.PhoneNumber != null && u.PhoneNumber.Contains(search)));
                }

                if (roleFilter != "All Roles")
                {
                    query = query.Where(u => u.RoleName == roleFilter);
                }

                var list = query
                    .OrderBy(u => u.RoleName)
                    .ThenBy(u => u.FullName)
                    .Select(u => new
                    {
                        Id = u.Id,
                        FullName = u.FullName,
                        Email = u.Email,
                        Role = u.RoleName,
                        Phone = u.PhoneNumber ?? "-",
                        Specialization = u.Specialization ?? "General Dentistry",
                        License = u.LicenseNumber ?? "-",
                        Status = u.IsActive ? "Active" : "Inactive"
                    })
                    .ToList();

                gridUsers.DataSource = list;
                if (gridUsers.Columns["Id"] != null) gridUsers.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowUserDialog(ApplicationUser? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New System User" : $"Edit User: {existing?.FullName}",
                Size = new Size(460, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblName = new Label { Text = "Full Name:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtName = new TextBox { Location = new Point(20, 35), Size = new Size(400, 26), Text = existing?.FullName ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblEmail = new Label { Text = "Email Address (Login Username):", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtEmail = new TextBox { Location = new Point(20, 90), Size = new Size(400, 26), Text = existing?.Email ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblRole = new Label { Text = "System Access Role:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbRole = new ComboBox { Location = new Point(20, 145), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbRole.Items.AddRange(new object[] { "SuperAdmin", "Admin", "Staff", "Dentist", "TenantA", "TenantB", "TenantC" });
            cmbRole.SelectedItem = existing?.RoleName ?? "Staff";

            var lblPhone = new Label { Text = "Contact Phone Number:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 200), Size = new Size(400, 26), Text = existing?.PhoneNumber ?? "+1 (555) 010-0010", Font = new Font("Segoe UI", 9.5F) };

            var lblSpec = new Label { Text = "Specialization / Department:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtSpec = new TextBox { Location = new Point(20, 255), Size = new Size(400, 26), Text = existing?.Specialization ?? "General Dentistry", Font = new Font("Segoe UI", 9.5F) };

            var lblLic = new Label { Text = "Professional License Number:", Location = new Point(20, 290), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtLic = new TextBox { Location = new Point(20, 310), Size = new Size(400, 26), Text = existing?.LicenseNumber ?? "LIC-NY-99201", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Create User Account" : "Save Changes",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 365),
                Size = new Size(400, 42),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblName, txtName, lblEmail, txtEmail, lblRole, cmbRole, lblPhone, txtPhone, lblSpec, txtSpec, lblLic, txtLic, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                using var db = DbContextFactory.Create();
                if (isNew)
                {
                    var u = new ApplicationUser
                    {
                        UserName = txtEmail.Text.Trim(),
                        Email = txtEmail.Text.Trim(),
                        FullName = txtName.Text.Trim(),
                        RoleName = cmbRole.SelectedItem?.ToString() ?? "Staff",
                        PhoneNumber = txtPhone.Text.Trim(),
                        Specialization = txtSpec.Text.Trim(),
                        LicenseNumber = txtLic.Text.Trim(),
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow
                    };
                    db.Users.Add(u);
                }
                else
                {
                    var u = db.Users.FirstOrDefault(x => x.Id == existing!.Id);
                    if (u != null)
                    {
                        u.FullName = txtName.Text.Trim();
                        u.Email = txtEmail.Text.Trim();
                        u.UserName = txtEmail.Text.Trim();
                        u.RoleName = cmbRole.SelectedItem?.ToString() ?? "Staff";
                        u.PhoneNumber = txtPhone.Text.Trim();
                        u.Specialization = txtSpec.Text.Trim();
                        u.LicenseNumber = txtLic.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadUsers();
            }
        }

        private void EditSelectedUser()
        {
            if (gridUsers.SelectedRows.Count == 0 || gridUsers.SelectedRows[0].Cells["Id"].Value == null) return;
            string id = gridUsers.SelectedRows[0].Cells["Id"].Value.ToString()!;

            using var db = DbContextFactory.Create();
            var u = db.Users.FirstOrDefault(x => x.Id == id);
            if (u != null)
            {
                ShowUserDialog(u);
            }
        }

        private void ToggleSelectedUserStatus()
        {
            if (gridUsers.SelectedRows.Count == 0 || gridUsers.SelectedRows[0].Cells["Id"].Value == null) return;
            string id = gridUsers.SelectedRows[0].Cells["Id"].Value.ToString()!;

            using var db = DbContextFactory.Create();
            var u = db.Users.FirstOrDefault(x => x.Id == id);
            if (u != null)
            {
                u.IsActive = !u.IsActive;
                db.SaveChanges();
                LoadUsers();
                MessageBox.Show($"User {u.FullName} status set to: {(u.IsActive ? "Active" : "Inactive")}", "Status Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSelectedUser()
        {
            if (gridUsers.SelectedRows.Count == 0 || gridUsers.SelectedRows[0].Cells["Id"].Value == null) return;
            string id = gridUsers.SelectedRows[0].Cells["Id"].Value.ToString()!;

            if (MessageBox.Show("Are you sure you want to delete this user account?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var u = db.Users.FirstOrDefault(x => x.Id == id);
                if (u != null)
                {
                    db.Users.Remove(u);
                    db.SaveChanges();
                    LoadUsers();
                }
            }
        }
    }
}
