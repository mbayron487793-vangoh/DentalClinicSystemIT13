using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class ActionsControl : UserControl
    {
        private DataGridView gridActions = null!;
        private ComboBox cmbStatusFilter = null!;
        private ComboBox cmbPriorityFilter = null!;

        public ActionsControl()
        {
            InitializeComponent();
            LoadActions();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Operational Actions & Clinical Workflow Dashboard",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "High-priority practice directives, clinical approvals, emergency protocols, and treatment task dispatches",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblStatus = new Label { Text = "Status:", Location = new Point(12, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbStatusFilter = new ComboBox { Location = new Point(65, 11), Size = new Size(120, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbStatusFilter.Items.AddRange(new object[] { "All Statuses", "Pending", "In Progress", "Approved", "Completed" });
            cmbStatusFilter.SelectedIndex = 0;
            cmbStatusFilter.SelectedIndexChanged += (s, e) => LoadActions();

            var lblPri = new Label { Text = "Priority:", Location = new Point(195, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbPriorityFilter = new ComboBox { Location = new Point(250, 11), Size = new Size(110, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbPriorityFilter.Items.AddRange(new object[] { "All", "Urgent", "High", "Normal" });
            cmbPriorityFilter.SelectedIndex = 0;
            cmbPriorityFilter.SelectedIndexChanged += (s, e) => LoadActions();

            var btnAdd = new Button
            {
                Text = "+ Log Action Directive",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(375, 9),
                Size = new Size(160, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowActionDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Action",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(545, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedAction();

            var btnApprove = new Button
            {
                Text = "Approve / Advance",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(665, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnApprove.FlatAppearance.BorderSize = 0;
            btnApprove.Click += (s, e) => AdvanceSelectedActionStatus();

            var btnDelete = new Button
            {
                Text = "Delete Action",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(825, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedAction();

            filterPanel.Controls.AddRange(new Control[] { lblStatus, cmbStatusFilter, lblPri, cmbPriorityFilter, btnAdd, btnEdit, btnApprove, btnDelete });

            // Data Grid
            gridActions = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridActions.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridActions.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridActions.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridActions.EnableHeadersVisualStyles = false;
            gridActions.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridActions.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridActions });
        }

        private void LoadActions()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string statusFilter = cmbStatusFilter.SelectedItem?.ToString() ?? "All Statuses";
                string priorityFilter = cmbPriorityFilter.SelectedItem?.ToString() ?? "All";

                var query = db.SystemActions.AsQueryable();
                if (statusFilter != "All Statuses")
                {
                    query = query.Where(a => a.Status == statusFilter);
                }
                if (priorityFilter != "All")
                {
                    query = query.Where(a => a.Priority == priorityFilter);
                }

                var list = query
                    .OrderByDescending(a => a.Priority == "Urgent")
                    .ThenBy(a => a.DueDate)
                    .Select(a => new
                    {
                        Id = a.Id,
                        Title = a.ActionTitle,
                        Category = a.ActionCategory,
                        Priority = a.Priority,
                        Status = a.Status,
                        AssignedTo = a.AssignedTo,
                        RequestedBy = a.RequestedBy,
                        DueDate = a.DueDate.ToString("yyyy-MM-dd"),
                        Description = a.Description
                    })
                    .ToList();

                gridActions.DataSource = list;
                if (gridActions.Columns["Id"] != null) gridActions.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowActionDialog(SystemAction? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Create Clinical Action Directive" : $"Edit Action: {existing?.ActionTitle}",
                Size = new Size(480, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblTitle = new Label { Text = "Action Title / Directive:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtTitle = new TextBox { Location = new Point(20, 35), Size = new Size(420, 26), Text = existing?.ActionTitle ?? "Sterilization & Autoclave Quality Audit", Font = new Font("Segoe UI", 9.5F) };

            var lblCat = new Label { Text = "Category:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbCat = new ComboBox { Location = new Point(20, 90), Size = new Size(200, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbCat.Items.AddRange(new object[] { "Clinical Task", "Workflow Approval", "Emergency Protocol", "Inventory Request", "Patient Care Followup" });
            cmbCat.SelectedItem = existing?.ActionCategory ?? "Clinical Task";

            var lblPri = new Label { Text = "Priority Level:", Location = new Point(240, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbPri = new ComboBox { Location = new Point(240, 90), Size = new Size(200, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbPri.Items.AddRange(new object[] { "Urgent", "High", "Normal", "Low" });
            cmbPri.SelectedItem = existing?.Priority ?? "Normal";

            var lblAssigned = new Label { Text = "Assignee / Lead Practitioner:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtAssigned = new TextBox { Location = new Point(20, 145), Size = new Size(420, 26), Text = existing?.AssignedTo ?? "Dr. Alexander Smith, DDS", Font = new Font("Segoe UI", 9.5F) };

            var lblReq = new Label { Text = "Requested By:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtReq = new TextBox { Location = new Point(20, 200), Size = new Size(420, 26), Text = existing?.RequestedBy ?? (Session.CurrentUser?.FullName ?? "Practice Director"), Font = new Font("Segoe UI", 9.5F) };

            var lblDesc = new Label { Text = "Action Description & Scope:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDesc = new TextBox { Location = new Point(20, 255), Size = new Size(420, 80), Multiline = true, Text = existing?.Description ?? "Perform biological indicator spore testing on all surgical autoclaves and log compliance.", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Save Action Directive" : "Update Directive",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 360),
                Size = new Size(420, 40),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblTitle, txtTitle, lblCat, cmbCat, lblPri, cmbPri, lblAssigned, txtAssigned, lblReq, txtReq, lblDesc, txtDesc, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                using var db = DbContextFactory.Create();
                if (isNew)
                {
                    db.SystemActions.Add(new SystemAction
                    {
                        ActionTitle = txtTitle.Text.Trim(),
                        ActionCategory = cmbCat.SelectedItem?.ToString() ?? "Clinical Task",
                        Priority = cmbPri.SelectedItem?.ToString() ?? "Normal",
                        AssignedTo = txtAssigned.Text.Trim(),
                        RequestedBy = txtReq.Text.Trim(),
                        Description = txtDesc.Text.Trim(),
                        Status = "Pending",
                        DueDate = DateTime.UtcNow.AddDays(3),
                        CreatedAt = DateTime.UtcNow
                    });
                }
                else
                {
                    var a = db.SystemActions.FirstOrDefault(x => x.Id == existing!.Id);
                    if (a != null)
                    {
                        a.ActionTitle = txtTitle.Text.Trim();
                        a.ActionCategory = cmbCat.SelectedItem?.ToString() ?? "Clinical Task";
                        a.Priority = cmbPri.SelectedItem?.ToString() ?? "Normal";
                        a.AssignedTo = txtAssigned.Text.Trim();
                        a.RequestedBy = txtReq.Text.Trim();
                        a.Description = txtDesc.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadActions();
            }
        }

        private void EditSelectedAction()
        {
            if (gridActions.SelectedRows.Count == 0 || gridActions.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridActions.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var a = db.SystemActions.FirstOrDefault(x => x.Id == id);
            if (a != null)
            {
                ShowActionDialog(a);
            }
        }

        private void AdvanceSelectedActionStatus()
        {
            if (gridActions.SelectedRows.Count == 0 || gridActions.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridActions.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var a = db.SystemActions.FirstOrDefault(x => x.Id == id);
            if (a != null)
            {
                if (a.Status == "Pending") a.Status = "In Progress";
                else if (a.Status == "In Progress") a.Status = "Approved";
                else if (a.Status == "Approved") a.Status = "Completed";
                else a.Status = "Completed";

                db.SaveChanges();
                LoadActions();
                MessageBox.Show($"Action status updated to '{a.Status}'!", "Workflow Advanced", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSelectedAction()
        {
            if (gridActions.SelectedRows.Count == 0 || gridActions.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridActions.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this action item?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var a = db.SystemActions.FirstOrDefault(x => x.Id == id);
                if (a != null)
                {
                    db.SystemActions.Remove(a);
                    db.SaveChanges();
                    LoadActions();
                }
            }
        }
    }
}
