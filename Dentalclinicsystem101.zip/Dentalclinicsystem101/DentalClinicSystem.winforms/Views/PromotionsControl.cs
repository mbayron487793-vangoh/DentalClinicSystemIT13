using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class PromotionsControl : UserControl
    {
        private DataGridView gridPromos = null!;
        private TextBox txtSearch = null!;

        public PromotionsControl()
        {
            InitializeComponent();
            LoadPromotions();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Manage Clinical Promotions & Discount Subsidies",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Special promotional campaigns, percentage discounts, seasonal incentives, and patient fee subsidies",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(200, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadPromotions();

            var btnAdd = new Button
            {
                Text = "+ Add Promotion",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(280, 9),
                Size = new Size(140, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowPromotionDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Promotion",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(430, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedPromotion();

            var btnToggle = new Button
            {
                Text = "Toggle Active",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(560, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnToggle.FlatAppearance.BorderSize = 0;
            btnToggle.Click += (s, e) => ToggleSelectedPromotion();

            var btnDelete = new Button
            {
                Text = "Delete Promo",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(680, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedPromotion();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, btnAdd, btnEdit, btnToggle, btnDelete });

            gridPromos = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridPromos.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridPromos.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridPromos.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridPromos.EnableHeadersVisualStyles = false;
            gridPromos.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridPromos.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridPromos });
        }

        private void LoadPromotions()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();

                var query = db.Promotions.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(p => p.Title.ToLower().Contains(search) || p.PromoCode.ToLower().Contains(search));
                }

                var list = query
                    .OrderByDescending(p => p.IsActive)
                    .ThenBy(p => p.PromoCode)
                    .Select(p => new
                    {
                        Id = p.Id,
                        Code = p.PromoCode,
                        Title = p.Title,
                        Discount = p.DiscountType == DiscountType.Percentage ? $"{p.DiscountValue}%" : $"₱{p.DiscountValue:N2}",
                        MinSpend = $"₱{p.MinSpend:N2}",
                        ValidRange = $"{p.StartDate:yyyy-MM-dd} to {p.EndDate:yyyy-MM-dd}",
                        Description = p.Description,
                        Status = p.IsActive ? "Active" : "Expired"
                    })
                    .ToList();

                gridPromos.DataSource = list;
                if (gridPromos.Columns["Id"] != null) gridPromos.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowPromotionDialog(Promotion? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New Clinical Promotion" : $"Edit Promotion: {existing?.PromoCode}",
                Size = new Size(460, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblCode = new Label { Text = "Promo Code:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCode = new TextBox { Location = new Point(20, 35), Size = new Size(400, 26), Text = existing?.PromoCode ?? "SUMMER20", Font = new Font("Segoe UI", 9.5F) };

            var lblTitle = new Label { Text = "Campaign Title:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtTitle = new TextBox { Location = new Point(20, 90), Size = new Size(400, 26), Text = existing?.Title ?? "20% Seasonal Smiles Discount", Font = new Font("Segoe UI", 9.5F) };

            var lblType = new Label { Text = "Discount Type:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbType = new ComboBox { Location = new Point(20, 145), Size = new Size(190, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbType.Items.AddRange(new object[] { "Percentage", "FixedAmount" });
            cmbType.SelectedItem = existing != null ? existing.DiscountType.ToString() : "Percentage";

            var lblVal = new Label { Text = "Discount Value (% or ₱):", Location = new Point(230, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtVal = new TextBox { Location = new Point(230, 145), Size = new Size(190, 26), Text = existing != null ? existing.DiscountValue.ToString() : "20", Font = new Font("Segoe UI", 9.5F) };

            var lblSpend = new Label { Text = "Minimum Spend (₱):", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtSpend = new TextBox { Location = new Point(20, 200), Size = new Size(400, 26), Text = existing != null ? existing.MinSpend.ToString("N2") : "100.00", Font = new Font("Segoe UI", 9.5F) };

            var lblDesc = new Label { Text = "Promotion Details & Terms:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDesc = new TextBox { Location = new Point(20, 255), Size = new Size(400, 70), Multiline = true, Text = existing?.Description ?? "Applicable to standard clinical preventative treatments." };

            var btnSave = new Button
            {
                Text = isNew ? "Create Promotion" : "Save Changes",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 350),
                Size = new Size(400, 42),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblCode, txtCode, lblTitle, txtTitle, lblType, cmbType, lblVal, txtVal, lblSpend, txtSpend, lblDesc, txtDesc, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtCode.Text))
            {
                decimal.TryParse(txtVal.Text, out decimal val);
                decimal.TryParse(txtSpend.Text, out decimal minSpend);
                Enum.TryParse<DiscountType>(cmbType.SelectedItem?.ToString() ?? "Percentage", out var dType);

                using var db = DbContextFactory.Create();
                if (isNew)
                {
                    db.Promotions.Add(new Promotion
                    {
                        PromoCode = txtCode.Text.Trim().ToUpper(),
                        Title = txtTitle.Text.Trim(),
                        DiscountType = dType,
                        DiscountValue = val,
                        MinSpend = minSpend,
                        StartDate = DateTime.UtcNow.AddMonths(-1),
                        EndDate = DateTime.UtcNow.AddMonths(6),
                        Description = txtDesc.Text.Trim(),
                        IsActive = true
                    });
                }
                else
                {
                    var p = db.Promotions.FirstOrDefault(x => x.Id == existing!.Id);
                    if (p != null)
                    {
                        p.PromoCode = txtCode.Text.Trim().ToUpper();
                        p.Title = txtTitle.Text.Trim();
                        p.DiscountType = dType;
                        p.DiscountValue = val;
                        p.MinSpend = minSpend;
                        p.Description = txtDesc.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadPromotions();
            }
        }

        private void EditSelectedPromotion()
        {
            if (gridPromos.SelectedRows.Count == 0 || gridPromos.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridPromos.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var p = db.Promotions.FirstOrDefault(x => x.Id == id);
            if (p != null)
            {
                ShowPromotionDialog(p);
            }
        }

        private void ToggleSelectedPromotion()
        {
            if (gridPromos.SelectedRows.Count == 0 || gridPromos.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridPromos.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var p = db.Promotions.FirstOrDefault(x => x.Id == id);
            if (p != null)
            {
                p.IsActive = !p.IsActive;
                db.SaveChanges();
                LoadPromotions();
                MessageBox.Show($"Promotion {p.PromoCode} is now {(p.IsActive ? "Active" : "Expired")}.", "Status Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSelectedPromotion()
        {
            if (gridPromos.SelectedRows.Count == 0 || gridPromos.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridPromos.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this promotional campaign?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var p = db.Promotions.FirstOrDefault(x => x.Id == id);
                if (p != null)
                {
                    db.Promotions.Remove(p);
                    db.SaveChanges();
                    LoadPromotions();
                }
            }
        }
    }
}
