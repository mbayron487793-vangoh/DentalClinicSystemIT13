using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.AspNetCore.Identity;

namespace DentalClinicWinForms.Views
{
    public class TenantsControl : UserControl
    {
        private DataGridView gridTenants = null!;
        private TextBox txtSearch = null!;

        public TenantsControl()
        {
            InitializeComponent();
            LoadTenants();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Tenants Management & Client Accounts",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Manage practice tenants (Tenant A, Tenant B, Tenant C), client contact info, and communication channels (Phone & Email)",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search Tenant:", Location = new Point(12, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(120, 11), Size = new Size(200, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadTenants();

            var btnAdd = new Button
            {
                Text = "+ Add New Tenant",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(335, 9),
                Size = new Size(140, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => { if (ShowAddTenantDialog(this.FindForm())) LoadTenants(); };

            var btnEdit = new Button
            {
                Text = "Edit Tenant",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(485, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedTenant();

            var btnInform = new Button
            {
                Text = "Inform Tenant (Phone / Email)",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(605, 9),
                Size = new Size(220, 30),
                Cursor = Cursors.Hand
            };
            btnInform.FlatAppearance.BorderSize = 0;
            btnInform.Click += (s, e) => InformSelectedTenant();

            var btnDelete = new Button
            {
                Text = "Delete Tenant",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(835, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedTenant();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, btnAdd, btnEdit, btnInform, btnDelete });

            // Data Grid
            gridTenants = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridTenants.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridTenants.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridTenants.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridTenants.EnableHeadersVisualStyles = false;
            gridTenants.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridTenants.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridTenants });
        }

        private void LoadTenants()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();

                var list = db.Tenants
                    .Where(t => string.IsNullOrEmpty(search) ||
                                t.TenantName.ToLower().Contains(search) ||
                                t.TenantCode.ToLower().Contains(search) ||
                                t.SubscriptionTier.ToLower().Contains(search) ||
                                t.ContactEmail.ToLower().Contains(search))
                    .OrderBy(t => t.TenantCode)
                    .Select(t => new
                    {
                        Id = t.Id,
                        Code = t.TenantCode,
                        Name = t.TenantName,
                        Tier = t.SubscriptionTier,
                        Email = t.ContactEmail,
                        Phone = t.ContactPhone,
                        Branches = t.BranchesCount,
                        Status = t.Status,
                        Address = t.Address
                    })
                    .ToList();

                gridTenants.DataSource = list;
                if (gridTenants.Columns["Id"] != null) gridTenants.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private static string RoleForTier(string tier) => tier switch
        {
            "Tenant B" => "TenantB",
            "Tenant C" => "TenantC",
            _ => "TenantA"
        };

        /// <summary>
        /// Opens the "Add New Tenant" dialog. Creates the tenant record, its subscription and
        /// the tenant's admin login account. Returns true when a tenant was created.
        /// </summary>
        public static bool ShowAddTenantDialog(IWin32Window? owner)
        {
            using var dlg = new Form
            {
                Text = "Add New Tenant",
                Size = new Size(460, 540),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            int y = 15;
            TextBox AddText(string label, string value, bool password = false)
            {
                dlg.Controls.Add(new Label { Text = label, Location = new Point(20, y), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) });
                var tb = new TextBox { Location = new Point(20, y + 20), Size = new Size(400, 26), Text = value, Font = new Font("Segoe UI", 9.5F), UseSystemPasswordChar = password };
                dlg.Controls.Add(tb);
                y += 55;
                return tb;
            }

            var txtCode = AddText("Tenant Code:", $"TNT-{new Random().Next(1000, 9999)}");
            var txtName = AddText("Tenant / Clinic Name:", "");

            dlg.Controls.Add(new Label { Text = "Subscription Tier:", Location = new Point(20, y), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) });
            var cmbTier = new ComboBox { Location = new Point(20, y + 20), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbTier.Items.AddRange(new object[] { "Tenant A", "Tenant B", "Tenant C" });
            cmbTier.SelectedIndex = 0;
            dlg.Controls.Add(cmbTier);
            y += 55;

            var txtEmail = AddText("Contact Email (also the tenant admin login):", "");
            var txtPhone = AddText("Contact Phone Number:", "");
            var txtAddress = AddText("Clinic Address:", "");
            var txtPassword = AddText("Tenant Admin Password (min 6 characters):", "Tenant@123456", password: true);

            var lblError = new Label { Location = new Point(20, y - 5), Size = new Size(400, 36), ForeColor = Color.FromArgb(185, 28, 28), Font = new Font("Segoe UI", 8.5F) };
            dlg.Controls.Add(lblError);

            var btnSave = new Button
            {
                Text = "Create Tenant",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, y + 35),
                Size = new Size(400, 40)
            };
            btnSave.FlatAppearance.BorderSize = 0;
            dlg.Controls.Add(btnSave);

            bool created = false;
            btnSave.Click += (s, e) =>
            {
                string code = txtCode.Text.Trim();
                string name = txtName.Text.Trim();
                string email = txtEmail.Text.Trim();
                string phone = txtPhone.Text.Trim();
                string tier = cmbTier.SelectedItem?.ToString() ?? "Tenant A";

                if (code.Length == 0 || name.Length == 0 || email.Length == 0 || phone.Length == 0)
                {
                    lblError.Text = "Tenant code, name, email and phone are required.";
                    return;
                }
                if (!email.Contains('@'))
                {
                    lblError.Text = "Please enter a valid email address.";
                    return;
                }
                if (txtPassword.Text.Length < 6)
                {
                    lblError.Text = "Password must be at least 6 characters.";
                    return;
                }

                try
                {
                    using var db = DbContextFactory.Create();
                    if (db.Tenants.Any(t => t.TenantCode == code))
                    {
                        lblError.Text = $"Tenant code '{code}' already exists.";
                        return;
                    }
                    string normEmail = email.ToUpperInvariant();
                    if (db.Users.Any(u => u.NormalizedEmail == normEmail || u.NormalizedUserName == normEmail))
                    {
                        lblError.Text = $"An account with email '{email}' already exists.";
                        return;
                    }

                    string role = RoleForTier(tier);
                    decimal price = tier switch { "Tenant B" => 8999m, "Tenant C" => 14999m, _ => 4999m };
                    string plan = tier switch
                    {
                        "Tenant B" => "Tenant B: Business Intelligence & Actions",
                        "Tenant C" => "Tenant C: Enterprise Multi-Branching & BI",
                        _ => "Tenant A: Core Transactions & Clinical Data"
                    };
                    string modules = tier switch
                    {
                        "Tenant B" => "Dashboard, Business Intelligence, Actions",
                        "Tenant C" => "Dashboard, Branching, Business Intelligence, Actions",
                        _ => "Dashboard, Main transaction, Data Collection"
                    };

                    db.Tenants.Add(new Tenant
                    {
                        TenantCode = code,
                        TenantName = name,
                        SubscriptionTier = tier,
                        ContactEmail = email,
                        ContactPhone = phone,
                        Address = txtAddress.Text.Trim(),
                        Status = "Active",
                        BranchesCount = tier == "Tenant C" ? 3 : 1,
                        CreatedAt = DateTime.UtcNow
                    });

                    db.Subscriptions.Add(new TenantSubscription
                    {
                        TenantName = name,
                        SubscriptionTier = tier,
                        PlanName = plan,
                        MonthlyPrice = price,
                        BillingCycle = "Monthly",
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow.AddYears(1),
                        Status = "Active",
                        ContactEmail = email,
                        ContactPhone = phone,
                        AllowedModulesSummary = modules
                    });

                    var user = new ApplicationUser
                    {
                        Id = Guid.NewGuid().ToString(),
                        UserName = email,
                        NormalizedUserName = normEmail,
                        Email = email,
                        NormalizedEmail = normEmail,
                        EmailConfirmed = true,
                        PhoneNumber = phone,
                        FullName = name,
                        RoleName = role,
                        IsActive = true,
                        SecurityStamp = Guid.NewGuid().ToString(),
                        ConcurrencyStamp = Guid.NewGuid().ToString()
                    };
                    user.PasswordHash = new PasswordHasher<ApplicationUser>().HashPassword(user, txtPassword.Text);
                    db.Users.Add(user);

                    var roleEntity = db.Roles.FirstOrDefault(r => r.Name == role);
                    if (roleEntity != null)
                        db.UserRoles.Add(new IdentityUserRole<string> { UserId = user.Id, RoleId = roleEntity.Id });

                    db.AuditLogs.Add(new AuditLog
                    {
                        UserName = Session.CurrentUser?.Email ?? "superadmin@dentalclinic.com",
                        Module = "Tenants",
                        Action = "TenantCreated",
                        Details = $"Created tenant {name} ({code}) on {tier}; admin login {email}",
                        Timestamp = DateTime.UtcNow
                    });

                    db.SaveChanges();
                    created = true;
                    MessageBox.Show($"Tenant '{name}' created.\n\nAdmin login: {email}\nTier: {tier}",
                        "Tenant Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dlg.DialogResult = DialogResult.OK;
                    dlg.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = "Could not create tenant: " + ex.Message;
                }
            };

            dlg.ShowDialog(owner);
            return created;
        }

        private void ShowTenantDialog(Tenant? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New Clinic Tenant" : $"Edit Tenant: {existing?.TenantName}",
                Size = new Size(460, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblCode = new Label { Text = "Tenant Code:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCode = new TextBox { Location = new Point(20, 35), Size = new Size(400, 26), Text = existing?.TenantCode ?? $"TNT-{new Random().Next(100, 999)}", Font = new Font("Segoe UI", 9.5F) };

            var lblName = new Label { Text = "Tenant Organization Name:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtName = new TextBox { Location = new Point(20, 90), Size = new Size(400, 26), Text = existing?.TenantName ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblTier = new Label { Text = "Assigned Subscription Tier:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbTier = new ComboBox { Location = new Point(20, 145), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbTier.Items.AddRange(new object[] { "Tenant A", "Tenant B", "Tenant C" });
            cmbTier.SelectedItem = existing?.SubscriptionTier ?? "Tenant A";

            var lblEmail = new Label { Text = "Contact Email:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtEmail = new TextBox { Location = new Point(20, 200), Size = new Size(400, 26), Text = existing?.ContactEmail ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblPhone = new Label { Text = "Contact Phone Number:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 255), Size = new Size(400, 26), Text = existing?.ContactPhone ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblAddress = new Label { Text = "Clinic Address:", Location = new Point(20, 290), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtAddress = new TextBox { Location = new Point(20, 310), Size = new Size(400, 26), Text = existing?.Address ?? "", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Create Tenant" : "Save Changes",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 370),
                Size = new Size(400, 40),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblCode, txtCode, lblName, txtName, lblTier, cmbTier, lblEmail, txtEmail, lblPhone, txtPhone, lblAddress, txtAddress, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtName.Text))
            {
                using var db = DbContextFactory.Create();
                if (isNew)
                {
                    db.Tenants.Add(new Tenant
                    {
                        TenantCode = txtCode.Text.Trim(),
                        TenantName = txtName.Text.Trim(),
                        SubscriptionTier = cmbTier.SelectedItem?.ToString() ?? "Tenant A",
                        ContactEmail = txtEmail.Text.Trim(),
                        ContactPhone = txtPhone.Text.Trim(),
                        Address = txtAddress.Text.Trim(),
                        Status = "Active",
                        BranchesCount = (cmbTier.SelectedItem?.ToString() == "Tenant C") ? 3 : 1,
                        CreatedAt = DateTime.UtcNow
                    });
                }
                else
                {
                    var t = db.Tenants.FirstOrDefault(x => x.Id == existing!.Id);
                    if (t != null)
                    {
                        t.TenantCode = txtCode.Text.Trim();
                        t.TenantName = txtName.Text.Trim();
                        t.SubscriptionTier = cmbTier.SelectedItem?.ToString() ?? "Tenant A";
                        t.ContactEmail = txtEmail.Text.Trim();
                        t.ContactPhone = txtPhone.Text.Trim();
                        t.Address = txtAddress.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadTenants();
            }
        }

        private void EditSelectedTenant()
        {
            if (gridTenants.SelectedRows.Count == 0 || gridTenants.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridTenants.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var t = db.Tenants.FirstOrDefault(x => x.Id == id);
            if (t != null)
            {
                ShowTenantDialog(t);
            }
        }

        private void InformSelectedTenant()
        {
            if (gridTenants.SelectedRows.Count == 0 || gridTenants.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridTenants.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var t = db.Tenants.FirstOrDefault(x => x.Id == id);
            if (t == null) return;

            using var dlg = new Form
            {
                Text = $"Dispatch Notification - {t.TenantName}",
                Size = new Size(480, 400),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblHeader = new Label
            {
                Text = $"Inform Client: {t.TenantName} ({t.SubscriptionTier})",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblChannel = new Label { Text = "Notification Medium (Phone / Email):", Location = new Point(20, 50), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbChannel = new ComboBox { Location = new Point(20, 72), Size = new Size(420, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbChannel.Items.AddRange(new object[] { $"Phone SMS ({t.ContactPhone})", $"Email ({t.ContactEmail})", "Both Phone SMS & Email" });
            cmbChannel.SelectedIndex = 0;

            var lblMsg = new Label { Text = "Message Content:", Location = new Point(20, 110), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtMsg = new TextBox
            {
                Location = new Point(20, 132),
                Size = new Size(420, 110),
                Multiline = true,
                Font = new Font("Segoe UI", 9.5F),
                Text = $"Hello {t.TenantName}, this is an official notification from DentalCare Super Administration regarding your {t.SubscriptionTier} subscription privileges and updates."
            };

            var btnSend = new Button
            {
                Text = "Dispatch Notification",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 270),
                Size = new Size(420, 42),
                DialogResult = DialogResult.OK
            };
            btnSend.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblHeader, lblChannel, cmbChannel, lblMsg, txtMsg, btnSend });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string channelChoice = cmbChannel.SelectedItem?.ToString() ?? "Phone SMS";
                db.AuditLogs.Add(new AuditLog
                {
                    UserName = Session.CurrentUser?.Email ?? "superadmin@dentalclinic.com",
                    Module = "Tenants",
                    Action = "ClientNotificationSent",
                    Details = $"Informed {t.TenantName} via {channelChoice}: {txtMsg.Text.Trim()}",
                    Timestamp = DateTime.UtcNow
                });
                db.SaveChanges();

                MessageBox.Show($"Notification successfully dispatched to {t.TenantName} via {channelChoice}!", "Client Informed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSelectedTenant()
        {
            if (gridTenants.SelectedRows.Count == 0 || gridTenants.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridTenants.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Are you sure you want to delete or deactivate this tenant record?", "Confirm Tenant Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var t = db.Tenants.FirstOrDefault(x => x.Id == id);
                if (t != null)
                {
                    db.Tenants.Remove(t);
                    db.SaveChanges();
                    LoadTenants();
                }
            }
        }
    }
}
