using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using DentalClinicWinForms.Services;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class BillingControl : UserControl
    {
        private DataGridView gridBilling = null!;
        private TextBox txtSearch = null!;
        private ComboBox cmbStatusFilter = null!;

        public BillingControl()
        {
            InitializeComponent();
            LoadBilling();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Process Patient Billing & Invoicing (PDF Export Enabled)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Manage clinical billing invoices, record payments, calculate taxes/discounts, and print official invoices in PDF format",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(150, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadBilling();

            var lblStatus = new Label { Text = "Status:", Location = new Point(225, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbStatusFilter = new ComboBox { Location = new Point(275, 11), Size = new Size(120, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbStatusFilter.Items.AddRange(new object[] { "All", "Paid", "PartiallyPaid", "Unpaid" });
            cmbStatusFilter.SelectedIndex = 0;
            cmbStatusFilter.SelectedIndexChanged += (s, e) => LoadBilling();

            var btnAdd = new Button
            {
                Text = "+ New Invoice",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(410, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowAddInvoiceDialog();

            var btnEdit = new Button
            {
                Text = "Edit Invoice",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(535, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedInvoice();

            var btnPay = new Button
            {
                Text = "Record Payment (₱)",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(650, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnPay.FlatAppearance.BorderSize = 0;
            btnPay.Click += (s, e) => ShowRecordPaymentDialog();

            var btnPrintPdf = new Button
            {
                Text = "Print in PDF",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(220, 38, 38),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(805, 9),
                Size = new Size(140, 30),
                Cursor = Cursors.Hand
            };
            btnPrintPdf.FlatAppearance.BorderSize = 0;
            btnPrintPdf.Click += (s, e) => PrintSelectedInvoicePdf();

            var btnDelete = new Button
            {
                Text = "Delete",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(100, 116, 139),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(950, 9),
                Size = new Size(80, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedInvoice();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblStatus, cmbStatusFilter, btnAdd, btnEdit, btnPay, btnPrintPdf, btnDelete });

            gridBilling = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridBilling.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridBilling.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridBilling.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridBilling.EnableHeadersVisualStyles = false;
            gridBilling.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridBilling.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridBilling });
        }

        private void LoadBilling()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();
                string statusFilter = cmbStatusFilter.SelectedItem?.ToString() ?? "All";

                var query = db.BillingInvoices.Include(b => b.Patient).AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(b => b.InvoiceNumber.ToLower().Contains(search) ||
                                             (b.Patient != null && (b.Patient.FirstName.ToLower().Contains(search) || b.Patient.LastName.ToLower().Contains(search))));
                }

                if (statusFilter != "All")
                {
                    if (Enum.TryParse<InvoiceStatus>(statusFilter, out var st))
                    {
                        query = query.Where(b => b.Status == st);
                    }
                }

                var list = query
                    .OrderByDescending(b => b.InvoiceDate)
                    .Take(120)
                    .Select(b => new
                    {
                        Id = b.Id,
                        InvoiceNo = b.InvoiceNumber,
                        Date = b.InvoiceDate.ToString("yyyy-MM-dd"),
                        Patient = b.Patient != null ? b.Patient.FirstName + " " + b.Patient.LastName : "N/A",
                        SubTotal = $"₱{b.SubTotal:N2}",
                        Discount = $"-₱{b.DiscountAmount:N2}",
                        Total = $"₱{b.TotalAmount:N2}",
                        Paid = $"₱{b.AmountPaid:N2}",
                        Balance = $"₱{b.BalanceDue:N2}",
                        Status = b.Status.ToString(),
                        Notes = b.Notes
                    })
                    .ToList();

                gridBilling.DataSource = list;
                if (gridBilling.Columns["Id"] != null) gridBilling.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void PrintSelectedInvoicePdf()
        {
            if (gridBilling.SelectedRows.Count == 0 || gridBilling.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Please select an invoice from the table to print.", "Select Invoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int id = Convert.ToInt32(gridBilling.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var invoice = db.BillingInvoices
                .Include(b => b.Patient)
                .Include(b => b.Items)
                .FirstOrDefault(b => b.Id == id);

            if (invoice != null)
            {
                try
                {
                    string filePath = PdfInvoiceGenerator.GenerateInvoicePdf(invoice);
                    MessageBox.Show($"Billing Invoice #{invoice.InvoiceNumber} generated successfully in PDF!\nFile Location:\n{filePath}", "PDF Invoice Ready", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    PdfInvoiceGenerator.OpenPdf(filePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("PDF Generation error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ShowAddInvoiceDialog()
        {
            using var dlg = new Form
            {
                Text = "Generate New Billing Invoice",
                Size = new Size(460, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            using var db = DbContextFactory.Create();
            var patients = db.Patients.OrderBy(p => p.LastName).Select(p => new { p.Id, Display = p.LastName + ", " + p.FirstName + " (" + p.PatientCode + ")" }).ToList();
            var services = db.DentalServices.Where(s => s.IsActive).OrderBy(s => s.Name).ToList();

            var lblPat = new Label { Text = "Patient:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbPat = new ComboBox { Location = new Point(20, 35), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbPat.DisplayMember = "Display";
            cmbPat.ValueMember = "Id";
            cmbPat.DataSource = patients;

            var lblSvc = new Label { Text = "Clinical Service:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbSvc = new ComboBox { Location = new Point(20, 90), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbSvc.DisplayMember = "Name";
            cmbSvc.ValueMember = "Id";
            cmbSvc.DataSource = services;

            var lblSub = new Label { Text = "SubTotal (₱):", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtSub = new TextBox { Location = new Point(20, 145), Size = new Size(190, 26), Text = "250.00", Font = new Font("Segoe UI", 9.5F) };

            var lblDisc = new Label { Text = "Discount (₱):", Location = new Point(230, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDisc = new TextBox { Location = new Point(230, 145), Size = new Size(190, 26), Text = "0.00", Font = new Font("Segoe UI", 9.5F) };

            cmbSvc.SelectedIndexChanged += (s, e) =>
            {
                if (cmbSvc.SelectedItem is DentalService ds)
                {
                    txtSub.Text = ds.StandardPrice.ToString("N2");
                }
            };

            var lblNotes = new Label { Text = "Invoice Notes & Remarks:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtNotes = new TextBox { Location = new Point(20, 200), Size = new Size(400, 60), Multiline = true, Text = "Clinical consultation and procedure performed.", Font = new Font("Segoe UI", 9.5F) };

            var btnCreate = new Button
            {
                Text = "Create Invoice & Save",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 360),
                Size = new Size(400, 42),
                DialogResult = DialogResult.OK
            };
            btnCreate.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblPat, cmbPat, lblSvc, cmbSvc, lblSub, txtSub, lblDisc, txtDisc, lblNotes, txtNotes, btnCreate });

            if (dlg.ShowDialog() == DialogResult.OK && int.TryParse(cmbPat.SelectedValue?.ToString(), out int patId))
            {
                decimal.TryParse(txtSub.Text, out decimal subTotal);
                decimal.TryParse(txtDisc.Text, out decimal discount);
                decimal tax = Math.Round((subTotal - discount) * 0.05m, 2);
                decimal total = Math.Max(0, (subTotal - discount) + tax);

                int count = db.BillingInvoices.Count() + 1;
                var newInv = new BillingInvoice
                {
                    InvoiceNumber = $"INV-2024-{count:D4}",
                    PatientId = patId,
                    InvoiceDate = DateTime.UtcNow,
                    DueDate = DateTime.UtcNow.AddDays(7),
                    SubTotal = subTotal,
                    DiscountAmount = discount,
                    TaxAmount = tax,
                    TotalAmount = total,
                    AmountPaid = 0,
                    BalanceDue = total,
                    Status = InvoiceStatus.Unpaid,
                    Notes = txtNotes.Text.Trim(),
                    CreatedAt = DateTime.UtcNow
                };

                db.BillingInvoices.Add(newInv);
                db.SaveChanges();
                LoadBilling();

                if (MessageBox.Show("Invoice created successfully! Do you want to print the PDF now?", "Print PDF", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string pdf = PdfInvoiceGenerator.GenerateInvoicePdf(newInv);
                    PdfInvoiceGenerator.OpenPdf(pdf);
                }
            }
        }

        private void EditSelectedInvoice()
        {
            if (gridBilling.SelectedRows.Count == 0 || gridBilling.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridBilling.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var inv = db.BillingInvoices.Include(b => b.Patient).FirstOrDefault(b => b.Id == id);
            if (inv == null) return;

            using var dlg = new Form
            {
                Text = $"Edit Invoice #{inv.InvoiceNumber}",
                Size = new Size(420, 360),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblInfo = new Label { Text = $"Patient: {inv.Patient?.FullName}\nTotal: ₱{inv.TotalAmount:N2} | Paid: ₱{inv.AmountPaid:N2}", Location = new Point(20, 15), Size = new Size(360, 40), Font = new Font("Segoe UI", 9.5F, FontStyle.Bold) };

            var lblSt = new Label { Text = "Status:", Location = new Point(20, 65), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbSt = new ComboBox { Location = new Point(20, 85), Size = new Size(360, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSt.Items.AddRange(new object[] { "Paid", "PartiallyPaid", "Unpaid" });
            cmbSt.SelectedItem = inv.Status.ToString();

            var lblNotes = new Label { Text = "Notes:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtNotes = new TextBox { Location = new Point(20, 145), Size = new Size(360, 70), Multiline = true, Text = inv.Notes ?? "" };

            var btnSave = new Button
            {
                Text = "Save Changes",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 240),
                Size = new Size(360, 40),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblInfo, lblSt, cmbSt, lblNotes, txtNotes, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                Enum.TryParse<InvoiceStatus>(cmbSt.SelectedItem?.ToString() ?? "Unpaid", out var newSt);
                inv.Status = newSt;
                inv.Notes = txtNotes.Text.Trim();
                db.SaveChanges();
                LoadBilling();
            }
        }

        private void DeleteSelectedInvoice()
        {
            if (gridBilling.SelectedRows.Count == 0 || gridBilling.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridBilling.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this billing invoice record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var inv = db.BillingInvoices.FirstOrDefault(b => b.Id == id);
                if (inv != null)
                {
                    db.BillingInvoices.Remove(inv);
                    db.SaveChanges();
                    LoadBilling();
                }
            }
        }

        private void ShowRecordPaymentDialog()
        {
            if (gridBilling.SelectedRows.Count == 0 || gridBilling.SelectedRows[0].Cells["Id"].Value == null) return;
            int invoiceId = Convert.ToInt32(gridBilling.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var inv = db.BillingInvoices.Include(b => b.Patient).FirstOrDefault(b => b.Id == invoiceId);
            if (inv == null || inv.BalanceDue <= 0)
            {
                MessageBox.Show("This invoice has no outstanding balance due.", "Billing Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dlg = new Form
            {
                Text = $"Record Payment - Invoice #{inv.InvoiceNumber}",
                Size = new Size(420, 360),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblInfo = new Label { Text = $"Patient: {inv.Patient?.FullName}\nBalance Due: ₱{inv.BalanceDue:N2}", Location = new Point(20, 20), Size = new Size(360, 45), Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), ForeColor = Color.FromArgb(15, 23, 42) };

            var lblAmt = new Label { Text = "Payment Amount (₱):", Location = new Point(20, 75), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtAmt = new TextBox { Location = new Point(20, 97), Size = new Size(360, 26), Text = inv.BalanceDue.ToString("N2"), Font = new Font("Segoe UI", 9.5F) };

            var lblMethod = new Label { Text = "Payment Method:", Location = new Point(20, 135), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbMethod = new ComboBox { Location = new Point(20, 157), Size = new Size(360, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMethod.Items.AddRange(new object[] { "Cash", "CreditCard", "Insurance", "GCash" });
            cmbMethod.SelectedIndex = 0;

            var btnConfirm = new Button
            {
                Text = "Process Payment",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 240),
                Size = new Size(360, 38),
                DialogResult = DialogResult.OK
            };
            btnConfirm.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblInfo, lblAmt, txtAmt, lblMethod, cmbMethod, btnConfirm });

            if (dlg.ShowDialog() == DialogResult.OK && decimal.TryParse(txtAmt.Text, out decimal payAmt) && payAmt > 0)
            {
                decimal amountToApply = Math.Min(payAmt, inv.BalanceDue);
                inv.AmountPaid += amountToApply;
                inv.BalanceDue = inv.TotalAmount - inv.AmountPaid;
                if (inv.BalanceDue <= 0)
                {
                    inv.BalanceDue = 0;
                    inv.Status = InvoiceStatus.Paid;
                }
                else
                {
                    inv.Status = InvoiceStatus.PartiallyPaid;
                }

                Enum.TryParse<PaymentMethod>(cmbMethod.SelectedItem?.ToString() ?? "Cash", out var pMethod);

                var paymentRecord = new Payment
                {
                    InvoiceId = inv.Id,
                    Amount = amountToApply,
                    PaymentDate = DateTime.UtcNow,
                    Method = pMethod,
                    PaymentReference = $"PAY-{DateTime.UtcNow.Ticks.ToString().Substring(10)}"
                };
                db.Payments.Add(paymentRecord);
                db.SaveChanges();
                LoadBilling();

                if (MessageBox.Show("Payment recorded! Would you like to print the updated PDF receipt now?", "Print Receipt PDF", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string pdf = PdfInvoiceGenerator.GenerateInvoicePdf(inv);
                    PdfInvoiceGenerator.OpenPdf(pdf);
                }
            }
        }
    }
}
