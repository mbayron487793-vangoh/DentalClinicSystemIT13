using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class TreatmentHistoryControl : UserControl
    {
        private ComboBox cmbPatients = null!;
        private DataGridView gridHistory = null!;
        private Label lblPatientDetails = null!;
        private Label lblTotalVisits = null!;
        private Label lblTotalSpent = null!;

        public TreatmentHistoryControl()
        {
            InitializeComponent();
            LoadPatientsDropdown();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Track Patient Treatment History (Dentist Portal)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Chronological clinical timeline of past dental interventions, tooth diagnoses, surgical notes, and prescribed pharmaceuticals",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Patient Selection Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 78),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSelect = new Label
            {
                Text = "Select Patient:",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Location = new Point(12, 14),
                AutoSize = true
            };

            cmbPatients = new ComboBox
            {
                Location = new Point(110, 11),
                Size = new Size(340, 26),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9.5F)
            };
            cmbPatients.SelectedIndexChanged += (s, e) => LoadPatientHistory();

            var btnViewAll = new Button
            {
                Text = "Show All Patient Histories",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 65, 85),
                BackColor = Color.FromArgb(241, 245, 249),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(465, 9),
                Size = new Size(180, 30),
                Cursor = Cursors.Hand
            };
            btnViewAll.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            btnViewAll.Click += (s, e) => LoadAllHistories();

            var btnPrint = new Button
            {
                Text = "Print / Export Summary",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(655, 9),
                Size = new Size(170, 30),
                Cursor = Cursors.Hand
            };
            btnPrint.FlatAppearance.BorderSize = 0;
            btnPrint.Click += (s, e) => PrintTreatmentSummary();

            filterPanel.Controls.AddRange(new Control[] { lblSelect, cmbPatients, btnViewAll, btnPrint });

            // Patient Summary Banner
            var patientBanner = new Panel
            {
                Location = new Point(20, 135),
                Size = new Size(1120, 60),
                BackColor = Color.FromArgb(238, 242, 255),
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            lblPatientDetails = new Label
            {
                Text = "Patient: Select a patient from above to track treatment history.",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(49, 46, 129),
                Location = new Point(15, 10),
                AutoSize = true
            };

            lblTotalVisits = new Label
            {
                Text = "Total Clinical Visits: 0",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(79, 70, 229),
                Location = new Point(15, 33),
                AutoSize = true
            };

            lblTotalSpent = new Label
            {
                Text = "Lifetime Production: ₱0.00",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(79, 70, 229),
                Location = new Point(250, 33),
                AutoSize = true
            };

            patientBanner.Controls.AddRange(new Control[] { lblPatientDetails, lblTotalVisits, lblTotalSpent });

            // Data Grid
            gridHistory = new DataGridView
            {
                Location = new Point(20, 205),
                Size = new Size(1120, 435),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridHistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridHistory.EnableHeadersVisualStyles = false;
            gridHistory.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridHistory.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, patientBanner, gridHistory });
        }

        private void LoadPatientsDropdown()
        {
            try
            {
                using var db = DbContextFactory.Create();
                var patients = db.Patients
                    .OrderBy(p => p.LastName)
                    .ThenBy(p => p.FirstName)
                    .Select(p => new { p.Id, Display = $"{p.LastName}, {p.FirstName} ({p.PatientCode})" })
                    .ToList();

                cmbPatients.DisplayMember = "Display";
                cmbPatients.ValueMember = "Id";
                cmbPatients.DataSource = patients;
            }
            catch { }
        }

        private void LoadPatientHistory()
        {
            if (cmbPatients.SelectedValue == null) return;
            if (!int.TryParse(cmbPatients.SelectedValue.ToString(), out int patientId)) return;

            try
            {
                using var db = DbContextFactory.Create();
                var patient = db.Patients.FirstOrDefault(p => p.Id == patientId);
                if (patient != null)
                {
                    lblPatientDetails.Text = $"Patient: {patient.FullName} | Age: {DateTime.Now.Year - patient.DateOfBirth.Year} | Blood: {patient.BloodType ?? "N/A"} | Allergies: {patient.Allergies ?? "None"} | Medical: {patient.MedicalHistoryNotes ?? "None"}";
                }

                var list = db.TreatmentRecords
                    .Include(t => t.Dentist)
                    .Include(t => t.DentalService)
                    .Where(t => t.PatientId == patientId)
                    .OrderByDescending(t => t.TreatmentDate)
                    .ToList();

                lblTotalVisits.Text = $"Total Clinical Visits: {list.Count}";
                lblTotalSpent.Text = $"Lifetime Production: ₱{list.Sum(t => t.Cost):N2}";

                var displayList = list.Select(t => new
                {
                    Date = t.TreatmentDate.ToString("yyyy-MM-dd"),
                    RecordNo = t.RecordNumber,
                    Tooth = t.ToothNumber ?? "Full Dentition",
                    Service = t.DentalService?.Name ?? "General Treatment",
                    Diagnosis = t.Diagnosis,
                    ProcedureDetails = t.ProcedureNotes,
                    Prescriptions = t.Prescriptions ?? "None",
                    Cost = $"₱{t.Cost:N2}",
                    Dentist = t.Dentist?.FullName ?? "Staff Dentist"
                }).ToList();

                gridHistory.DataSource = displayList;
            }
            catch { }
        }

        private void LoadAllHistories()
        {
            try
            {
                using var db = DbContextFactory.Create();
                lblPatientDetails.Text = "All Clinic Patient Treatment Histories (Consolidated Clinical Log)";
                var list = db.TreatmentRecords
                    .Include(t => t.Patient)
                    .Include(t => t.Dentist)
                    .Include(t => t.DentalService)
                    .OrderByDescending(t => t.TreatmentDate)
                    .Take(150)
                    .ToList();

                lblTotalVisits.Text = $"Total Records Shown: {list.Count}";
                lblTotalSpent.Text = $"Total Production: ₱{list.Sum(t => t.Cost):N2}";

                var displayList = list.Select(t => new
                {
                    Date = t.TreatmentDate.ToString("yyyy-MM-dd"),
                    RecordNo = t.RecordNumber,
                    Patient = t.Patient?.FullName ?? "N/A",
                    Tooth = t.ToothNumber ?? "Full Dentition",
                    Service = t.DentalService?.Name ?? "General Treatment",
                    Diagnosis = t.Diagnosis,
                    ProcedureDetails = t.ProcedureNotes,
                    Prescriptions = t.Prescriptions ?? "None",
                    Cost = $"₱{t.Cost:N2}",
                    Dentist = t.Dentist?.FullName ?? "Staff Dentist"
                }).ToList();

                gridHistory.DataSource = displayList;
            }
            catch { }
        }

        private void PrintTreatmentSummary()
        {
            if (gridHistory.Rows.Count == 0)
            {
                MessageBox.Show("No treatment history data to export.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show($"Treatment history for {cmbPatients.Text} successfully compiled and formatted for clinical review!\nTotal records: {gridHistory.Rows.Count}", "Clinical Treatment Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
