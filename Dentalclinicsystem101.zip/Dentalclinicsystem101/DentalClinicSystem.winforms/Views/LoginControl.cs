using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class LoginControl : UserControl
    {
        private TextBox txtEmail = null!;
        private TextBox txtPassword = null!;
        private Button btnLogin = null!;
        private Label lblError = null!;
        private Action<ApplicationUser, string> onLoginSuccess;

        public LoginControl(Action<ApplicationUser, string> onLoginSuccess)
        {
            this.onLoginSuccess = onLoginSuccess;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);

            var card = new Panel
            {
                Size = new Size(500, 520),
                BackColor = Color.White,
                Location = new Point((this.Width - 500) / 2, Math.Max(20, (this.Height - 520) / 2)),
                Anchor = AnchorStyles.None,
                BorderStyle = BorderStyle.FixedSingle
            };

            var title = new Label
            {
                Text = "DentalCare Portal",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 20),
                Size = new Size(460, 32),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var subtitle = new Label
            {
                Text = "Sign in to your clinical, practice, or tenant subscription account",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(20, 52),
                Size = new Size(460, 22),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var lblEmail = new Label
            {
                Text = "Email Address",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 65, 85),
                Location = new Point(40, 85),
                AutoSize = true
            };

            txtEmail = new TextBox
            {
                Location = new Point(40, 107),
                Size = new Size(418, 28),
                Font = new Font("Segoe UI", 10F),
                PlaceholderText = "name@dentalclinic.com"
            };

            var lblPassword = new Label
            {
                Text = "Password",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 65, 85),
                Location = new Point(40, 142),
                AutoSize = true
            };

            txtPassword = new TextBox
            {
                Location = new Point(40, 164),
                Size = new Size(418, 28),
                Font = new Font("Segoe UI", 10F),
                UseSystemPasswordChar = true,
                Text = "Admin@123456"
            };

            btnLogin = new Button
            {
                Text = "Sign In to Portal",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(40, 205),
                Size = new Size(418, 40),
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;

            lblError = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = Color.Red,
                Location = new Point(40, 250),
                Size = new Size(418, 22),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Quick Role Switch Demo Section
            var lblQuick = new Label
            {
                Text = "One-Click Quick Login by Role & Subscription Tier:",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(71, 85, 105),
                Location = new Point(40, 275),
                AutoSize = true
            };

            var pnlRoles = new FlowLayoutPanel
            {
                Location = new Point(40, 298),
                Size = new Size(418, 205),
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoScroll = false
            };

            pnlRoles.Controls.Add(CreateQuickChip("Master (SuperAdmin)", "superadmin@dentalclinic.com", "SuperAdmin", Color.FromArgb(220, 38, 38)));
            pnlRoles.Controls.Add(CreateQuickChip("Clinic Admin", "admin@dentalclinic.com", "Admin", Color.FromArgb(139, 92, 246)));
            pnlRoles.Controls.Add(CreateQuickChip("Front Desk Staff", "staff@dentalclinic.com", "Staff", Color.FromArgb(16, 185, 129)));
            pnlRoles.Controls.Add(CreateQuickChip("Dr. Smith (Dentist)", "dr.smith@dentalclinic.com", "Dentist", Color.FromArgb(14, 165, 233)));
            pnlRoles.Controls.Add(CreateQuickChip("Tenant A (Main Tx, Data)", "tenanta@dentalclinic.com", "TenantA", Color.FromArgb(245, 158, 11)));
            pnlRoles.Controls.Add(CreateQuickChip("Tenant B (BI, Actions)", "tenantb@dentalclinic.com", "TenantB", Color.FromArgb(99, 102, 241)));
            pnlRoles.Controls.Add(CreateQuickChip("Tenant C (Branching, BI, Actions)", "tenantc@dentalclinic.com", "TenantC", Color.FromArgb(236, 72, 153)));

            card.Controls.Add(title);
            card.Controls.Add(subtitle);
            card.Controls.Add(lblEmail);
            card.Controls.Add(txtEmail);
            card.Controls.Add(lblPassword);
            card.Controls.Add(txtPassword);
            card.Controls.Add(btnLogin);
            card.Controls.Add(lblError);
            card.Controls.Add(lblQuick);
            card.Controls.Add(pnlRoles);

            this.Controls.Add(card);
            this.Resize += (s, e) => { card.Location = new Point((this.Width - 500) / 2, Math.Max(20, (this.Height - 520) / 2)); };
        }

        private Button CreateQuickChip(string label, string email, string role, Color color)
        {
            var btn = new Button
            {
                Text = label,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = color,
                BackColor = Color.FromArgb(248, 250, 252),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(200, 34),
                Margin = new Padding(3, 3, 3, 3),
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btn.FlatAppearance.BorderColor = Color.FromArgb(226, 232, 240);
            btn.Click += (s, e) =>
            {
                txtEmail.Text = email;
                txtPassword.Text = "Admin@123456";
                PerformLogin(email, "Admin@123456");
            };
            return btn;
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            PerformLogin(txtEmail.Text.Trim(), txtPassword.Text);
        }

        private void PerformLogin(string email, string password)
        {
            if (string.IsNullOrEmpty(email))
            {
                lblError.Text = "Please enter your account email.";
                return;
            }

            try
            {
                using var db = DbContextFactory.Create();
                var user = db.Users.FirstOrDefault(u => u.Email == email || u.UserName == email);
                if (user != null)
                {
                    var userRole = db.UserRoles.FirstOrDefault(ur => ur.UserId == user.Id);
                    var role = db.Roles.FirstOrDefault(r => r.Id == (userRole != null ? userRole.RoleId : ""))?.Name ?? user.RoleName;

                    onLoginSuccess?.Invoke(user, role);
                }
                else
                {
                    // Fallback create virtual user if db not seeded yet for this tenant
                    string fallbackRole = "Staff";
                    if (email.Contains("superadmin")) fallbackRole = "SuperAdmin";
                    else if (email.Contains("admin")) fallbackRole = "Admin";
                    else if (email.Contains("smith") || email.Contains("dentist")) fallbackRole = "Dentist";
                    else if (email.Contains("tenanta")) fallbackRole = "TenantA";
                    else if (email.Contains("tenantb")) fallbackRole = "TenantB";
                    else if (email.Contains("tenantc")) fallbackRole = "TenantC";

                    var virtualUser = new ApplicationUser
                    {
                        UserName = email,
                        Email = email,
                        FullName = email.Split('@')[0].ToUpper(),
                        RoleName = fallbackRole
                    };
                    onLoginSuccess?.Invoke(virtualUser, fallbackRole);
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Database connection error: " + ex.Message;
            }
        }
    }
}
