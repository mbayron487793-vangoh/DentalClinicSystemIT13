using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class BranchingControl : UserControl
    {
        private DataGridView gridBranches = null!;
        private Label lblTotalBranches = null!;
        private Label lblTotalChairs = null!;
        private Label lblBranchRevenue = null!;

        public BranchingControl()
        {
            InitializeComponent();
            LoadBranchMetrics();
            LoadBranches();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Clinic Branching & Multi-Location Management (Tenant C)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Enterprise multi-site clinic branches, facility resources, practice chair allocation, and regional revenue metrics",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Metrics Cards
            var metricsPanel = new TableLayoutPanel
            {
                Location = new Point(20, 75),
                Size = new Size(1120, 85),
                ColumnCount = 3,
                RowCount = 1,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));

            var card1 = CreateCard("ACTIVE CLINIC BRANCHES", "4 Locations", Color.FromArgb(2, 132, 199), out lblTotalBranches);
            var card2 = CreateCard("TOTAL OPERATORY CHAIRS", "18 Operatories", Color.FromArgb(139, 92, 246), out lblTotalChairs);
            var card3 = CreateCard("COMBINED BRANCH PRODUCTION", "₱1,280,000.00", Color.FromArgb(16, 185, 129), out lblBranchRevenue);

            metricsPanel.Controls.Add(card1, 0, 0);
            metricsPanel.Controls.Add(card2, 1, 0);
            metricsPanel.Controls.Add(card3, 2, 0);

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 170),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var btnAdd = new Button
            {
                Text = "+ Open New Branch",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(15, 9),
                Size = new Size(160, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowBranchDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Branch",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(185, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedBranch();

            var btnDelete = new Button
            {
                Text = "Close / Delete Branch",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(315, 9),
                Size = new Size(160, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedBranch();

            filterPanel.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete });

            // Data Grid
            gridBranches = new DataGridView
            {
                Location = new Point(20, 230),
                Size = new Size(1120, 430),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridBranches.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridBranches.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridBranches.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridBranches.EnableHeadersVisualStyles = false;
            gridBranches.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridBranches.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, metricsPanel, filterPanel, gridBranches });
        }

        private Panel CreateCard(string title, string value, Color accentColor, out Label lblVal)
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                BorderStyle = BorderStyle.FixedSingle
            };

            var topBar = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = accentColor };
            var lblT = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(12, 10),
                AutoSize = true
            };
            lblVal = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(12, 30),
                AutoSize = true
            };

            p.Controls.Add(lblVal);
            p.Controls.Add(lblT);
            p.Controls.Add(topBar);
            return p;
        }

        private void LoadBranchMetrics()
        {
            try
            {
                using var db = DbContextFactory.Create();
                var branches = db.Branches.ToList();
                lblTotalBranches.Text = $"{branches.Count} Operating Branches";
                lblTotalChairs.Text = $"{branches.Sum(b => b.DentalChairsCount)} Dental Chairs";
                decimal rev = branches.Sum(b => b.MonthlyRevenue);
                lblBranchRevenue.Text = $"₱{rev:N2}";
            }
            catch { }
        }

        private void LoadBranches()
        {
            try
            {
                using var db = DbContextFactory.Create();
                var list = db.Branches
                    .OrderBy(b => b.BranchCode)
                    .Select(b => new
                    {
                        Id = b.Id,
                        Code = b.BranchCode,
                        BranchName = b.BranchName,
                        City = b.CityLocation,
                        Address = b.Address,
                        Phone = b.PhoneNumber,
                        Manager = b.HeadDentistOrManager,
                        Chairs = b.DentalChairsCount,
                        MonthlyProduction = $"₱{b.MonthlyRevenue:N2}",
                        Status = b.IsActive ? "Active" : "Closed"
                    })
                    .ToList();

                gridBranches.DataSource = list;
                if (gridBranches.Columns["Id"] != null) gridBranches.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowBranchDialog(ClinicBranch? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New Clinic Branch" : $"Edit Branch - {existing?.BranchName}",
                Size = new Size(480, 520),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblCode = new Label { Text = "Branch Code:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCode = new TextBox { Location = new Point(20, 35), Size = new Size(420, 26), Text = existing?.BranchCode ?? $"BRN-0{new Random().Next(10, 99)}", Font = new Font("Segoe UI", 9.5F) };

            var lblName = new Label { Text = "Branch Name / Facility:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtName = new TextBox { Location = new Point(20, 90), Size = new Size(420, 26), Text = existing?.BranchName ?? "Downtown Dental Care Center", Font = new Font("Segoe UI", 9.5F) };

            var lblCity = new Label { Text = "City Location:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCity = new TextBox { Location = new Point(20, 145), Size = new Size(420, 26), Text = existing?.CityLocation ?? "Manila Metro Central", Font = new Font("Segoe UI", 9.5F) };

            var lblAddr = new Label { Text = "Physical Address:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtAddr = new TextBox { Location = new Point(20, 200), Size = new Size(420, 26), Text = existing?.Address ?? "Building B, 4th Floor, Health Avenue", Font = new Font("Segoe UI", 9.5F) };

            var lblPhone = new Label { Text = "Contact Phone:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 255), Size = new Size(420, 26), Text = existing?.PhoneNumber ?? "+1 (555) 018-4421", Font = new Font("Segoe UI", 9.5F) };

            var lblMgr = new Label { Text = "Head Practitioner / Clinic Manager:", Location = new Point(20, 290), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtMgr = new TextBox { Location = new Point(20, 310), Size = new Size(420, 26), Text = existing?.HeadDentistOrManager ?? "Dr. Alexander Smith, DDS", Font = new Font("Segoe UI", 9.5F) };

            var lblChairs = new Label { Text = "Number of Dental Operatory Chairs:", Location = new Point(20, 345), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtChairs = new TextBox { Location = new Point(20, 365), Size = new Size(200, 26), Text = existing != null ? existing.DentalChairsCount.ToString() : "5", Font = new Font("Segoe UI", 9.5F) };

            var lblRev = new Label { Text = "Monthly Target Production (₱):", Location = new Point(240, 345), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtRev = new TextBox { Location = new Point(240, 365), Size = new Size(200, 26), Text = existing != null ? existing.MonthlyRevenue.ToString("N2") : "350000.00", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Add Branch Location" : "Save Branch Updates",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 420),
                Size = new Size(420, 40),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblCode, txtCode, lblName, txtName, lblCity, txtCity, lblAddr, txtAddr, lblPhone, txtPhone, lblMgr, txtMgr, lblChairs, txtChairs, lblRev, txtRev, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtName.Text))
            {
                int.TryParse(txtChairs.Text, out int chairs);
                decimal.TryParse(txtRev.Text, out decimal rev);
                using var db = DbContextFactory.Create();

                if (isNew)
                {
                    db.Branches.Add(new ClinicBranch
                    {
                        BranchCode = txtCode.Text.Trim(),
                        BranchName = txtName.Text.Trim(),
                        CityLocation = txtCity.Text.Trim(),
                        Address = txtAddr.Text.Trim(),
                        PhoneNumber = txtPhone.Text.Trim(),
                        HeadDentistOrManager = txtMgr.Text.Trim(),
                        DentalChairsCount = chairs > 0 ? chairs : 4,
                        MonthlyRevenue = rev > 0 ? rev : 250000,
                        IsActive = true,
                        AssignedTenantTier = "Tenant C"
                    });
                }
                else
                {
                    var b = db.Branches.FirstOrDefault(x => x.Id == existing!.Id);
                    if (b != null)
                    {
                        b.BranchCode = txtCode.Text.Trim();
                        b.BranchName = txtName.Text.Trim();
                        b.CityLocation = txtCity.Text.Trim();
                        b.Address = txtAddr.Text.Trim();
                        b.PhoneNumber = txtPhone.Text.Trim();
                        b.HeadDentistOrManager = txtMgr.Text.Trim();
                        b.DentalChairsCount = chairs;
                        b.MonthlyRevenue = rev;
                    }
                }
                db.SaveChanges();
                LoadBranchMetrics();
                LoadBranches();
            }
        }

        private void EditSelectedBranch()
        {
            if (gridBranches.SelectedRows.Count == 0 || gridBranches.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridBranches.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var b = db.Branches.FirstOrDefault(x => x.Id == id);
            if (b != null)
            {
                ShowBranchDialog(b);
            }
        }

        private void DeleteSelectedBranch()
        {
            if (gridBranches.SelectedRows.Count == 0 || gridBranches.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridBranches.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this clinic branch location?", "Confirm Branch Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var b = db.Branches.FirstOrDefault(x => x.Id == id);
                if (b != null)
                {
                    db.Branches.Remove(b);
                    db.SaveChanges();
                    LoadBranchMetrics();
                    LoadBranches();
                }
            }
        }
    }
}
