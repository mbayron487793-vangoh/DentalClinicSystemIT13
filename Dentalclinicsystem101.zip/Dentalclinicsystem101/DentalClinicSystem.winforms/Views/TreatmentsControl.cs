using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class TreatmentsControl : UserControl
    {
        private DataGridView gridTreatments = null!;
        private TextBox txtSearch = null!;

        public TreatmentsControl()
        {
            InitializeComponent();
            LoadTreatments();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Manage Clinical Treatment Records",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Clinical documentation of practitioner procedures, tooth chart numbers, surgical findings, and medication orders",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(200, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadTreatments();

            var btnAdd = new Button
            {
                Text = "+ Record Treatment",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(285, 9),
                Size = new Size(160, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowTreatmentDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Treatment",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(455, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedTreatment();

            var btnDelete = new Button
            {
                Text = "Delete Record",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(585, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedTreatment();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, btnAdd, btnEdit, btnDelete });

            gridTreatments = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridTreatments.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridTreatments.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridTreatments.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridTreatments.EnableHeadersVisualStyles = false;
            gridTreatments.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridTreatments.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridTreatments });
        }

        private void LoadTreatments()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();

                var query = db.TreatmentRecords
                    .Include(t => t.Patient)
                    .Include(t => t.Dentist)
                    .Include(t => t.DentalService)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(t => t.RecordNumber.ToLower().Contains(search) ||
                                             (t.Patient != null && (t.Patient.FirstName.ToLower().Contains(search) || t.Patient.LastName.ToLower().Contains(search))) ||
                                             t.Diagnosis.ToLower().Contains(search) ||
                                             t.ToothNumber.ToLower().Contains(search));
                }

                var list = query
                    .OrderByDescending(t => t.TreatmentDate)
                    .Take(120)
                    .Select(t => new
                    {
                        Id = t.Id,
                        RecordNo = t.RecordNumber,
                        Date = t.TreatmentDate.ToString("yyyy-MM-dd"),
                        Patient = t.Patient != null ? $"{t.Patient.FirstName} {t.Patient.LastName}" : "N/A",
                        Dentist = t.Dentist != null ? t.Dentist.FullName : "Dr. Alexander Smith",
                        Procedure = t.DentalService != null ? t.DentalService.Name : "Clinical Procedure",
                        Tooth = t.ToothNumber != null ? t.ToothNumber : "Full Mouth",
                        Diagnosis = t.Diagnosis,
                        Cost = $"₱{t.Cost:N2}",
                        Prescriptions = t.Prescriptions ?? "None"
                    })
                    .ToList();

                gridTreatments.DataSource = list;
                if (gridTreatments.Columns["Id"] != null) gridTreatments.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowTreatmentDialog(TreatmentRecord? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Record Clinical Dental Treatment" : $"Edit Treatment: {existing?.RecordNumber}",
                Size = new Size(500, 520),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            using var db = DbContextFactory.Create();
            var patients = db.Patients.OrderBy(p => p.LastName).Select(p => new { p.Id, Display = $"{p.LastName}, {p.FirstName} ({p.PatientCode})" }).ToList();
            var dentists = db.Users.Where(u => u.RoleName == "Dentist" || u.RoleName == "Admin").OrderBy(u => u.FullName).Select(u => new { u.Id, Display = u.FullName }).ToList();
            var services = db.DentalServices.Where(s => s.IsActive).OrderBy(s => s.Name).ToList();

            var lblPat = new Label { Text = "Patient:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbPat = new ComboBox { Location = new Point(20, 35), Size = new Size(440, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbPat.DisplayMember = "Display";
            cmbPat.ValueMember = "Id";
            cmbPat.DataSource = patients;
            if (existing != null) cmbPat.SelectedValue = existing.PatientId;

            var lblDoc = new Label { Text = "Attending Dentist:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbDoc = new ComboBox { Location = new Point(20, 90), Size = new Size(440, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbDoc.DisplayMember = "Display";
            cmbDoc.ValueMember = "Id";
            cmbDoc.DataSource = dentists;
            if (existing != null) cmbDoc.SelectedValue = existing.DentistId;

            var lblSvc = new Label { Text = "Service / Procedure:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbSvc = new ComboBox { Location = new Point(20, 145), Size = new Size(290, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbSvc.DisplayMember = "Name";
            cmbSvc.ValueMember = "Id";
            cmbSvc.DataSource = services;
            if (existing != null) cmbSvc.SelectedValue = existing.ServiceId;

            var lblCost = new Label { Text = "Cost (₱):", Location = new Point(320, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCost = new TextBox { Location = new Point(320, 145), Size = new Size(140, 26), Text = existing != null ? existing.Cost.ToString("N2") : "200.00", Font = new Font("Segoe UI", 9.5F) };

            cmbSvc.SelectedIndexChanged += (s, e) =>
            {
                if (cmbSvc.SelectedItem is DentalService ds)
                {
                    txtCost.Text = ds.StandardPrice.ToString("N2");
                }
            };

            var lblTooth = new Label { Text = "Tooth Chart # / Location:", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtTooth = new TextBox { Location = new Point(20, 200), Size = new Size(440, 26), Text = existing?.ToothNumber ?? "Tooth #19 (Mandibular 1st Molar)", Font = new Font("Segoe UI", 9.5F) };

            var lblDiag = new Label { Text = "Clinical Diagnosis:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDiag = new TextBox { Location = new Point(20, 255), Size = new Size(440, 26), Text = existing?.Diagnosis ?? "Dental caries with localized cavity.", Font = new Font("Segoe UI", 9.5F) };

            var lblProc = new Label { Text = "Procedure Notes & Prescriptions:", Location = new Point(20, 290), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtProc = new TextBox { Location = new Point(20, 310), Size = new Size(440, 70), Multiline = true, Text = existing?.ProcedureNotes ?? "Administered local anesthetic. Restored tooth with composite.", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Save Treatment Record" : "Update Treatment",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 410),
                Size = new Size(440, 42),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblPat, cmbPat, lblDoc, cmbDoc, lblSvc, cmbSvc, lblCost, txtCost, lblTooth, txtTooth, lblDiag, txtDiag, lblProc, txtProc, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && int.TryParse(cmbPat.SelectedValue?.ToString(), out int patId))
            {
                string dentistId = cmbDoc.SelectedValue?.ToString() ?? dentists.FirstOrDefault()?.Id ?? "";
                int.TryParse(cmbSvc.SelectedValue?.ToString(), out int svcId);
                decimal.TryParse(txtCost.Text, out decimal cost);

                if (isNew)
                {
                    int count = db.TreatmentRecords.Count() + 1;
                    db.TreatmentRecords.Add(new TreatmentRecord
                    {
                        RecordNumber = $"TRT-2024-{count:D4}",
                        PatientId = patId,
                        DentistId = dentistId,
                        ServiceId = svcId,
                        TreatmentDate = DateTime.UtcNow,
                        ToothNumber = txtTooth.Text.Trim(),
                        Diagnosis = txtDiag.Text.Trim(),
                        ProcedureNotes = txtProc.Text.Trim(),
                        Prescriptions = "Ibuprofen 400mg prn pain",
                        Cost = cost > 0 ? cost : 150,
                        CreatedAt = DateTime.UtcNow
                    });
                }
                else
                {
                    var t = db.TreatmentRecords.FirstOrDefault(x => x.Id == existing!.Id);
                    if (t != null)
                    {
                        t.PatientId = patId;
                        t.DentistId = dentistId;
                        t.ServiceId = svcId;
                        t.Cost = cost;
                        t.ToothNumber = txtTooth.Text.Trim();
                        t.Diagnosis = txtDiag.Text.Trim();
                        t.ProcedureNotes = txtProc.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadTreatments();
            }
        }

        private void EditSelectedTreatment()
        {
            if (gridTreatments.SelectedRows.Count == 0 || gridTreatments.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridTreatments.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var t = db.TreatmentRecords.FirstOrDefault(x => x.Id == id);
            if (t != null)
            {
                ShowTreatmentDialog(t);
            }
        }

        private void DeleteSelectedTreatment()
        {
            if (gridTreatments.SelectedRows.Count == 0 || gridTreatments.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridTreatments.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this clinical treatment record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var t = db.TreatmentRecords.FirstOrDefault(x => x.Id == id);
                if (t != null)
                {
                    db.TreatmentRecords.Remove(t);
                    db.SaveChanges();
                    LoadTreatments();
                }
            }
        }
    }
}
