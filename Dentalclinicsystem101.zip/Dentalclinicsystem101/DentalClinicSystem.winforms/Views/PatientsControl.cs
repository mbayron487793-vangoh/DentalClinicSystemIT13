using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class PatientsControl : UserControl
    {
        private DataGridView gridPatients = null!;
        private TextBox txtSearch = null!;

        public PatientsControl()
        {
            InitializeComponent();
            LoadPatients();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Manage Patient Records",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Directory of active dental patients, contact information, and medical histories",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search Patient:", Location = new Point(12, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(120, 11), Size = new Size(280, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadPatients();

            var btnAdd = new Button
            {
                Text = "+ Add New Patient",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(415, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowAddPatientDialog();

            var btnEdit = new Button
            {
                Text = "Edit Selected",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(575, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedPatient();

            var btnDelete = new Button
            {
                Text = "Delete Patient",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(705, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedPatient();

            filterPanel.Controls.Add(lblSearch);
            filterPanel.Controls.Add(txtSearch);
            filterPanel.Controls.Add(btnAdd);
            filterPanel.Controls.Add(btnEdit);
            filterPanel.Controls.Add(btnDelete);

            // Data Grid
            gridPatients = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridPatients.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridPatients.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridPatients.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridPatients.EnableHeadersVisualStyles = false;
            gridPatients.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridPatients.RowTemplate.Height = 32;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblSub);
            this.Controls.Add(filterPanel);
            this.Controls.Add(gridPatients);
        }

        private void LoadPatients()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch?.Text.Trim() ?? "";

                var query = db.Patients.Where(p => p.IsActive);
                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(p => p.FirstName.Contains(search) || p.LastName.Contains(search) || p.PatientCode.Contains(search) || p.Phone.Contains(search));
                }

                var list = query
                    .OrderBy(p => p.FirstName)
                    .Select(p => new
                    {
                        Id = p.Id,
                        Code = p.PatientCode,
                        FullName = p.FullName,
                        DOB = p.DateOfBirth.ToString("yyyy-MM-dd"),
                        Gender = p.Gender,
                        Phone = p.Phone,
                        Email = p.Email ?? "-",
                        Address = p.Address ?? "-",
                        MedicalHistory = p.MedicalHistoryNotes ?? "None"
                    })
                    .ToList();

                gridPatients.DataSource = list;
                if (gridPatients.Columns["Id"] != null) gridPatients.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowAddPatientDialog()
        {
            using var dlg = new Form
            {
                Text = "Add New Patient Record",
                Size = new Size(480, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblF = new Label { Text = "First Name:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtF = new TextBox { Location = new Point(20, 42), Size = new Size(420, 26) };

            var lblL = new Label { Text = "Last Name:", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtL = new TextBox { Location = new Point(20, 102), Size = new Size(420, 26) };

            var lblPhone = new Label { Text = "Phone Number:", Location = new Point(20, 140), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 162), Size = new Size(420, 26) };

            var lblEmail = new Label { Text = "Email Address:", Location = new Point(20, 200), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtEmail = new TextBox { Location = new Point(20, 222), Size = new Size(420, 26) };

            var lblNotes = new Label { Text = "Medical History / Allergies:", Location = new Point(20, 260), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtNotes = new TextBox { Location = new Point(20, 282), Size = new Size(420, 60), Multiline = true };

            var btnSave = new Button
            {
                Text = "Save Patient",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 365),
                Size = new Size(420, 38),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblF, txtF, lblL, txtL, lblPhone, txtPhone, lblEmail, txtEmail, lblNotes, txtNotes, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtF.Text) && !string.IsNullOrWhiteSpace(txtL.Text))
            {
                using var db = DbContextFactory.Create();
                int nextId = db.Patients.Count() + 1001;
                var pat = new Patient
                {
                    PatientCode = $"PAT-{nextId}",
                    FirstName = txtF.Text.Trim(),
                    LastName = txtL.Text.Trim(),
                    DateOfBirth = DateTime.UtcNow.AddYears(-25),
                    Gender = "Male",
                    Phone = txtPhone.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    MedicalHistoryNotes = txtNotes.Text.Trim(),
                    IsActive = true
                };
                db.Patients.Add(pat);
                db.SaveChanges();
                LoadPatients();
            }
        }

        private void EditSelectedPatient()
        {
            if (gridPatients.SelectedRows.Count == 0) return;
            int patId = (int)gridPatients.SelectedRows[0].Cells["Id"].Value;

            using var db = DbContextFactory.Create();
            var pat = db.Patients.Find(patId);
            if (pat == null) return;

            using var dlg = new Form
            {
                Text = $"Edit Patient - {pat.FullName}",
                Size = new Size(480, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblF = new Label { Text = "First Name:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtF = new TextBox { Location = new Point(20, 42), Size = new Size(420, 26), Text = pat.FirstName };

            var lblL = new Label { Text = "Last Name:", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtL = new TextBox { Location = new Point(20, 102), Size = new Size(420, 26), Text = pat.LastName };

            var lblPhone = new Label { Text = "Phone Number:", Location = new Point(20, 140), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 162), Size = new Size(420, 26), Text = pat.Phone };

            var lblEmail = new Label { Text = "Email Address:", Location = new Point(20, 200), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtEmail = new TextBox { Location = new Point(20, 222), Size = new Size(420, 26), Text = pat.Email };

            var lblNotes = new Label { Text = "Medical History Notes:", Location = new Point(20, 260), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtNotes = new TextBox { Location = new Point(20, 282), Size = new Size(420, 60), Multiline = true, Text = pat.MedicalHistoryNotes };

            var btnSave = new Button
            {
                Text = "Update Patient Record",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 365),
                Size = new Size(420, 38),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblF, txtF, lblL, txtL, lblPhone, txtPhone, lblEmail, txtEmail, lblNotes, txtNotes, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                pat.FirstName = txtF.Text.Trim();
                pat.LastName = txtL.Text.Trim();
                pat.Phone = txtPhone.Text.Trim();
                pat.Email = txtEmail.Text.Trim();
                pat.MedicalHistoryNotes = txtNotes.Text.Trim();
                db.SaveChanges();
                LoadPatients();
            }
        }

        private void DeleteSelectedPatient()
        {
            if (gridPatients.SelectedRows.Count == 0 || gridPatients.SelectedRows[0].Cells["Id"].Value == null) return;
            int patId = Convert.ToInt32(gridPatients.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Are you sure you want to delete this patient record?", "Confirm Patient Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var pat = db.Patients.Find(patId);
                if (pat != null)
                {
                    db.Patients.Remove(pat);
                    db.SaveChanges();
                    LoadPatients();
                }
            }
        }
    }
}
