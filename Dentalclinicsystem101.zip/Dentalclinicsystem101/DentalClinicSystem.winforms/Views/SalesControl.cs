using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class SalesControl : UserControl
    {
        private DataGridView gridSales = null!;
        private TextBox txtSearch = null!;
        private ComboBox cmbStatus = null!;

        public SalesControl()
        {
            InitializeComponent();
            LoadSalesData();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Sales Service Module",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Executive clinical sales oversight, revenue reconciliation, and payment status",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Filter Bar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1100, 45),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 12), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(70, 9), Size = new Size(220, 26), Font = new Font("Segoe UI", 9F) };
            txtSearch.TextChanged += (s, e) => LoadSalesData();

            var lblStatus = new Label { Text = "Payment Status:", Location = new Point(310, 12), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbStatus = new ComboBox { Location = new Point(430, 9), Size = new Size(160, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbStatus.Items.AddRange(new object[] { "All Statuses", "Paid", "PartiallyPaid", "Unpaid" });
            cmbStatus.SelectedIndex = 0;
            cmbStatus.SelectedIndexChanged += (s, e) => LoadSalesData();

            filterPanel.Controls.Add(lblSearch);
            filterPanel.Controls.Add(txtSearch);
            filterPanel.Controls.Add(lblStatus);
            filterPanel.Controls.Add(cmbStatus);

            // Grid
            gridSales = new DataGridView
            {
                Location = new Point(20, 135),
                Size = new Size(1100, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridSales.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridSales.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridSales.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridSales.EnableHeadersVisualStyles = false;
            gridSales.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridSales.RowTemplate.Height = 30;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblSub);
            this.Controls.Add(filterPanel);
            this.Controls.Add(gridSales);
        }

        private void LoadSalesData()
        {
            try
            {
                using var db = DbContextFactory.Create();
                var query = db.BillingInvoices
                    .Include(i => i.Patient)
                    .Include(i => i.Items)
                    .AsQueryable();

                string search = txtSearch?.Text.Trim() ?? "";
                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(i => i.InvoiceNumber.Contains(search) || (i.Patient != null && i.Patient.FullName.Contains(search)));
                }

                string status = cmbStatus?.SelectedItem?.ToString() ?? "All Statuses";
                if (status != "All Statuses" && Enum.TryParse<InvoiceStatus>(status, out var parsedStatus))
                {
                    query = query.Where(i => i.Status == parsedStatus);
                }

                var list = query
                    .OrderByDescending(i => i.InvoiceDate)
                    .Take(100)
                    .ToList()
                    .Select(i => new
                    {
                        InvoiceNo = i.InvoiceNumber,
                        Date = i.InvoiceDate.ToString("MMM dd, yyyy"),
                        Patient = i.Patient?.FullName ?? "N/A",
                        Subtotal = $"₱{i.SubTotal:N2}",
                        Discount = $"-₱{i.DiscountAmount:N2}",
                        TotalAmount = $"₱{i.TotalAmount:N2}",
                        AmountPaid = $"₱{i.AmountPaid:N2}",
                        BalanceDue = $"₱{i.BalanceDue:N2}",
                        Status = i.Status.ToString()
                    })
                    .ToList();

                gridSales.DataSource = list;
            }
            catch { }
        }
    }
}
