using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class AppointmentsControl : UserControl
    {
        private DataGridView gridAppts = null!;
        private ComboBox cmbStatusFilter = null!;

        public AppointmentsControl()
        {
            InitializeComponent();
            LoadAppointments();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Schedule & View Appointments",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Patient appointment booking, practitioner schedules, and visit statuses",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblStatus = new Label { Text = "Filter Status:", Location = new Point(12, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbStatusFilter = new ComboBox { Location = new Point(100, 11), Size = new Size(160, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbStatusFilter.Items.AddRange(new object[] { "All Statuses", "Scheduled", "Confirmed", "InProgress", "Completed", "Cancelled" });
            cmbStatusFilter.SelectedIndex = 0;
            cmbStatusFilter.SelectedIndexChanged += (s, e) => LoadAppointments();

            var btnBook = new Button
            {
                Text = "+ Schedule Appointment",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(280, 9),
                Size = new Size(180, 30),
                Cursor = Cursors.Hand
            };
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Click += (s, e) => ShowScheduleDialog();

            var btnComplete = new Button
            {
                Text = "Mark Completed",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(470, 9),
                Size = new Size(130, 30),
                Cursor = Cursors.Hand
            };
            btnComplete.FlatAppearance.BorderSize = 0;
            btnComplete.Click += (s, e) => ChangeStatus(AppointmentStatus.Completed);

            var btnCancel = new Button
            {
                Text = "Cancel Appt",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(605, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.Click += (s, e) => ChangeStatus(AppointmentStatus.Cancelled);

            var btnDelete = new Button
            {
                Text = "Delete Appt",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(100, 116, 139),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(720, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedAppointment();

            filterPanel.Controls.Add(lblStatus);
            filterPanel.Controls.Add(cmbStatusFilter);
            filterPanel.Controls.Add(btnBook);
            filterPanel.Controls.Add(btnComplete);
            filterPanel.Controls.Add(btnCancel);
            filterPanel.Controls.Add(btnDelete);

            gridAppts = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridAppts.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridAppts.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridAppts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridAppts.EnableHeadersVisualStyles = false;
            gridAppts.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridAppts.RowTemplate.Height = 30;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblSub);
            this.Controls.Add(filterPanel);
            this.Controls.Add(gridAppts);
        }

        private void LoadAppointments()
        {
            try
            {
                using var db = DbContextFactory.Create();
                var query = db.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Dentist)
                    .Include(a => a.DentalService)
                    .AsQueryable();

                string selectedStatus = cmbStatusFilter?.SelectedItem?.ToString() ?? "All Statuses";
                if (selectedStatus != "All Statuses" && Enum.TryParse<AppointmentStatus>(selectedStatus, out var status))
                {
                    query = query.Where(a => a.Status == status);
                }

                var list = query
                    .OrderByDescending(a => a.AppointmentDate)
                    .Take(100)
                    .ToList()
                    .Select(a => new
                    {
                        Id = a.Id,
                        ApptNumber = a.AppointmentNumber,
                        Date = a.AppointmentDate.ToString("MMM dd, yyyy"),
                        Time = $"{a.StartTime} - {a.EndTime}",
                        Patient = a.Patient?.FullName ?? "N/A",
                        Dentist = a.Dentist?.FullName ?? "Clinical Staff",
                        Service = a.DentalService?.Name ?? "General Checkup",
                        Status = a.Status.ToString(),
                        Notes = a.ReasonForVisit ?? "-"
                    })
                    .ToList();

                gridAppts.DataSource = list;
                if (gridAppts.Columns["Id"] != null) gridAppts.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ChangeStatus(AppointmentStatus newStatus)
        {
            if (gridAppts.SelectedRows.Count == 0) return;
            int apptId = (int)gridAppts.SelectedRows[0].Cells["Id"].Value;

            using var db = DbContextFactory.Create();
            var appt = db.Appointments.Find(apptId);
            if (appt != null)
            {
                appt.Status = newStatus;
                db.SaveChanges();
                LoadAppointments();
            }
        }

        private void DeleteSelectedAppointment()
        {
            if (gridAppts.SelectedRows.Count == 0) return;
            int apptId = (int)gridAppts.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Are you sure you want to delete this appointment?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var appt = db.Appointments.Find(apptId);
                if (appt != null)
                {
                    db.Appointments.Remove(appt);
                    db.SaveChanges();
                    LoadAppointments();
                }
            }
        }

        private void ShowScheduleDialog()
        {
            using var db = DbContextFactory.Create();
            var patients = db.Patients.Where(p => p.IsActive).OrderBy(p => p.FirstName).ToList();
            var dentists = db.Users.Where(u => u.RoleName == "Dentist").ToList();
            var services = db.DentalServices.Where(s => s.IsActive).ToList();

            if (patients.Count == 0 || dentists.Count == 0 || services.Count == 0) return;

            using var dlg = new Form
            {
                Text = "Schedule New Appointment",
                Size = new Size(460, 420),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblP = new Label { Text = "Select Patient:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbP = new ComboBox { Location = new Point(20, 42), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbP.DataSource = patients;
            cmbP.DisplayMember = "FullName";
            cmbP.ValueMember = "Id";

            var lblD = new Label { Text = "Select Dentist:", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbD = new ComboBox { Location = new Point(20, 102), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbD.DataSource = dentists;
            cmbD.DisplayMember = "FullName";
            cmbD.ValueMember = "Id";

            var lblS = new Label { Text = "Select Dental Service:", Location = new Point(20, 140), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbS = new ComboBox { Location = new Point(20, 162), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbS.DataSource = services;
            cmbS.DisplayMember = "Name";
            cmbS.ValueMember = "Id";

            var lblDate = new Label { Text = "Appointment Date:", Location = new Point(20, 200), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var dtpDate = new DateTimePicker { Location = new Point(20, 222), Size = new Size(400, 26), Value = DateTime.Today.AddDays(1) };

            var btnSave = new Button
            {
                Text = "Book Appointment",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 310),
                Size = new Size(400, 38),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblP, cmbP, lblD, cmbD, lblS, cmbS, lblDate, dtpDate, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && cmbP.SelectedValue != null && cmbD.SelectedValue != null && cmbS.SelectedValue != null)
            {
                int nextId = db.Appointments.Count() + 1001;
                var newAppt = new Appointment
                {
                    AppointmentNumber = $"APT-2024-{nextId}",
                    PatientId = (int)cmbP.SelectedValue,
                    DentistId = (string)cmbD.SelectedValue,
                    ServiceId = (int)cmbS.SelectedValue,
                    AppointmentDate = dtpDate.Value.Date,
                    StartTime = new TimeSpan(10, 0, 0),
                    EndTime = new TimeSpan(10, 30, 0),
                    Status = AppointmentStatus.Scheduled,
                    ReasonForVisit = "Standard Clinical Consultation & Treatment"
                };
                db.Appointments.Add(newAppt);
                db.SaveChanges();
                LoadAppointments();
            }
        }
    }
}
