using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DentalClinicWinForms.Views
{
    public class DrilldownForm : Form
    {
        private DataGridView gridDetails = null!;
        private TextBox txtSearch = null!;
        private Label lblTotal = null!;
        private IEnumerable sourceData;

        public DrilldownForm(string modalTitle, string subtitle, string totalText, IEnumerable data)
        {
            this.sourceData = data;
            InitializeComponent(modalTitle, subtitle, totalText);
            BindGrid(data);
        }

        private void InitializeComponent(string modalTitle, string subtitle, string totalText)
        {
            this.Text = modalTitle;
            this.Size = new Size(950, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(15);

            // Header Panel
            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblTitle = new Label
            {
                Text = modalTitle,
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(15, 10),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = subtitle,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(16, 36),
                AutoSize = true
            };

            lblTotal = new Label
            {
                Text = totalText,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(16, 185, 129),
                Location = new Point(650, 18),
                Size = new Size(270, 30),
                TextAlign = ContentAlignment.MiddleRight,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            headerPanel.Controls.Add(lblTitle);
            headerPanel.Controls.Add(lblSub);
            headerPanel.Controls.Add(lblTotal);

            // Search Bar
            var searchPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 45,
                BackColor = Color.FromArgb(241, 245, 249),
                Padding = new Padding(0, 10, 0, 10)
            };

            var lblSearch = new Label { Text = "Search Drilldown Items:", Location = new Point(5, 14), AutoSize = true, Font = new Font("Segoe UI", 8.5F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(160, 10), Size = new Size(300, 25), Font = new Font("Segoe UI", 9F) };
            txtSearch.TextChanged += (s, e) => FilterData();

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);

            // Data Grid
            gridDetails = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };
            gridDetails.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridDetails.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridDetails.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridDetails.EnableHeadersVisualStyles = false;
            gridDetails.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridDetails.RowTemplate.Height = 30;

            // Close Button
            var bottomPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 45,
                BackColor = Color.FromArgb(241, 245, 249)
            };

            var btnClose = new Button
            {
                Text = "Close Drilldown",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(15, 23, 42),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(800, 8),
                Size = new Size(120, 30),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right,
                DialogResult = DialogResult.OK,
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            bottomPanel.Controls.Add(btnClose);

            this.Controls.Add(gridDetails);
            this.Controls.Add(searchPanel);
            this.Controls.Add(headerPanel);
            this.Controls.Add(bottomPanel);
        }

        private void BindGrid(IEnumerable data)
        {
            gridDetails.DataSource = data;
        }

        private void FilterData()
        {
            string search = txtSearch.Text.Trim().ToLower();
            if (string.IsNullOrEmpty(search))
            {
                BindGrid(sourceData);
                return;
            }

            // Simple search filtering
            var list = new List<object>();
            foreach (var item in sourceData)
            {
                string itemStr = item.ToString() ?? "";
                var props = item.GetType().GetProperties();
                bool match = props.Any(p => (p.GetValue(item)?.ToString() ?? "").ToLower().Contains(search));
                if (match) list.Add(item);
            }
            BindGrid(list);
        }
    }
}
