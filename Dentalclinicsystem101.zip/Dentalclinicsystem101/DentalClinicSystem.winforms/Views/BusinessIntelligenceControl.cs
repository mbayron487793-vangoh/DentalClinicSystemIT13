using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class BusinessIntelligenceControl : UserControl
    {
        private TableLayoutPanel kpiPanel = null!;
        private TableLayoutPanel graphsPanel = null!;
        private DataGridView gridSummary = null!;

        public BusinessIntelligenceControl()
        {
            InitializeComponent();
            LoadDataAndBuildGraphs();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(15);
            this.AutoScroll = true;

            var mainLayout = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                Width = 1200
            };

            // Header
            var lblTitle = new Label
            {
                Text = "Business Intelligence & Clinical Analytics",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Margin = new Padding(10, 10, 10, 2),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Real-time practice performance, financial KPIs, and patient volume tracking (Click cards/rows for drilldown details)",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Margin = new Padding(12, 0, 10, 15),
                AutoSize = true
            };

            // 1. KPI Cards Row
            kpiPanel = new TableLayoutPanel
            {
                Size = new Size(1160, 100),
                ColumnCount = 4,
                RowCount = 1,
                Margin = new Padding(10, 0, 10, 15)
            };
            kpiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            kpiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            kpiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            kpiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));

            // 2. Graphs 2x3 Grid Container
            graphsPanel = new TableLayoutPanel
            {
                Size = new Size(1160, 820),
                ColumnCount = 2,
                RowCount = 3,
                Margin = new Padding(10, 0, 10, 15)
            };
            graphsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            graphsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            graphsPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 270F));
            graphsPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 270F));
            graphsPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 270F));

            // Table Title
            var lblTableTitle = new Label
            {
                Text = "Top Performing Dental Services (Click row to inspect case drilldown)",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Margin = new Padding(10, 10, 10, 5),
                AutoSize = true
            };

            // Grid Summary
            gridSummary = new DataGridView
            {
                Size = new Size(1160, 350),
                Margin = new Padding(10, 0, 10, 30),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                Cursor = Cursors.Hand
            };
            gridSummary.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridSummary.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridSummary.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridSummary.EnableHeadersVisualStyles = false;
            gridSummary.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridSummary.RowTemplate.Height = 32;

            gridSummary.CellDoubleClick += GridSummary_CellDoubleClick;

            mainLayout.Controls.Add(lblTitle);
            mainLayout.Controls.Add(lblSub);
            mainLayout.Controls.Add(kpiPanel);
            mainLayout.Controls.Add(graphsPanel);
            mainLayout.Controls.Add(lblTableTitle);
            mainLayout.Controls.Add(gridSummary);

            this.Controls.Add(mainLayout);
        }

        private Panel CreateKpiCard(string title, string value, Color accentColor, Action onClick)
        {
            var pnl = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                Padding = new Padding(10),
                BorderStyle = BorderStyle.FixedSingle,
                Cursor = Cursors.Hand
            };

            var bar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 5,
                BackColor = accentColor
            };

            var lblT = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(14, 10),
                AutoSize = true,
                Cursor = Cursors.Hand
            };

            var lblV = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = accentColor,
                Location = new Point(12, 32),
                AutoSize = true,
                Cursor = Cursors.Hand
            };

            var lblClickMsg = new Label
            {
                Text = "Click for drilldown details →",
                Font = new Font("Segoe UI", 7.5F, FontStyle.Italic),
                ForeColor = Color.FromArgb(148, 163, 184),
                Location = new Point(14, 68),
                AutoSize = true,
                Cursor = Cursors.Hand
            };

            pnl.Controls.Add(bar);
            pnl.Controls.Add(lblT);
            pnl.Controls.Add(lblV);
            pnl.Controls.Add(lblClickMsg);

            pnl.Click += (s, e) => onClick();
            lblT.Click += (s, e) => onClick();
            lblV.Click += (s, e) => onClick();
            lblClickMsg.Click += (s, e) => onClick();

            return pnl;
        }

        private void LoadDataAndBuildGraphs()
        {
            try
            {
                using var db = DbContextFactory.Create();

                // ── 1. KPI Cards ──
                decimal totalBilled = db.BillingInvoices.Sum(i => (decimal?)i.TotalAmount) ?? 0m;
                decimal totalPaid = db.Payments.Sum(p => (decimal?)p.Amount) ?? 0m;
                decimal totalDue = db.BillingInvoices.Sum(i => (decimal?)i.BalanceDue) ?? 0m;
                decimal totalDiscounts = db.BillingInvoices.Sum(i => (decimal?)i.DiscountAmount) ?? 0m;

                kpiPanel.Controls.Clear();
                kpiPanel.Controls.Add(CreateKpiCard("GROSS BILLED SALES", $"₱{totalBilled:N2}", Color.FromArgb(2, 132, 199), () => DrilldownBilledSales()), 0, 0);
                kpiPanel.Controls.Add(CreateKpiCard("COLLECTED REVENUE", $"₱{totalPaid:N2}", Color.FromArgb(16, 185, 129), () => DrilldownCollectedRevenue()), 1, 0);
                kpiPanel.Controls.Add(CreateKpiCard("OUTSTANDING RECEIVABLES", $"₱{totalDue:N2}", Color.FromArgb(239, 68, 68), () => DrilldownOutstandingReceivables()), 2, 0);
                kpiPanel.Controls.Add(CreateKpiCard("PROMO DISCOUNTS GRANTED", $"-₱{totalDiscounts:N2}", Color.FromArgb(245, 158, 11), () => DrilldownPromoDiscounts()), 3, 0);

                // ── 2. Build 5 Native GDI+ Graphs ──
                graphsPanel.Controls.Clear();

                var today = DateTime.UtcNow.Date;
                var payments = db.Payments.ToList();
                var monthlyLabels = new List<string>();
                var monthlyValues = new List<decimal>();

                for (int m = 11; m >= 0; m--)
                {
                    var targetMonth = today.AddMonths(-m);
                    var monthStart = new DateTime(targetMonth.Year, targetMonth.Month, 1);
                    var monthEnd = monthStart.AddMonths(1);
                    monthlyLabels.Add(targetMonth.ToString("MMM"));
                    decimal mRev = payments.Where(p => p.PaymentDate >= monthStart && p.PaymentDate < monthEnd).Sum(p => p.Amount);
                    monthlyValues.Add(mRev);
                }
                var chart1 = new LineChartControl("Monthly Revenue Trend (Last 12 Months)", monthlyLabels, monthlyValues);
                graphsPanel.Controls.Add(chart1, 0, 0);

                var catData = db.TreatmentRecords
                    .Include(t => t.DentalService)
                    .Where(t => t.DentalService != null)
                    .ToList()
                    .GroupBy(t => t.DentalService!.Category)
                    .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Sum(x => x.Cost) })
                    .OrderByDescending(x => x.Value)
                    .ToList();
                var chart2 = new DoughnutChartControl("Revenue Distribution by Category", catData);
                graphsPanel.Controls.Add(chart2, 1, 0);

                var appts = db.Appointments.ToList();
                var statusData = Enum.GetValues<AppointmentStatus>()
                    .Select(s => new ChartCategoryItem { Name = s.ToString(), Value = appts.Count(a => a.Status == s) })
                    .Where(s => s.Value > 0)
                    .ToList();
                var chart3 = new PieChartControl("Appointment Status Distribution", statusData);
                graphsPanel.Controls.Add(chart3, 0, 1);

                var dentistData = db.TreatmentRecords
                    .Include(t => t.Dentist)
                    .Where(t => t.Dentist != null)
                    .ToList()
                    .GroupBy(t => t.Dentist!.FullName)
                    .Select(g => new ChartCategoryItem { Name = g.Key.Replace("Dr. ", ""), Value = g.Sum(x => x.Cost) })
                    .OrderByDescending(x => x.Value)
                    .ToList();
                var chart4 = new BarChartControl("Dentist Production Comparison (₱)", dentistData, Color.FromArgb(139, 92, 246));
                graphsPanel.Controls.Add(chart4, 1, 1);

                var promoData = db.Promotions
                    .Include(p => p.AppliedInvoices)
                    .ToList()
                    .Select(p => new PromoImpactItem
                    {
                        PromoCode = p.PromoCode,
                        Discount = p.AppliedInvoices.Sum(i => i.DiscountAmount),
                        Revenue = p.AppliedInvoices.Sum(i => i.TotalAmount)
                    })
                    .Where(p => p.Discount > 0 || p.Revenue > 0)
                    .ToList();
                var chart5 = new PromoImpactChartControl("Promotional Discounts vs Revenue", promoData);
                graphsPanel.Controls.Add(chart5, 0, 2);

                var retentionBox = CreateRetentionSummaryCard(db);
                graphsPanel.Controls.Add(retentionBox, 1, 2);

                // ── 3. Populate Summary Grid ──
                var services = db.DentalServices
                    .Select(s => new
                    {
                        ServiceCode = s.ServiceCode,
                        ServiceName = s.Name,
                        Category = s.Category,
                        StandardPrice = $"₱{s.StandardPrice:N2}",
                        TotalTimesRendered = db.InvoiceItems.Count(i => i.ServiceId == s.Id),
                        TotalRevenueGenerated = $"₱{(db.InvoiceItems.Where(i => i.ServiceId == s.Id).Sum(i => (decimal?)i.LineTotal) ?? 0m):N2}"
                    })
                    .OrderByDescending(s => s.TotalTimesRendered)
                    .ToList();

                gridSummary.DataSource = services;
            }
            catch { }
        }

        // ── DRILLDOWN ACTION HANDLERS ──

        private void DrilldownBilledSales()
        {
            using var db = DbContextFactory.Create();
            var invoices = db.BillingInvoices
                .Include(i => i.Patient)
                .OrderByDescending(i => i.InvoiceDate)
                .Select(i => new
                {
                    InvoiceNo = i.InvoiceNumber,
                    Date = i.InvoiceDate.ToString("MMM dd, yyyy"),
                    Patient = i.Patient != null ? i.Patient.FullName : "N/A",
                    Subtotal = $"₱{i.SubTotal:N2}",
                    Discount = $"-₱{i.DiscountAmount:N2}",
                    TotalAmount = $"₱{i.TotalAmount:N2}",
                    Status = i.Status.ToString()
                })
                .ToList();

            decimal sum = db.BillingInvoices.Sum(i => (decimal?)i.TotalAmount) ?? 0m;
            using var dlg = new DrilldownForm("Gross Billed Sales Drilldown", "Showing itemized clinical billing invoices from SQL Server DB", $"Total Billed: ₱{sum:N2}", invoices);
            dlg.ShowDialog();
        }

        private void DrilldownCollectedRevenue()
        {
            using var db = DbContextFactory.Create();
            var payments = db.Payments
                .Include(p => p.Invoice)
                .ThenInclude(i => i!.Patient)
                .OrderByDescending(p => p.PaymentDate)
                .Select(p => new
                {
                    PaymentRef = p.PaymentReference,
                    Date = p.PaymentDate.ToString("MMM dd, yyyy hh:mm tt"),
                    Patient = p.Invoice != null && p.Invoice.Patient != null ? p.Invoice.Patient.FullName : "N/A",
                    Method = p.Method.ToString(),
                    AmountPaid = $"₱{p.Amount:N2}",
                    InvoiceRef = p.Invoice != null ? p.Invoice.InvoiceNumber : "-"
                })
                .ToList();

            decimal sum = db.Payments.Sum(p => (decimal?)p.Amount) ?? 0m;
            using var dlg = new DrilldownForm("Collected Revenue Drilldown", "Showing cleared patient payments & transaction references", $"Total Collected: ₱{sum:N2}", payments);
            dlg.ShowDialog();
        }

        private void DrilldownOutstandingReceivables()
        {
            using var db = DbContextFactory.Create();
            var unpaid = db.BillingInvoices
                .Include(i => i.Patient)
                .Where(i => i.BalanceDue > 0)
                .OrderByDescending(i => i.BalanceDue)
                .Select(i => new
                {
                    InvoiceNo = i.InvoiceNumber,
                    Date = i.InvoiceDate.ToString("MMM dd, yyyy"),
                    Patient = i.Patient != null ? i.Patient.FullName : "N/A",
                    TotalAmount = $"₱{i.TotalAmount:N2}",
                    AmountPaid = $"₱{i.AmountPaid:N2}",
                    BalanceDue = $"₱{i.BalanceDue:N2}",
                    Status = i.Status.ToString()
                })
                .ToList();

            decimal sum = db.BillingInvoices.Sum(i => (decimal?)i.BalanceDue) ?? 0m;
            using var dlg = new DrilldownForm("Outstanding Receivables Drilldown", "Showing all pending patient balances and uncollected accounts", $"Total Due: ₱{sum:N2}", unpaid);
            dlg.ShowDialog();
        }

        private void DrilldownPromoDiscounts()
        {
            using var db = DbContextFactory.Create();
            var promos = db.BillingInvoices
                .Include(i => i.Patient)
                .Include(i => i.Promotion)
                .Where(i => i.DiscountAmount > 0)
                .OrderByDescending(i => i.DiscountAmount)
                .Select(i => new
                {
                    InvoiceNo = i.InvoiceNumber,
                    Date = i.InvoiceDate.ToString("MMM dd, yyyy"),
                    Patient = i.Patient != null ? i.Patient.FullName : "N/A",
                    PromoCode = i.Promotion != null ? i.Promotion.PromoCode : "Discount",
                    DiscountGranted = $"-₱{i.DiscountAmount:N2}",
                    NetTotal = $"₱{i.TotalAmount:N2}"
                })
                .ToList();

            decimal sum = db.BillingInvoices.Sum(i => (decimal?)i.DiscountAmount) ?? 0m;
            using var dlg = new DrilldownForm("Promo Discounts Impact Drilldown", "Showing all promotional invoice subsidies and campaign discounts", $"Total Discounts: -₱{sum:N2}", promos);
            dlg.ShowDialog();
        }

        private void GridSummary_CellDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            string sName = gridSummary.Rows[e.RowIndex].Cells["ServiceName"].Value?.ToString() ?? "";
            if (string.IsNullOrEmpty(sName)) return;

            using var db = DbContextFactory.Create();
            var cases = db.TreatmentRecords
                .Include(t => t.Patient)
                .Include(t => t.Dentist)
                .Include(t => t.DentalService)
                .Where(t => t.DentalService != null && t.DentalService.Name == sName)
                .OrderByDescending(t => t.TreatmentDate)
                .Select(t => new
                {
                    RecordNo = t.RecordNumber,
                    Date = t.TreatmentDate.ToString("MMM dd, yyyy"),
                    Patient = t.Patient != null ? t.Patient.FullName : "N/A",
                    Dentist = t.Dentist != null ? t.Dentist.FullName : "Dr. Smith",
                    ToothNo = t.ToothNumber != null ? $"#{t.ToothNumber}" : "Full Mouth",
                    Cost = $"₱{t.Cost:N2}",
                    Diagnosis = t.Diagnosis
                })
                .ToList();

            decimal sum = db.TreatmentRecords.Where(t => t.DentalService != null && t.DentalService.Name == sName).Sum(t => (decimal?)t.Cost) ?? 0m;
            using var dlg = new DrilldownForm($"Case Drilldown - '{sName}'", $"Showing all clinical treatment cases performed for {sName}", $"Total Revenue: ₱{sum:N2}", cases);
            dlg.ShowDialog();
        }

        private Panel CreateRetentionSummaryCard(DentalClinicSystem.Data.ApplicationDbContext db)
        {
            var pnl = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                Padding = new Padding(15),
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblHeader = new Label
            {
                Text = "Patient Retention & Practice Health",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(15, 15),
                AutoSize = true
            };

            int activePatients = db.Patients.Count(p => p.IsActive);
            int totalAppts = db.Appointments.Count();
            int completedAppts = db.Appointments.Count(a => a.Status == AppointmentStatus.Completed);
            double completionRate = totalAppts > 0 ? Math.Round((double)completedAppts / totalAppts * 100, 1) : 0;

            var lblStat1 = new Label { Text = $"• Active Patient Registry: {activePatients} Patients", Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), ForeColor = Color.FromArgb(2, 132, 199), Location = new Point(20, 50), AutoSize = true };
            var lblStat2 = new Label { Text = $"• Appointment Completion Rate: {completionRate}%", Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), ForeColor = Color.FromArgb(16, 185, 129), Location = new Point(20, 85), AutoSize = true };
            var lblStat3 = new Label { Text = $"• Total Completed Clinical Visits: {completedAppts}", Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), ForeColor = Color.FromArgb(139, 92, 246), Location = new Point(20, 120), AutoSize = true };
            var lblStat4 = new Label { Text = $"• Currency Standard: Philippine Peso (₱)", Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), ForeColor = Color.FromArgb(51, 65, 85), Location = new Point(20, 155), AutoSize = true };

            pnl.Controls.Add(lblHeader);
            pnl.Controls.Add(lblStat1);
            pnl.Controls.Add(lblStat2);
            pnl.Controls.Add(lblStat3);
            pnl.Controls.Add(lblStat4);

            return pnl;
        }
    }

    // ── Helper Models ──
    public class ChartCategoryItem
    {
        public string Name { get; set; } = string.Empty;
        public decimal Value { get; set; }
    }

    public class PromoImpactItem
    {
        public string PromoCode { get; set; } = string.Empty;
        public decimal Discount { get; set; }
        public decimal Revenue { get; set; }
    }

    // ── NATIVE GDI+ CHART CONTROL 1: LINE CHART (Monthly Revenue Trend) ──
    public class LineChartControl : Panel
    {
        private string title;
        private List<string> labels;
        private List<decimal> values;
        private bool isCurrency;

        public LineChartControl(string title, List<string> labels, List<decimal> values, bool isCurrency = true)
        {
            this.isCurrency = isCurrency;
            this.title = title;
            this.labels = labels;
            this.values = values;
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Margin = new Padding(4);
            this.BorderStyle = BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold);
            using var titleBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
            g.DrawString(title, titleFont, titleBrush, 12, 10);

            if (values == null || values.Count == 0) return;

            int leftMargin = 55;
            int rightMargin = 20;
            int topMargin = 40;
            int bottomMargin = 30;

            int chartWidth = this.Width - leftMargin - rightMargin;
            int chartHeight = this.Height - topMargin - bottomMargin;

            decimal maxVal = values.Max();
            if (maxVal == 0) maxVal = 1;

            using var gridPen = new Pen(Color.FromArgb(241, 245, 249), 1);
            using var labelFont = new Font("Segoe UI", 7.5F);
            using var labelBrush = new SolidBrush(Color.FromArgb(100, 116, 139));

            int gridSteps = 4;
            for (int i = 0; i <= gridSteps; i++)
            {
                int y = topMargin + (chartHeight * i / gridSteps);
                g.DrawLine(gridPen, leftMargin, y, this.Width - rightMargin, y);

                decimal valAtLine = maxVal * (gridSteps - i) / gridSteps;
                g.DrawString(isCurrency ? $"₱{valAtLine / 1000:N0}k" : $"{valAtLine:N0}", labelFont, labelBrush, 5, y - 6);
            }

            using var linePen = new Pen(Color.FromArgb(2, 132, 199), 3);
            using var pointBrush = new SolidBrush(Color.FromArgb(2, 132, 199));

            PointF[] points = new PointF[values.Count];
            for (int i = 0; i < values.Count; i++)
            {
                float x = leftMargin + (chartWidth * i / (float)Math.Max(1, values.Count - 1));
                float y = topMargin + chartHeight - (chartHeight * (float)(values[i] / maxVal));
                points[i] = new PointF(x, y);

                g.DrawString(labels[i], labelFont, labelBrush, x - 12, this.Height - bottomMargin + 5);
            }

            if (points.Length > 1)
            {
                g.DrawLines(linePen, points);
            }

            foreach (var pt in points)
            {
                g.FillEllipse(pointBrush, pt.X - 4, pt.Y - 4, 8, 8);
            }
        }
    }

    // ── NATIVE GDI+ CHART CONTROL 2: DOUGHNUT CHART (Category Revenue) ──
    public class DoughnutChartControl : Panel
    {
        private string title;
        private List<ChartCategoryItem> items;

        public DoughnutChartControl(string title, List<ChartCategoryItem> items)
        {
            this.title = title;
            this.items = items;
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Margin = new Padding(4);
            this.BorderStyle = BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold);
            using var titleBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
            g.DrawString(title, titleFont, titleBrush, 12, 10);

            if (items == null || items.Count == 0) return;

            decimal total = items.Sum(i => i.Value);
            if (total == 0) return;

            Color[] colors = new Color[] {
                Color.FromArgb(2, 132, 199), Color.FromArgb(16, 185, 129),
                Color.FromArgb(139, 92, 246), Color.FromArgb(245, 158, 11),
                Color.FromArgb(239, 68, 68), Color.FromArgb(14, 165, 233)
            };

            int outerDiam = 150;
            int innerDiam = 85;
            int rectX = 20;
            int rectY = 50;

            float startAngle = 0;
            int colorIdx = 0;

            foreach (var item in items)
            {
                float sweepAngle = (float)(item.Value / total * 360m);
                using var brush = new SolidBrush(colors[colorIdx % colors.Length]);
                g.FillPie(brush, rectX, rectY, outerDiam, outerDiam, startAngle, sweepAngle);
                startAngle += sweepAngle;
                colorIdx++;
            }

            using var holeBrush = new SolidBrush(Color.White);
            int holeX = rectX + (outerDiam - innerDiam) / 2;
            int holeY = rectY + (outerDiam - innerDiam) / 2;
            g.FillEllipse(holeBrush, holeX, holeY, innerDiam, innerDiam);

            using var legendFont = new Font("Segoe UI", 8F);
            int legendX = rectX + outerDiam + 20;
            int legendY = 45;

            colorIdx = 0;
            foreach (var item in items)
            {
                using var brush = new SolidBrush(colors[colorIdx % colors.Length]);
                using var textBrush = new SolidBrush(Color.FromArgb(51, 65, 85));

                g.FillRectangle(brush, legendX, legendY + 2, 12, 12);
                g.DrawString($"{item.Name}: ₱{item.Value:N0}", legendFont, textBrush, legendX + 18, legendY);

                legendY += 22;
                colorIdx++;
            }
        }
    }

    // ── NATIVE GDI+ CHART CONTROL 3: PIE CHART (Appointment Status) ──
    public class PieChartControl : Panel
    {
        private string title;
        private List<ChartCategoryItem> items;

        public PieChartControl(string title, List<ChartCategoryItem> items)
        {
            this.title = title;
            this.items = items;
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Margin = new Padding(4);
            this.BorderStyle = BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold);
            using var titleBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
            g.DrawString(title, titleFont, titleBrush, 12, 10);

            if (items == null || items.Count == 0) return;

            decimal total = items.Sum(i => i.Value);
            if (total == 0) return;

            Color[] colors = new Color[] {
                Color.FromArgb(59, 130, 246), Color.FromArgb(16, 185, 129),
                Color.FromArgb(139, 92, 246), Color.FromArgb(239, 68, 68), Color.FromArgb(100, 116, 139)
            };

            int outerDiam = 150;
            int rectX = 20;
            int rectY = 50;

            float startAngle = 0;
            int colorIdx = 0;

            foreach (var item in items)
            {
                float sweepAngle = (float)(item.Value / total * 360m);
                using var brush = new SolidBrush(colors[colorIdx % colors.Length]);
                g.FillPie(brush, rectX, rectY, outerDiam, outerDiam, startAngle, sweepAngle);
                startAngle += sweepAngle;
                colorIdx++;
            }

            using var legendFont = new Font("Segoe UI", 8F);
            int legendX = rectX + outerDiam + 20;
            int legendY = 45;

            colorIdx = 0;
            foreach (var item in items)
            {
                using var brush = new SolidBrush(colors[colorIdx % colors.Length]);
                using var textBrush = new SolidBrush(Color.FromArgb(51, 65, 85));

                g.FillRectangle(brush, legendX, legendY + 2, 12, 12);
                g.DrawString($"{item.Name} ({item.Value})", legendFont, textBrush, legendX + 18, legendY);

                legendY += 22;
                colorIdx++;
            }
        }
    }

    // ── NATIVE GDI+ CHART CONTROL 4: BAR CHART (Dentist Production) ──
    public class BarChartControl : Panel
    {
        private string title;
        private List<ChartCategoryItem> items;
        private Color barColor;
        private bool isCurrency;

        public BarChartControl(string title, List<ChartCategoryItem> items, Color barColor, bool isCurrency = true)
        {
            this.isCurrency = isCurrency;
            this.title = title;
            this.items = items;
            this.barColor = barColor;
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Margin = new Padding(4);
            this.BorderStyle = BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold);
            using var titleBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
            g.DrawString(title, titleFont, titleBrush, 12, 10);

            if (items == null || items.Count == 0) return;

            decimal maxVal = items.Max(i => i.Value);
            if (maxVal == 0) maxVal = 1;

            int leftMargin = 55;
            int rightMargin = 20;
            int topMargin = 40;
            int bottomMargin = 35;

            int chartWidth = this.Width - leftMargin - rightMargin;
            int chartHeight = this.Height - topMargin - bottomMargin;

            using var gridPen = new Pen(Color.FromArgb(241, 245, 249), 1);
            using var labelFont = new Font("Segoe UI", 7.5F);
            using var labelBrush = new SolidBrush(Color.FromArgb(100, 116, 139));
            using var barBrush = new SolidBrush(barColor);

            int gridSteps = 4;
            for (int i = 0; i <= gridSteps; i++)
            {
                int y = topMargin + (chartHeight * i / gridSteps);
                g.DrawLine(gridPen, leftMargin, y, this.Width - rightMargin, y);

                decimal valAtLine = maxVal * (gridSteps - i) / gridSteps;
                g.DrawString(isCurrency ? $"₱{valAtLine / 1000:N0}k" : $"{valAtLine:N0}", labelFont, labelBrush, 5, y - 6);
            }

            int barWidth = Math.Min(50, chartWidth / (items.Count * 2));
            int step = chartWidth / Math.Max(1, items.Count);

            for (int i = 0; i < items.Count; i++)
            {
                int x = leftMargin + (step * i) + (step - barWidth) / 2;
                int h = (int)(chartHeight * (float)(items[i].Value / maxVal));
                int y = topMargin + chartHeight - h;

                g.FillRectangle(barBrush, x, y, barWidth, h);

                g.DrawString(isCurrency ? $"₱{items[i].Value:N0}" : $"{items[i].Value:N0}", labelFont, labelBrush, x - 5, y - 16);
                g.DrawString(items[i].Name, labelFont, labelBrush, x, this.Height - bottomMargin + 5);
            }
        }
    }

    // ── NATIVE GDI+ CHART CONTROL 5: GROUPED BAR CHART (Promo Impact) ──
    public class PromoImpactChartControl : Panel
    {
        private string title;
        private List<PromoImpactItem> items;

        public PromoImpactChartControl(string title, List<PromoImpactItem> items)
        {
            this.title = title;
            this.items = items;
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Margin = new Padding(4);
            this.BorderStyle = BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold);
            using var titleBrush = new SolidBrush(Color.FromArgb(15, 23, 42));
            g.DrawString(title, titleFont, titleBrush, 12, 10);

            using var legendFont = new Font("Segoe UI", 7.5F);
            using var discBrush = new SolidBrush(Color.FromArgb(245, 158, 11));
            using var revBrush = new SolidBrush(Color.FromArgb(16, 185, 129));
            using var labelBrush = new SolidBrush(Color.FromArgb(100, 116, 139));

            g.FillRectangle(discBrush, 280, 12, 10, 10);
            g.DrawString("Discount Given", legendFont, labelBrush, 294, 10);

            g.FillRectangle(revBrush, 390, 12, 10, 10);
            g.DrawString("Revenue Generated", legendFont, labelBrush, 404, 10);

            if (items == null || items.Count == 0) return;

            decimal maxVal = items.Max(i => Math.Max(i.Discount, i.Revenue));
            if (maxVal == 0) maxVal = 1;

            int leftMargin = 55;
            int rightMargin = 20;
            int topMargin = 40;
            int bottomMargin = 35;

            int chartWidth = this.Width - leftMargin - rightMargin;
            int chartHeight = this.Height - topMargin - bottomMargin;

            using var gridPen = new Pen(Color.FromArgb(241, 245, 249), 1);
            int gridSteps = 4;
            for (int i = 0; i <= gridSteps; i++)
            {
                int y = topMargin + (chartHeight * i / gridSteps);
                g.DrawLine(gridPen, leftMargin, y, this.Width - rightMargin, y);

                decimal valAtLine = maxVal * (gridSteps - i) / gridSteps;
                g.DrawString($"₱{valAtLine / 1000:N0}k", legendFont, labelBrush, 5, y - 6);
            }

            int groupWidth = chartWidth / Math.Max(1, items.Count);
            int barWidth = Math.Min(22, groupWidth / 3);

            for (int i = 0; i < items.Count; i++)
            {
                int groupX = leftMargin + (groupWidth * i) + 15;

                int h1 = (int)(chartHeight * (float)(items[i].Discount / maxVal));
                int y1 = topMargin + chartHeight - h1;
                g.FillRectangle(discBrush, groupX, y1, barWidth, h1);

                int h2 = (int)(chartHeight * (float)(items[i].Revenue / maxVal));
                int y2 = topMargin + chartHeight - h2;
                g.FillRectangle(revBrush, groupX + barWidth + 4, y2, barWidth, h2);

                g.DrawString(items[i].PromoCode, legendFont, labelBrush, groupX, this.Height - bottomMargin + 5);
            }
        }
    }
}
