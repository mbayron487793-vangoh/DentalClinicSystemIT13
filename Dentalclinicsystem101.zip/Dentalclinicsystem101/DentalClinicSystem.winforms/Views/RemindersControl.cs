using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class RemindersControl : UserControl
    {
        private DataGridView gridReminders = null!;
        private TextBox txtSearch = null!;
        private ComboBox cmbChannelFilter = null!;

        public RemindersControl()
        {
            InitializeComponent();
            LoadReminders();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Send Appointment Reminders (Phone & Email Notification System)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Automated customer recall notifications: Inform patients of upcoming appointments via Phone Number (SMS) or Email",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(160, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadReminders();

            var lblChan = new Label { Text = "Channel:", Location = new Point(235, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbChannelFilter = new ComboBox { Location = new Point(295, 11), Size = new Size(110, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbChannelFilter.Items.AddRange(new object[] { "All", "SMS", "Email" });
            cmbChannelFilter.SelectedIndex = 0;
            cmbChannelFilter.SelectedIndexChanged += (s, e) => LoadReminders();

            var btnSendSingle = new Button
            {
                Text = "Notify Selected (Phone / Email)",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(415, 9),
                Size = new Size(210, 30),
                Cursor = Cursors.Hand
            };
            btnSendSingle.FlatAppearance.BorderSize = 0;
            btnSendSingle.Click += (s, e) => ShowSendReminderDialog();

            var btnSendBatch = new Button
            {
                Text = "Send All Pending Reminders",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(635, 9),
                Size = new Size(210, 30),
                Cursor = Cursors.Hand
            };
            btnSendBatch.FlatAppearance.BorderSize = 0;
            btnSendBatch.Click += (s, e) => SendAllPendingReminders();

            var btnDelete = new Button
            {
                Text = "Delete Log",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(855, 9),
                Size = new Size(100, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedReminder();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblChan, cmbChannelFilter, btnSendSingle, btnSendBatch, btnDelete });

            gridReminders = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridReminders.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridReminders.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridReminders.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridReminders.EnableHeadersVisualStyles = false;
            gridReminders.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridReminders.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridReminders });
        }

        private void LoadReminders()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();
                string channel = cmbChannelFilter.SelectedItem?.ToString() ?? "All";

                var query = db.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Dentist)
                    .Include(a => a.DentalService)
                    .Where(a => a.Status == AppointmentStatus.Scheduled || a.Status == AppointmentStatus.Confirmed)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(a => a.AppointmentNumber.ToLower().Contains(search) ||
                                             (a.Patient != null && (a.Patient.FirstName.ToLower().Contains(search) || a.Patient.LastName.ToLower().Contains(search) || a.Patient.Phone.Contains(search))));
                }

                var list = query
                    .OrderBy(a => a.AppointmentDate)
                    .Take(120)
                    .ToList()
                    .Select(a => new
                    {
                        Id = a.Id,
                        ApptNumber = a.AppointmentNumber,
                        DateTime = $"{a.AppointmentDate:yyyy-MM-dd} at {a.StartTime}",
                        Patient = a.Patient != null ? $"{a.Patient.FirstName} {a.Patient.LastName}" : "N/A",
                        Phone = a.Patient?.Phone ?? "-",
                        Email = a.Patient?.Email ?? "-",
                        Dentist = a.Dentist?.FullName ?? "Dr. Alexander Smith",
                        Service = a.DentalService?.Name ?? "Dental Service",
                        ReminderStatus = a.ReminderSent ? $"Dispatched ({a.ReminderSentAt:MMM dd hh:mm tt})" : "Pending Dispatch",
                        NotificationChannel = !string.IsNullOrEmpty(a.Patient?.Email) ? "SMS & Email" : "SMS Only"
                    })
                    .ToList();

                gridReminders.DataSource = list;
                if (gridReminders.Columns["Id"] != null) gridReminders.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowSendReminderDialog()
        {
            if (gridReminders.SelectedRows.Count == 0 || gridReminders.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Please select an appointment from the table to dispatch a reminder.", "Select Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int apptId = Convert.ToInt32(gridReminders.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var appt = db.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Dentist)
                .Include(a => a.DentalService)
                .FirstOrDefault(a => a.Id == apptId);

            if (appt == null) return;

            using var dlg = new Form
            {
                Text = $"Dispatch Reminder - Appointment #{appt.AppointmentNumber}",
                Size = new Size(500, 440),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblHeader = new Label
            {
                Text = $"Patient: {appt.Patient?.FullName}\nDate: {appt.AppointmentDate:MMMM dd, yyyy} at {appt.StartTime}",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                Size = new Size(440, 40)
            };

            var lblChan = new Label { Text = "Notification Medium (Phone / Email):", Location = new Point(20, 60), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbChan = new ComboBox { Location = new Point(20, 82), Size = new Size(440, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbChan.Items.AddRange(new object[] { $"Phone SMS ({appt.Patient?.Phone})", $"Email ({appt.Patient?.Email})", "Both Phone SMS & Email" });
            cmbChan.SelectedIndex = 0;

            var lblRecipient = new Label { Text = "Verified Recipient Contact:", Location = new Point(20, 120), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtRecipient = new TextBox { Location = new Point(20, 140), Size = new Size(440, 26), Text = appt.Patient?.Phone ?? "", Font = new Font("Segoe UI", 9.5F) };

            cmbChan.SelectedIndexChanged += (s, e) =>
            {
                int sel = cmbChan.SelectedIndex;
                if (sel == 0) txtRecipient.Text = appt.Patient?.Phone ?? "";
                else if (sel == 1) txtRecipient.Text = appt.Patient?.Email ?? "";
                else txtRecipient.Text = $"{appt.Patient?.Phone} / {appt.Patient?.Email}";
            };

            var lblMsg = new Label { Text = "Appointment Reminder Message:", Location = new Point(20, 175), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtMsg = new TextBox
            {
                Location = new Point(20, 195),
                Size = new Size(440, 120),
                Multiline = true,
                Font = new Font("Segoe UI", 9.5F),
                Text = $"Hello {appt.Patient?.FirstName}, this is a reminder from DentalCare Clinic that you have an appointment with {appt.Dentist?.FullName ?? "your dentist"} for {appt.DentalService?.Name ?? "clinical procedure"} on {appt.AppointmentDate:dddd, MMMM dd} at {appt.StartTime}. Please arrive 10 mins early. Reply to confirm or call us."
            };

            var btnSend = new Button
            {
                Text = "Dispatch Reminder Now",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 335),
                Size = new Size(440, 42),
                DialogResult = DialogResult.OK
            };
            btnSend.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblHeader, lblChan, cmbChan, lblRecipient, txtRecipient, lblMsg, txtMsg, btnSend });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                appt.ReminderSent = true;
                appt.ReminderSentAt = DateTime.UtcNow;

                var reminderRecord = new AppointmentReminder
                {
                    AppointmentId = appt.Id,
                    PatientId = appt.PatientId,
                    Channel = cmbChan.SelectedIndex == 1 ? ReminderChannel.Email : ReminderChannel.SMS,
                    RecipientContact = txtRecipient.Text.Trim(),
                    MessageContent = txtMsg.Text.Trim(),
                    ScheduledTime = DateTime.UtcNow,
                    SentTime = DateTime.UtcNow,
                    Status = ReminderStatus.Delivered,
                    DeliveryNote = $"Reminder dispatched via {cmbChan.SelectedItem}"
                };

                db.AppointmentReminders.Add(reminderRecord);
                db.SaveChanges();

                MessageBox.Show($"Appointment reminder successfully sent to {appt.Patient?.FullName} via {cmbChan.SelectedItem}!\nContact: {txtRecipient.Text}", "Reminder Dispatched", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadReminders();
            }
        }

        private void SendAllPendingReminders()
        {
            using var db = DbContextFactory.Create();
            var pending = db.Appointments
                .Include(a => a.Patient)
                .Where(a => !a.ReminderSent && (a.Status == AppointmentStatus.Scheduled || a.Status == AppointmentStatus.Confirmed))
                .ToList();

            if (pending.Count == 0)
            {
                MessageBox.Show("All upcoming appointments have already received reminders!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            foreach (var a in pending)
            {
                a.ReminderSent = true;
                a.ReminderSentAt = DateTime.UtcNow;
            }

            db.SaveChanges();
            MessageBox.Show($"Batch dispatch complete! {pending.Count} appointment reminders sent via Phone SMS & Email.", "Batch Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadReminders();
        }

        private void DeleteSelectedReminder()
        {
            if (gridReminders.SelectedRows.Count == 0 || gridReminders.SelectedRows[0].Cells["Id"].Value == null) return;
            int apptId = Convert.ToInt32(gridReminders.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var appt = db.Appointments.FirstOrDefault(a => a.Id == apptId);
            if (appt != null)
            {
                appt.ReminderSent = false;
                appt.ReminderSentAt = null;
                db.SaveChanges();
                LoadReminders();
                MessageBox.Show("Reminder flag reset.", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
