using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class SubscriptionsControl : UserControl
    {
        private DataGridView gridSubs = null!;
        private ComboBox cmbTierFilter = null!;

        public SubscriptionsControl()
        {
            InitializeComponent();
            LoadSubscriptions();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Subscriptions & Tier Access Management",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Super Admin subscription plans, client tier assignments (Tenant A, B, C), billing status, and client notifications (Phone / Email)",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblTier = new Label { Text = "Filter Tier:", Location = new Point(12, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbTierFilter = new ComboBox { Location = new Point(85, 11), Size = new Size(140, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbTierFilter.Items.AddRange(new object[] { "All Tiers", "Tenant A", "Tenant B", "Tenant C" });
            cmbTierFilter.SelectedIndex = 0;
            cmbTierFilter.SelectedIndexChanged += (s, e) => LoadSubscriptions();

            var btnAdd = new Button
            {
                Text = "+ New Subscription",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(240, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowSubscriptionDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Subscription",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(400, 9),
                Size = new Size(130, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedSubscription();

            var btnInform = new Button
            {
                Text = "Inform Client (Phone / Email)",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(540, 9),
                Size = new Size(210, 30),
                Cursor = Cursors.Hand
            };
            btnInform.FlatAppearance.BorderSize = 0;
            btnInform.Click += (s, e) => InformSelectedClient();

            var btnDelete = new Button
            {
                Text = "Cancel / Delete",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(760, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedSubscription();

            filterPanel.Controls.AddRange(new Control[] { lblTier, cmbTierFilter, btnAdd, btnEdit, btnInform, btnDelete });

            // Data Grid
            gridSubs = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridSubs.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridSubs.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridSubs.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridSubs.EnableHeadersVisualStyles = false;
            gridSubs.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridSubs.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridSubs });
        }

        private void LoadSubscriptions()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string tierFilter = cmbTierFilter.SelectedItem?.ToString() ?? "All Tiers";

                var query = db.Subscriptions.AsQueryable();
                if (tierFilter != "All Tiers")
                {
                    query = query.Where(s => s.SubscriptionTier == tierFilter);
                }

                var list = query
                    .OrderBy(s => s.SubscriptionTier)
                    .ThenBy(s => s.TenantName)
                    .Select(s => new
                    {
                        Id = s.Id,
                        Tenant = s.TenantName,
                        Tier = s.SubscriptionTier,
                        Plan = s.PlanName,
                        MonthlyRate = $"₱{s.MonthlyPrice:N2}",
                        Cycle = s.BillingCycle,
                        Status = s.Status,
                        ValidUntil = s.EndDate.ToString("yyyy-MM-dd"),
                        Phone = s.ContactPhone,
                        Email = s.ContactEmail,
                        Modules = s.AllowedModulesSummary
                    })
                    .ToList();

                gridSubs.DataSource = list;
                if (gridSubs.Columns["Id"] != null) gridSubs.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowSubscriptionDialog(TenantSubscription? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New Tenant Subscription" : $"Edit Subscription: {existing?.TenantName}",
                Size = new Size(480, 520),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblTenant = new Label { Text = "Tenant Organization:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtTenant = new TextBox { Location = new Point(20, 35), Size = new Size(420, 26), Text = existing?.TenantName ?? "Tenant A Practice", Font = new Font("Segoe UI", 9.5F) };

            var lblTier = new Label { Text = "Subscription Tier Plan:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbTier = new ComboBox { Location = new Point(20, 90), Size = new Size(420, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbTier.Items.AddRange(new object[] { "Tenant A", "Tenant B", "Tenant C" });
            cmbTier.SelectedItem = existing?.SubscriptionTier ?? "Tenant A";

            var lblPlan = new Label { Text = "Plan Description / Name:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPlan = new TextBox { Location = new Point(20, 145), Size = new Size(420, 26), Text = existing?.PlanName ?? "Tier A Core Package", Font = new Font("Segoe UI", 9.5F) };

            var lblPrice = new Label { Text = "Monthly Fee (₱):", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPrice = new TextBox { Location = new Point(20, 200), Size = new Size(420, 26), Text = existing != null ? existing.MonthlyPrice.ToString("N2") : "4999.00", Font = new Font("Segoe UI", 9.5F) };

            var lblPhone = new Label { Text = "Client Phone (SMS):", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPhone = new TextBox { Location = new Point(20, 255), Size = new Size(420, 26), Text = existing?.ContactPhone ?? "+1 (555) 019-1001", Font = new Font("Segoe UI", 9.5F) };

            var lblEmail = new Label { Text = "Client Email:", Location = new Point(20, 290), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtEmail = new TextBox { Location = new Point(20, 310), Size = new Size(420, 26), Text = existing?.ContactEmail ?? "tenanta@dentalclinic.com", Font = new Font("Segoe UI", 9.5F) };

            var lblModules = new Label { Text = "Allowed Subscription Modules:", Location = new Point(20, 345), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtModules = new TextBox
            {
                Location = new Point(20, 365),
                Size = new Size(420, 26),
                Font = new Font("Segoe UI", 9F),
                Text = existing?.AllowedModulesSummary ?? "Main transaction, Data Collection",
                ReadOnly = true
            };

            cmbTier.SelectedIndexChanged += (s, e) =>
            {
                string sel = cmbTier.SelectedItem?.ToString() ?? "Tenant A";
                if (sel == "Tenant A")
                {
                    txtModules.Text = "Main transaction, Data Collection";
                    txtPlan.Text = "Tenant A - Core Transactions & Data Tier";
                    txtPrice.Text = "4999.00";
                }
                else if (sel == "Tenant B")
                {
                    txtModules.Text = "Business Intelligence, Actions";
                    txtPlan.Text = "Tenant B - Business Intelligence & Action Tier";
                    txtPrice.Text = "8999.00";
                }
                else
                {
                    txtModules.Text = "Branching, Business Intelligence, Actions";
                    txtPlan.Text = "Tenant C - Enterprise Branching & BI Tier";
                    txtPrice.Text = "14999.00";
                }
            };

            var btnSave = new Button
            {
                Text = isNew ? "Save Subscription" : "Update Subscription",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 420),
                Size = new Size(420, 40),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblTenant, txtTenant, lblTier, cmbTier, lblPlan, txtPlan, lblPrice, txtPrice, lblPhone, txtPhone, lblEmail, txtEmail, lblModules, txtModules, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && decimal.TryParse(txtPrice.Text, out decimal price))
            {
                using var db = DbContextFactory.Create();
                string tier = cmbTier.SelectedItem?.ToString() ?? "Tenant A";
                if (isNew)
                {
                    db.Subscriptions.Add(new TenantSubscription
                    {
                        TenantName = txtTenant.Text.Trim(),
                        SubscriptionTier = tier,
                        PlanName = txtPlan.Text.Trim(),
                        MonthlyPrice = price,
                        BillingCycle = "Monthly",
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow.AddYears(1),
                        Status = "Active",
                        ContactPhone = txtPhone.Text.Trim(),
                        ContactEmail = txtEmail.Text.Trim(),
                        AllowedModulesSummary = txtModules.Text.Trim()
                    });
                }
                else
                {
                    var sub = db.Subscriptions.FirstOrDefault(x => x.Id == existing!.Id);
                    if (sub != null)
                    {
                        sub.TenantName = txtTenant.Text.Trim();
                        sub.SubscriptionTier = tier;
                        sub.PlanName = txtPlan.Text.Trim();
                        sub.MonthlyPrice = price;
                        sub.ContactPhone = txtPhone.Text.Trim();
                        sub.ContactEmail = txtEmail.Text.Trim();
                        sub.AllowedModulesSummary = txtModules.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadSubscriptions();
            }
        }

        private void EditSelectedSubscription()
        {
            if (gridSubs.SelectedRows.Count == 0 || gridSubs.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridSubs.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var sub = db.Subscriptions.FirstOrDefault(x => x.Id == id);
            if (sub != null)
            {
                ShowSubscriptionDialog(sub);
            }
        }

        private void InformSelectedClient()
        {
            if (gridSubs.SelectedRows.Count == 0 || gridSubs.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridSubs.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var sub = db.Subscriptions.FirstOrDefault(x => x.Id == id);
            if (sub == null) return;

            using var dlg = new Form
            {
                Text = $"Dispatch Subscription Notice - {sub.TenantName}",
                Size = new Size(480, 420),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblHeader = new Label
            {
                Text = $"Inform Client: {sub.TenantName} ({sub.SubscriptionTier})",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblChannel = new Label { Text = "Notification Method (Phone / Email):", Location = new Point(20, 50), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbChannel = new ComboBox { Location = new Point(20, 72), Size = new Size(420, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbChannel.Items.AddRange(new object[] { $"Phone SMS ({sub.ContactPhone})", $"Email ({sub.ContactEmail})", "Both Phone SMS & Email" });
            cmbChannel.SelectedIndex = 0;

            var lblMsg = new Label { Text = "Subscription Message / Notice:", Location = new Point(20, 110), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtMsg = new TextBox
            {
                Location = new Point(20, 132),
                Size = new Size(420, 130),
                Multiline = true,
                Font = new Font("Segoe UI", 9.5F),
                Text = $"Notice to {sub.TenantName}: Your {sub.PlanName} subscription (Monthly fee: ₱{sub.MonthlyPrice:N2}) is currently {sub.Status}. Modules included: {sub.AllowedModulesSummary}. Renewal date: {sub.EndDate:yyyy-MM-dd}. Contact support@dentalcare.com for upgrades."
            };

            var btnSend = new Button
            {
                Text = "Dispatch Subscription Notice",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 290),
                Size = new Size(420, 42),
                DialogResult = DialogResult.OK
            };
            btnSend.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblHeader, lblChannel, cmbChannel, lblMsg, txtMsg, btnSend });

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string channel = cmbChannel.SelectedItem?.ToString() ?? "Phone SMS";
                sub.LastInformedDate = DateTime.UtcNow;
                sub.LastNotificationStatus = $"Dispatched via {channel}";

                db.AuditLogs.Add(new AuditLog
                {
                    UserName = Session.CurrentUser?.Email ?? "superadmin@dentalclinic.com",
                    Module = "Subscriptions",
                    Action = "SubscriptionInformed",
                    Details = $"Sent to {sub.TenantName} via {channel}: {txtMsg.Text.Trim()}",
                    Timestamp = DateTime.UtcNow
                });
                db.SaveChanges();

                MessageBox.Show($"Subscription notice dispatched successfully to {sub.TenantName} via {channel}!", "Tenant Informed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadSubscriptions();
            }
        }

        private void DeleteSelectedSubscription()
        {
            if (gridSubs.SelectedRows.Count == 0 || gridSubs.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridSubs.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Cancel and delete this subscription?", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var sub = db.Subscriptions.FirstOrDefault(x => x.Id == id);
                if (sub != null)
                {
                    db.Subscriptions.Remove(sub);
                    db.SaveChanges();
                    LoadSubscriptions();
                }
            }
        }
    }
}
