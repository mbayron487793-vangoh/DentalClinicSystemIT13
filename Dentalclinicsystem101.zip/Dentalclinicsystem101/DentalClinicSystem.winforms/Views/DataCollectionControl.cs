using System;
using System.Drawing;
using System.Windows.Forms;

namespace DentalClinicWinForms.Views
{
    public class DataCollectionControl : UserControl
    {
        private Panel tabHeaderPanel = null!;
        private Panel dataContentPanel = null!;
        private Button btnTabPatients = null!;
        private Button btnTabServices = null!;

        public DataCollectionControl()
        {
            InitializeComponent();
            SwitchTab(0);
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(15);

            var topPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 85,
                BackColor = Color.Transparent
            };

            var lblTitle = new Label
            {
                Text = "Clinical Data Collection (Tenant A Subscription)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(5, 5),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Comprehensive data intake center: Patient Registrations, Medical Histories, and Dental Service Catalog",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(7, 35),
                AutoSize = true
            };

            tabHeaderPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 36,
                BackColor = Color.Transparent
            };

            btnTabPatients = CreateTabButton(" 1. Patient Directory & Medical History", 0);
            btnTabServices = CreateTabButton(" 2. Dental Services & Price Catalog", 1);

            btnTabPatients.Location = new Point(5, 2);
            btnTabServices.Location = new Point(275, 2);

            tabHeaderPanel.Controls.AddRange(new Control[] { btnTabPatients, btnTabServices });

            topPanel.Controls.Add(lblTitle);
            topPanel.Controls.Add(lblSub);
            topPanel.Controls.Add(tabHeaderPanel);

            dataContentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };

            this.Controls.Add(dataContentPanel);
            this.Controls.Add(topPanel);
        }

        private Button CreateTabButton(string text, int tabIndex)
        {
            var btn = new Button
            {
                Text = text,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Size = new Size(260, 32),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) => SwitchTab(tabIndex);
            return btn;
        }

        private void SwitchTab(int tabIndex)
        {
            btnTabPatients.BackColor = Color.FromArgb(226, 232, 240);
            btnTabPatients.ForeColor = Color.FromArgb(71, 85, 105);
            btnTabServices.BackColor = Color.FromArgb(226, 232, 240);
            btnTabServices.ForeColor = Color.FromArgb(71, 85, 105);

            dataContentPanel.Controls.Clear();

            Control activeControl;
            if (tabIndex == 0)
            {
                btnTabPatients.BackColor = Color.FromArgb(2, 132, 199);
                btnTabPatients.ForeColor = Color.White;
                activeControl = new PatientsControl();
            }
            else
            {
                btnTabServices.BackColor = Color.FromArgb(139, 92, 246);
                btnTabServices.ForeColor = Color.White;
                activeControl = new ServicesControl();
            }

            activeControl.Dock = DockStyle.Fill;
            dataContentPanel.Controls.Add(activeControl);
        }
    }
}
