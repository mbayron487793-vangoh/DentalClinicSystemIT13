using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class ServicesControl : UserControl
    {
        private DataGridView gridServices = null!;
        private TextBox txtSearch = null!;
        private ComboBox cmbCategoryFilter = null!;

        public ServicesControl()
        {
            InitializeComponent();
            LoadServices();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);

            var lblTitle = new Label
            {
                Text = "Manage Dental Services & Clinical Fee Schedule",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Master catalog of clinical procedures, standard price lists, duration estimates, and category schedules",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Toolbar
            var filterPanel = new Panel
            {
                Location = new Point(20, 80),
                Size = new Size(1120, 50),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblSearch = new Label { Text = "Search:", Location = new Point(10, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            txtSearch = new TextBox { Location = new Point(65, 11), Size = new Size(160, 26), Font = new Font("Segoe UI", 9.5F) };
            txtSearch.TextChanged += (s, e) => LoadServices();

            var lblCat = new Label { Text = "Category:", Location = new Point(240, 14), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            cmbCategoryFilter = new ComboBox { Location = new Point(310, 11), Size = new Size(130, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9F) };
            cmbCategoryFilter.Items.AddRange(new object[] { "All", "Preventive", "Restorative", "Periodontics", "Endodontics", "Surgery", "Cosmetic", "Orthodontics", "General" });
            cmbCategoryFilter.SelectedIndex = 0;
            cmbCategoryFilter.SelectedIndexChanged += (s, e) => LoadServices();

            var btnAdd = new Button
            {
                Text = "+ Add Service",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(455, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => ShowServiceDialog(null);

            var btnEdit = new Button
            {
                Text = "Edit Service",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(585, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnEdit.FlatAppearance.BorderSize = 0;
            btnEdit.Click += (s, e) => EditSelectedService();

            var btnToggle = new Button
            {
                Text = "Toggle Active",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(705, 9),
                Size = new Size(110, 30),
                Cursor = Cursors.Hand
            };
            btnToggle.FlatAppearance.BorderSize = 0;
            btnToggle.Click += (s, e) => ToggleSelectedService();

            var btnDelete = new Button
            {
                Text = "Delete Service",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(825, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) => DeleteSelectedService();

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblCat, cmbCategoryFilter, btnAdd, btnEdit, btnToggle, btnDelete });

            gridServices = new DataGridView
            {
                Location = new Point(20, 140),
                Size = new Size(1120, 500),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridServices.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridServices.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridServices.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridServices.EnableHeadersVisualStyles = false;
            gridServices.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridServices.RowTemplate.Height = 32;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, filterPanel, gridServices });
        }

        private void LoadServices()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string search = txtSearch.Text.Trim().ToLower();
                string category = cmbCategoryFilter.SelectedItem?.ToString() ?? "All";

                var query = db.DentalServices.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(s => s.Name.ToLower().Contains(search) || s.ServiceCode.ToLower().Contains(search) || s.Category.ToLower().Contains(search));
                }

                if (category != "All")
                {
                    query = query.Where(s => s.Category == category);
                }

                var list = query
                    .OrderBy(s => s.Category)
                    .ThenBy(s => s.Name)
                    .Select(s => new
                    {
                        Id = s.Id,
                        Code = s.ServiceCode,
                        Name = s.Name,
                        Category = s.Category,
                        Price = $"₱{s.StandardPrice:N2}",
                        Duration = $"{s.EstimatedDurationMinutes} mins",
                        Description = s.Description,
                        Status = s.IsActive ? "Active" : "Disabled"
                    })
                    .ToList();

                gridServices.DataSource = list;
                if (gridServices.Columns["Id"] != null) gridServices.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowServiceDialog(DentalService? existing)
        {
            bool isNew = existing == null;
            using var dlg = new Form
            {
                Text = isNew ? "Add New Dental Service" : $"Edit Service: {existing?.Name}",
                Size = new Size(460, 480),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblCode = new Label { Text = "Service Code:", Location = new Point(20, 15), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtCode = new TextBox { Location = new Point(20, 35), Size = new Size(400, 26), Text = existing?.ServiceCode ?? $"DNT-{new Random().Next(100, 999)}", Font = new Font("Segoe UI", 9.5F) };

            var lblName = new Label { Text = "Service / Procedure Name:", Location = new Point(20, 70), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtName = new TextBox { Location = new Point(20, 90), Size = new Size(400, 26), Text = existing?.Name ?? "", Font = new Font("Segoe UI", 9.5F) };

            var lblCat = new Label { Text = "Category:", Location = new Point(20, 125), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbCat = new ComboBox { Location = new Point(20, 145), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9.5F) };
            cmbCat.Items.AddRange(new object[] { "Preventive", "Restorative", "Periodontics", "Endodontics", "Surgery", "Cosmetic", "Orthodontics", "General" });
            cmbCat.SelectedItem = existing?.Category ?? "Preventive";

            var lblPrice = new Label { Text = "Standard Price (₱):", Location = new Point(20, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtPrice = new TextBox { Location = new Point(20, 200), Size = new Size(190, 26), Text = existing != null ? existing.StandardPrice.ToString("N2") : "150.00", Font = new Font("Segoe UI", 9.5F) };

            var lblDur = new Label { Text = "Duration (Minutes):", Location = new Point(230, 180), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDur = new TextBox { Location = new Point(230, 200), Size = new Size(190, 26), Text = existing != null ? existing.EstimatedDurationMinutes.ToString() : "45", Font = new Font("Segoe UI", 9.5F) };

            var lblDesc = new Label { Text = "Clinical Description:", Location = new Point(20, 235), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDesc = new TextBox { Location = new Point(20, 255), Size = new Size(400, 70), Multiline = true, Text = existing?.Description ?? "Standard clinical protocol and evaluation.", Font = new Font("Segoe UI", 9.5F) };

            var btnSave = new Button
            {
                Text = isNew ? "Create Service" : "Save Changes",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 350),
                Size = new Size(400, 42),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblCode, txtCode, lblName, txtName, lblCat, cmbCat, lblPrice, txtPrice, lblDur, txtDur, lblDesc, txtDesc, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtName.Text))
            {
                decimal.TryParse(txtPrice.Text, out decimal price);
                int.TryParse(txtDur.Text, out int dur);

                using var db = DbContextFactory.Create();
                if (isNew)
                {
                    db.DentalServices.Add(new DentalService
                    {
                        ServiceCode = txtCode.Text.Trim(),
                        Name = txtName.Text.Trim(),
                        Category = cmbCat.SelectedItem?.ToString() ?? "Preventive",
                        StandardPrice = price > 0 ? price : 100,
                        EstimatedDurationMinutes = dur > 0 ? dur : 30,
                        Description = txtDesc.Text.Trim(),
                        IsActive = true
                    });
                }
                else
                {
                    var s = db.DentalServices.FirstOrDefault(x => x.Id == existing!.Id);
                    if (s != null)
                    {
                        s.ServiceCode = txtCode.Text.Trim();
                        s.Name = txtName.Text.Trim();
                        s.Category = cmbCat.SelectedItem?.ToString() ?? "Preventive";
                        s.StandardPrice = price;
                        s.EstimatedDurationMinutes = dur;
                        s.Description = txtDesc.Text.Trim();
                    }
                }
                db.SaveChanges();
                LoadServices();
            }
        }

        private void EditSelectedService()
        {
            if (gridServices.SelectedRows.Count == 0 || gridServices.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridServices.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var s = db.DentalServices.FirstOrDefault(x => x.Id == id);
            if (s != null)
            {
                ShowServiceDialog(s);
            }
        }

        private void ToggleSelectedService()
        {
            if (gridServices.SelectedRows.Count == 0 || gridServices.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridServices.SelectedRows[0].Cells["Id"].Value);

            using var db = DbContextFactory.Create();
            var s = db.DentalServices.FirstOrDefault(x => x.Id == id);
            if (s != null)
            {
                s.IsActive = !s.IsActive;
                db.SaveChanges();
                LoadServices();
                MessageBox.Show($"Service {s.Name} is now {(s.IsActive ? "Active" : "Disabled")}.", "Status Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteSelectedService()
        {
            if (gridServices.SelectedRows.Count == 0 || gridServices.SelectedRows[0].Cells["Id"].Value == null) return;
            int id = Convert.ToInt32(gridServices.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Are you sure you want to delete this dental service?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var s = db.DentalServices.FirstOrDefault(x => x.Id == id);
                if (s != null)
                {
                    db.DentalServices.Remove(s);
                    db.SaveChanges();
                    LoadServices();
                }
            }
        }
    }
}
