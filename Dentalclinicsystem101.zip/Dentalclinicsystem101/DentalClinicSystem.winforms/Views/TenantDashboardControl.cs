using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Data;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    /// <summary>
    /// Dashboard shown to the Super Admin, every Tenant (A/B/C) and the clinic Admin.
    /// Contains every report as a graph: financial, clinical and (for Super Admin) platform / tenant reports.
    /// </summary>
    public class TenantDashboardControl : UserControl
    {
        private const int ChartHeight = 280;

        private FlowLayoutPanel root = null!;
        private readonly List<Control> fullWidthItems = new();
        private Label lblScope = null!;

        public TenantDashboardControl()
        {
            InitializeComponent();
            LoadDashboard();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(15);
            this.AutoScroll = true;

            root = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false
            };
            this.Controls.Add(root);

            this.Resize += (s, e) => ResizeItems();
        }

        private void ResizeItems()
        {
            int w = Math.Max(700, this.ClientSize.Width - this.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth - 4);
            foreach (var c in fullWidthItems) c.Width = w;
        }

        // ───────────────────────── helpers ─────────────────────────

        private T AddFull<T>(T c) where T : Control
        {
            root.Controls.Add(c);
            fullWidthItems.Add(c);
            return c;
        }

        private void AddHeading(string text, string? sub = null)
        {
            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Margin = new Padding(10, 12, 10, 4),
                AutoSize = true
            };
            root.Controls.Add(lbl);
            if (sub != null)
            {
                root.Controls.Add(new Label
                {
                    Text = sub,
                    Font = new Font("Segoe UI", 8.5F),
                    ForeColor = Color.FromArgb(100, 116, 139),
                    Margin = new Padding(12, 0, 10, 6),
                    AutoSize = true
                });
            }
        }

        private TableLayoutPanel MakeGrid(int columns, int rows, int rowHeight)
        {
            var t = new TableLayoutPanel
            {
                ColumnCount = columns,
                RowCount = rows,
                Height = rows * rowHeight,
                Margin = new Padding(10, 0, 10, 10)
            };
            for (int c = 0; c < columns; c++) t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / columns));
            for (int r = 0; r < rows; r++) t.RowStyles.Add(new RowStyle(SizeType.Absolute, rowHeight));
            return AddFull(t);
        }

        private void AddKpiRow(params (string title, string value, Color color)[] cards)
        {
            int rows = (int)Math.Ceiling(cards.Length / 4.0);
            var grid = MakeGrid(4, rows, 84);
            for (int i = 0; i < cards.Length; i++)
                grid.Controls.Add(CreateKpiCard(cards[i].title, cards[i].value, cards[i].color), i % 4, i / 4);
        }

        private void AddCharts(params Control[] charts)
        {
            int rows = (int)Math.Ceiling(charts.Length / 2.0);
            var grid = MakeGrid(2, rows, ChartHeight);
            for (int i = 0; i < charts.Length; i++)
                grid.Controls.Add(charts[i], i % 2, i / 2);
        }

        private static Panel CreateKpiCard(string title, string value, Color accent)
        {
            var pnl = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                BorderStyle = BorderStyle.FixedSingle
            };
            var bar = new Panel { Dock = DockStyle.Left, Width = 5, BackColor = accent };
            var lblT = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(14, 12),
                AutoSize = true
            };
            var lblV = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = accent,
                Location = new Point(12, 36),
                AutoSize = true
            };
            pnl.Controls.Add(bar);
            pnl.Controls.Add(lblT);
            pnl.Controls.Add(lblV);
            return pnl;
        }

        private static string Short(string s, int max = 12) => s.Length <= max ? s : s.Substring(0, max - 1) + "…";

        // ───────────────────────── data & layout ─────────────────────────

        private void LoadDashboard()
        {
            try
            {
                using var db = DbContextFactory.Create();
                BuildHeader(db);

                if (Session.IsSuperAdmin) BuildPlatformSection(db);
                BuildFinancialSection(db);
                BuildClinicalSection(db);
                ResizeItems();
            }
            catch (Exception ex)
            {
                root.Controls.Add(new Label
                {
                    Text = "Unable to load dashboard: " + ex.Message,
                    ForeColor = Color.FromArgb(185, 28, 28),
                    AutoSize = true,
                    Margin = new Padding(12)
                });
            }
        }

        private void BuildHeader(ApplicationDbContext db)
        {
            string scope;
            string who;
            if (Session.IsSuperAdmin)
            {
                scope = "Platform dashboard: all tenants, subscriptions and clinic reports";
                who = "Super Admin Dashboard";
            }
            else if (Session.IsTenant)
            {
                string? email = Session.CurrentUser?.Email;
                var tenant = email == null ? null : db.Tenants.FirstOrDefault(t => t.ContactEmail == email);
                who = tenant != null ? $"{tenant.TenantName} Dashboard" : "Tenant Dashboard";
                scope = tenant != null
                    ? $"{tenant.TenantCode} · {tenant.SubscriptionTier} · Status: {tenant.Status} · All reports with graphs"
                    : "All reports with graphs";
            }
            else
            {
                who = "Clinic Admin Dashboard";
                scope = "All clinic reports with graphs";
            }

            root.Controls.Add(new Label
            {
                Text = who,
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Margin = new Padding(10, 10, 10, 2),
                AutoSize = true
            });

            lblScope = new Label
            {
                Text = scope,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(100, 116, 139),
                Margin = new Padding(12, 0, 10, 4),
                AutoSize = true
            };
            root.Controls.Add(lblScope);

            var actions = new FlowLayoutPanel
            {
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Margin = new Padding(10, 6, 10, 0)
            };

            var btnRefresh = new Button
            {
                Text = "Refresh Dashboard",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.Click += (s, e) => Reload();
            actions.Controls.Add(btnRefresh);

            if (Session.IsSuperAdmin)
            {
                var btnAdd = new Button
                {
                    Text = "+ Add Tenant",
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    ForeColor = Color.White,
                    BackColor = Color.FromArgb(16, 185, 129),
                    FlatStyle = FlatStyle.Flat,
                    Size = new Size(150, 30),
                    Cursor = Cursors.Hand
                };
                btnAdd.FlatAppearance.BorderSize = 0;
                btnAdd.Click += (s, e) => { if (TenantsControl.ShowAddTenantDialog(this.FindForm())) Reload(); };
                actions.Controls.Add(btnAdd);
            }

            root.Controls.Add(actions);
        }

        private void Reload()
        {
            this.SuspendLayout();
            root.Controls.Clear();
            fullWidthItems.Clear();
            LoadDashboard();
            this.ResumeLayout();
        }

        private void BuildPlatformSection(ApplicationDbContext db)
        {
            var tenants = db.Tenants.ToList();
            var subs = db.Subscriptions.ToList();

            decimal mrr = subs.Where(s => s.Status == "Active").Sum(s => s.MonthlyPrice);
            int pastDue = subs.Count(s => s.Status == "PastDue");

            AddHeading("Platform & Tenant Reports", "Super Admin only: every clinic tenant onboarded on the platform");
            AddKpiRow(
                ("TOTAL TENANTS", tenants.Count.ToString("N0"), Color.FromArgb(139, 92, 246)),
                ("ACTIVE TENANTS", tenants.Count(t => t.Status == "Active").ToString("N0"), Color.FromArgb(16, 185, 129)),
                ("MONTHLY RECURRING REVENUE", $"₱{mrr:N2}", Color.FromArgb(2, 132, 199)),
                ("PAST-DUE SUBSCRIPTIONS", pastDue.ToString("N0"), Color.FromArgb(239, 68, 68)));

            var byTier = tenants.GroupBy(t => t.SubscriptionTier)
                .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Count() }).OrderBy(x => x.Name).ToList();
            var byStatus = tenants.GroupBy(t => t.Status)
                .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Count() }).ToList();
            var mrrByTier = subs.Where(s => s.Status == "Active").GroupBy(s => s.SubscriptionTier)
                .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Sum(x => x.MonthlyPrice) }).OrderBy(x => x.Name).ToList();

            var (monthLabels, monthStarts) = LastMonths(12);
            var onboarded = monthStarts
                .Select(ms => (decimal)tenants.Count(t => t.CreatedAt >= ms && t.CreatedAt < ms.AddMonths(1))).ToList();

            AddCharts(
                new PieChartControl("Tenants by Subscription Tier", byTier),
                new DoughnutChartControl("Tenants by Status", byStatus),
                new BarChartControl("Monthly Recurring Revenue by Tier (₱)", mrrByTier, Color.FromArgb(2, 132, 199)),
                new LineChartControl("Tenants Onboarded per Month", monthLabels, onboarded, false));
        }

        private void BuildFinancialSection(ApplicationDbContext db)
        {
            var invoices = db.BillingInvoices.ToList();
            var payments = db.Payments.ToList();

            decimal billed = invoices.Sum(i => i.TotalAmount);
            decimal collected = payments.Sum(p => p.Amount);
            decimal due = invoices.Sum(i => i.BalanceDue);
            decimal discounts = invoices.Sum(i => i.DiscountAmount);
            var thisMonth = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
            decimal monthRev = payments.Where(p => p.PaymentDate >= thisMonth).Sum(p => p.Amount);
            decimal avgInvoice = invoices.Count > 0 ? billed / invoices.Count : 0m;
            decimal collectionRate = billed > 0 ? Math.Round(collected / billed * 100m, 1) : 0m;

            AddHeading("Financial Reports", "Sales, collections, receivables and promotions");
            AddKpiRow(
                ("GROSS BILLED SALES", $"₱{billed:N2}", Color.FromArgb(2, 132, 199)),
                ("COLLECTED REVENUE", $"₱{collected:N2}", Color.FromArgb(16, 185, 129)),
                ("OUTSTANDING RECEIVABLES", $"₱{due:N2}", Color.FromArgb(239, 68, 68)),
                ("PROMO DISCOUNTS GRANTED", $"-₱{discounts:N2}", Color.FromArgb(245, 158, 11)),
                ("REVENUE THIS MONTH", $"₱{monthRev:N2}", Color.FromArgb(14, 165, 233)),
                ("AVERAGE INVOICE", $"₱{avgInvoice:N2}", Color.FromArgb(99, 102, 241)),
                ("COLLECTION RATE", $"{collectionRate}%", Color.FromArgb(16, 185, 129)),
                ("TOTAL INVOICES", invoices.Count.ToString("N0"), Color.FromArgb(139, 92, 246)));

            var (labels, starts) = LastMonths(12);
            var monthlyRevenue = starts.Select(ms => payments.Where(p => p.PaymentDate >= ms && p.PaymentDate < ms.AddMonths(1)).Sum(p => p.Amount)).ToList();
            var monthlyBilled = starts.Select(ms => invoices.Where(i => i.InvoiceDate >= ms && i.InvoiceDate < ms.AddMonths(1)).Sum(i => i.TotalAmount)).ToList();

            var byMethod = payments.GroupBy(p => p.Method)
                .Select(g => new ChartCategoryItem { Name = g.Key.ToString(), Value = g.Sum(x => x.Amount) })
                .OrderByDescending(x => x.Value).ToList();

            var invoiceStatus = Enum.GetValues<InvoiceStatus>()
                .Select(s => new ChartCategoryItem { Name = s.ToString(), Value = invoices.Count(i => i.Status == s) })
                .Where(x => x.Value > 0).ToList();

            var promoData = db.Promotions.Include(p => p.AppliedInvoices).ToList()
                .Select(p => new PromoImpactItem
                {
                    PromoCode = p.PromoCode,
                    Discount = p.AppliedInvoices.Sum(i => i.DiscountAmount),
                    Revenue = p.AppliedInvoices.Sum(i => i.TotalAmount)
                })
                .Where(p => p.Discount > 0 || p.Revenue > 0).ToList();

            var topServices = db.InvoiceItems.Include(i => i.DentalService).Where(i => i.DentalService != null).ToList()
                .GroupBy(i => i.DentalService!.Name)
                .Select(g => new ChartCategoryItem { Name = Short(g.Key), Value = g.Sum(x => x.LineTotal) })
                .OrderByDescending(x => x.Value).Take(6).ToList();

            AddCharts(
                new LineChartControl("Monthly Revenue Collected (Last 12 Months)", labels, monthlyRevenue),
                new LineChartControl("Monthly Billed Sales (Last 12 Months)", labels, monthlyBilled),
                new DoughnutChartControl("Revenue by Payment Method", byMethod),
                new PieChartControl("Invoice Status Distribution", invoiceStatus),
                new PromoImpactChartControl("Promotional Discounts vs Revenue", promoData),
                new BarChartControl("Top Services by Revenue (₱)", topServices, Color.FromArgb(16, 185, 129)));
        }

        private void BuildClinicalSection(ApplicationDbContext db)
        {
            var patients = db.Patients.ToList();
            var appts = db.Appointments.ToList();
            var treatments = db.TreatmentRecords.Include(t => t.DentalService).Include(t => t.Dentist).ToList();

            int completed = appts.Count(a => a.Status == AppointmentStatus.Completed);
            double completionRate = appts.Count > 0 ? Math.Round((double)completed / appts.Count * 100, 1) : 0;
            int noShows = appts.Count(a => a.Status == AppointmentStatus.NoShow);
            var thisMonth = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);

            AddHeading("Clinical & Operations Reports", "Patients, appointments, treatments and dentist performance");
            AddKpiRow(
                ("ACTIVE PATIENTS", patients.Count(p => p.IsActive).ToString("N0"), Color.FromArgb(2, 132, 199)),
                ("NEW PATIENTS THIS MONTH", patients.Count(p => p.CreatedAt >= thisMonth).ToString("N0"), Color.FromArgb(16, 185, 129)),
                ("TOTAL APPOINTMENTS", appts.Count.ToString("N0"), Color.FromArgb(139, 92, 246)),
                ("COMPLETION RATE", $"{completionRate}%", Color.FromArgb(16, 185, 129)),
                ("NO-SHOWS", noShows.ToString("N0"), Color.FromArgb(239, 68, 68)),
                ("TREATMENTS RECORDED", treatments.Count.ToString("N0"), Color.FromArgb(14, 165, 233)),
                ("TREATMENT VALUE", $"₱{treatments.Sum(t => t.Cost):N2}", Color.FromArgb(245, 158, 11)),
                ("AVERAGE TREATMENT COST", $"₱{(treatments.Count > 0 ? treatments.Average(t => t.Cost) : 0m):N2}", Color.FromArgb(99, 102, 241)));

            var (labels, starts) = LastMonths(12);
            var apptsPerMonth = starts.Select(ms => (decimal)appts.Count(a => a.AppointmentDate >= ms && a.AppointmentDate < ms.AddMonths(1))).ToList();
            var newPatients = starts.Select(ms => (decimal)patients.Count(p => p.CreatedAt >= ms && p.CreatedAt < ms.AddMonths(1))).ToList();

            var statusData = Enum.GetValues<AppointmentStatus>()
                .Select(s => new ChartCategoryItem { Name = s.ToString(), Value = appts.Count(a => a.Status == s) })
                .Where(x => x.Value > 0).ToList();

            var categoryData = treatments.Where(t => t.DentalService != null)
                .GroupBy(t => t.DentalService!.Category)
                .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Sum(x => x.Cost) })
                .OrderByDescending(x => x.Value).ToList();

            var dentistData = treatments.Where(t => t.Dentist != null)
                .GroupBy(t => t.Dentist!.FullName)
                .Select(g => new ChartCategoryItem { Name = Short(g.Key.Replace("Dr. ", "")), Value = g.Sum(x => x.Cost) })
                .OrderByDescending(x => x.Value).ToList();

            var weekday = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday }
                .Select(d => new ChartCategoryItem { Name = d.ToString().Substring(0, 3), Value = appts.Count(a => a.AppointmentDate.DayOfWeek == d) }).ToList();

            var gender = patients.GroupBy(p => p.Gender)
                .Select(g => new ChartCategoryItem { Name = g.Key, Value = g.Count() }).ToList();

            AddCharts(
                new LineChartControl("Appointments per Month", labels, apptsPerMonth, false),
                new LineChartControl("New Patients per Month", labels, newPatients, false),
                new PieChartControl("Appointment Status Distribution", statusData),
                new BarChartControl("Appointments by Weekday", weekday, Color.FromArgb(99, 102, 241), false),
                new DoughnutChartControl("Treatment Revenue by Category", categoryData),
                new BarChartControl("Dentist Production Comparison (₱)", dentistData, Color.FromArgb(139, 92, 246)),
                new PieChartControl("Patients by Gender", gender));
        }

        private static (List<string> labels, List<DateTime> starts) LastMonths(int count)
        {
            var today = DateTime.UtcNow.Date;
            var labels = new List<string>();
            var starts = new List<DateTime>();
            for (int m = count - 1; m >= 0; m--)
            {
                var t = today.AddMonths(-m);
                starts.Add(new DateTime(t.Year, t.Month, 1));
                labels.Add(t.ToString("MMM"));
            }
            return (labels, starts);
        }
    }
}
