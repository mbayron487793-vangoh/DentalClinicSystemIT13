using System;
using System.Drawing;
using System.Windows.Forms;

namespace DentalClinicWinForms.Views
{
    public class MainTransactionsControl : UserControl
    {
        private Panel tabHeaderPanel = null!;
        private Panel transactionContentPanel = null!;
        private Button btnTabAppts = null!;
        private Button btnTabTreatments = null!;
        private Button btnTabBilling = null!;

        public MainTransactionsControl()
        {
            InitializeComponent();
            SwitchTab(0);
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(15);

            var topPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 85,
                BackColor = Color.Transparent
            };

            var lblTitle = new Label
            {
                Text = "Main Clinical Transactions (Tenant A Subscription)",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(5, 5),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Complete transactional pipeline for Tenant A: Patient Appointments, Dental Treatment Records, and Billing Invoices",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(7, 35),
                AutoSize = true
            };

            tabHeaderPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 36,
                BackColor = Color.Transparent
            };

            btnTabAppts = CreateTabButton(" 1. Patient Appointments", 0);
            btnTabTreatments = CreateTabButton(" 2. Clinical Treatments", 1);
            btnTabBilling = CreateTabButton(" 3. Invoicing & Billing (PDF)", 2);

            btnTabAppts.Location = new Point(5, 2);
            btnTabTreatments.Location = new Point(220, 2);
            btnTabBilling.Location = new Point(435, 2);

            tabHeaderPanel.Controls.AddRange(new Control[] { btnTabAppts, btnTabTreatments, btnTabBilling });

            topPanel.Controls.Add(lblTitle);
            topPanel.Controls.Add(lblSub);
            topPanel.Controls.Add(tabHeaderPanel);

            transactionContentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };

            this.Controls.Add(transactionContentPanel);
            this.Controls.Add(topPanel);
        }

        private Button CreateTabButton(string text, int tabIndex)
        {
            var btn = new Button
            {
                Text = text,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Size = new Size(205, 32),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) => SwitchTab(tabIndex);
            return btn;
        }

        private void SwitchTab(int tabIndex)
        {
            // Reset tab button colors
            btnTabAppts.BackColor = Color.FromArgb(226, 232, 240);
            btnTabAppts.ForeColor = Color.FromArgb(71, 85, 105);
            btnTabTreatments.BackColor = Color.FromArgb(226, 232, 240);
            btnTabTreatments.ForeColor = Color.FromArgb(71, 85, 105);
            btnTabBilling.BackColor = Color.FromArgb(226, 232, 240);
            btnTabBilling.ForeColor = Color.FromArgb(71, 85, 105);

            transactionContentPanel.Controls.Clear();

            Control activeControl;
            if (tabIndex == 0)
            {
                btnTabAppts.BackColor = Color.FromArgb(2, 132, 199);
                btnTabAppts.ForeColor = Color.White;
                activeControl = new AppointmentsControl();
            }
            else if (tabIndex == 1)
            {
                btnTabTreatments.BackColor = Color.FromArgb(139, 92, 246);
                btnTabTreatments.ForeColor = Color.White;
                activeControl = new TreatmentsControl();
            }
            else
            {
                btnTabBilling.BackColor = Color.FromArgb(16, 185, 129);
                btnTabBilling.ForeColor = Color.White;
                activeControl = new BillingControl();
            }

            activeControl.Dock = DockStyle.Fill;
            transactionContentPanel.Controls.Add(activeControl);
        }
    }
}
