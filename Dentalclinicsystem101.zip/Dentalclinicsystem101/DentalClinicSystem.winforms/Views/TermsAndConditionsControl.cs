using System;
using System.Drawing;
using System.Windows.Forms;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Views
{
    public class TermsAndConditionsControl : UserControl
    {
        private Panel contentPanel = null!;
        private ComboBox? cmbTierSelector;
        private Label lblCurrentTierTitle = null!;
        private Label lblEffectiveDate = null!;
        private RichTextBox rtbTermsText = null!;
        private Button btnAccept = null!;
        private Label lblAcceptanceStatus = null!;
        private string activeTier = "SuperAdmin";

        public TermsAndConditionsControl(string? initialTier = null)
        {
            if (!string.IsNullOrEmpty(initialTier))
            {
                activeTier = initialTier;
            }
            else if (Session.RoleName == "SuperAdmin")
            {
                activeTier = "SuperAdmin";
            }
            else if (Session.IsTenantA)
            {
                activeTier = "Tenant A";
            }
            else if (Session.IsTenantB)
            {
                activeTier = "Tenant B";
            }
            else if (Session.IsTenantC)
            {
                activeTier = "Tenant C";
            }
            else
            {
                activeTier = "General";
            }

            InitializeComponent();
            LoadTermsForTier(activeTier);
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(24);

            // Header Banner
            var headerCard = new Panel
            {
                Location = new Point(24, 20),
                Size = new Size(1100, 80),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblHeader = new Label
            {
                Text = "Terms and Conditions Agreement",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 14),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Official Service Level Agreement (SLA), Data Governance, and Multi-Tenancy Terms & Conditions",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 46),
                AutoSize = true
            };

            headerCard.Controls.Add(lblHeader);
            headerCard.Controls.Add(lblSub);

            // If Super Admin, show tier switcher to inspect any tenant's terms
            if (Session.RoleName == "SuperAdmin")
            {
                var lblSelector = new Label
                {
                    Text = "View Terms For:",
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    ForeColor = Color.FromArgb(71, 85, 105),
                    Location = new Point(720, 26),
                    AutoSize = true,
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };

                cmbTierSelector = new ComboBox
                {
                    Location = new Point(830, 23),
                    Size = new Size(245, 28),
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };
                cmbTierSelector.Items.AddRange(new object[]
                {
                    "Super Admin Master Governance",
                    "Tenant A: Core Tier (Main Tx, Data)",
                    "Tenant B: Pro Tier (BI, Actions)",
                    "Tenant C: Enterprise Tier (Branching, BI, Actions)"
                });
                cmbTierSelector.SelectedIndex = 0;
                cmbTierSelector.SelectedIndexChanged += (s, e) =>
                {
                    string selected = cmbTierSelector.SelectedIndex switch
                    {
                        0 => "SuperAdmin",
                        1 => "Tenant A",
                        2 => "Tenant B",
                        3 => "Tenant C",
                        _ => "SuperAdmin"
                    };
                    LoadTermsForTier(selected);
                };

                headerCard.Controls.Add(lblSelector);
                headerCard.Controls.Add(cmbTierSelector);
            }

            // Main Body Card
            contentPanel = new Panel
            {
                Location = new Point(24, 115),
                Size = new Size(1100, 560),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                Padding = new Padding(24)
            };

            lblCurrentTierTitle = new Label
            {
                Text = "Terms and Conditions",
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(24, 18),
                AutoSize = true
            };

            lblEffectiveDate = new Label
            {
                Text = "Effective Date: October 2026 • Status: Legally Active & Enforced",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Regular),
                ForeColor = Color.FromArgb(16, 185, 129),
                Location = new Point(26, 46),
                AutoSize = true
            };

            rtbTermsText = new RichTextBox
            {
                Location = new Point(24, 75),
                Size = new Size(1050, 410),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 9.5F),
                ReadOnly = true,
                BackColor = Color.FromArgb(250, 250, 252),
                BorderStyle = BorderStyle.FixedSingle,
                ScrollBars = RichTextBoxScrollBars.Vertical
            };

            // Bottom action panel
            var bottomBar = new Panel
            {
                Location = new Point(24, 498),
                Size = new Size(1050, 50),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            btnAccept = new Button
            {
                Text = "✓ I Accept & Acknowledge Terms",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(240, 36),
                Location = new Point(0, 7),
                Cursor = Cursors.Hand
            };
            btnAccept.FlatAppearance.BorderSize = 0;
            btnAccept.Click += BtnAccept_Click;

            var btnPrint = new Button
            {
                Text = "🖨 Print / Export Agreement",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 65, 85),
                BackColor = Color.FromArgb(241, 245, 249),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(210, 36),
                Location = new Point(255, 7),
                Cursor = Cursors.Hand
            };
            btnPrint.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            btnPrint.Click += (s, e) =>
            {
                MessageBox.Show(
                    "Terms & Conditions Agreement has been formatted for legal compliance.\nReady to send to default Windows printer / PDF print queue.",
                    "Export Agreement",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            };

            lblAcceptanceStatus = new Label
            {
                Text = "✔ Agreement Status: Acknowledged & Signed by " + (Session.CurrentUser?.FullName ?? "Account Holder"),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(16, 185, 129),
                Location = new Point(480, 16),
                AutoSize = true
            };

            bottomBar.Controls.Add(btnAccept);
            bottomBar.Controls.Add(btnPrint);
            bottomBar.Controls.Add(lblAcceptanceStatus);

            contentPanel.Controls.Add(lblCurrentTierTitle);
            contentPanel.Controls.Add(lblEffectiveDate);
            contentPanel.Controls.Add(rtbTermsText);
            contentPanel.Controls.Add(bottomBar);

            this.Controls.Add(headerCard);
            this.Controls.Add(contentPanel);
        }

        private void BtnAccept_Click(object? sender, EventArgs e)
        {
            lblAcceptanceStatus.Text = $"✔ Terms Accepted on {DateTime.Now:yyyy-MM-dd HH:mm:ss} by {Session.CurrentUser?.FullName ?? Session.RoleName}";
            lblAcceptanceStatus.ForeColor = Color.FromArgb(16, 185, 129);
            MessageBox.Show(
                $"Thank you. Your acknowledgment of the Terms and Conditions for {lblCurrentTierTitle.Text} has been successfully recorded in the audit log.",
                "Terms Acknowledged",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        public void LoadTermsForTier(string tier)
        {
            activeTier = tier;

            switch (tier)
            {
                case "SuperAdmin":
                    lblCurrentTierTitle.Text = "Master (Super Admin) System Administration & Governance Terms";
                    lblEffectiveDate.Text = "Effective Date: October 2026 • Applicable To: Super Administrators & System Root Operators";
                    rtbTermsText.Rtf = GetSuperAdminTermsRtf();
                    break;

                case "Tenant A":
                    lblCurrentTierTitle.Text = "Tenant A (Core Tier) Subscription Terms & Conditions";
                    lblEffectiveDate.Text = "Effective Date: October 2026 • Plan: Core Transactions & Clinical Data Collection";
                    rtbTermsText.Rtf = GetTenantATermsRtf();
                    break;

                case "Tenant B":
                    lblCurrentTierTitle.Text = "Tenant B (Pro Tier) Subscription Terms & Conditions";
                    lblEffectiveDate.Text = "Effective Date: October 2026 • Plan: Business Intelligence & Clinical Action Directives";
                    rtbTermsText.Rtf = GetTenantBTermsRtf();
                    break;

                case "Tenant C":
                    lblCurrentTierTitle.Text = "Tenant C (Enterprise Tier) Subscription Terms & Conditions";
                    lblEffectiveDate.Text = "Effective Date: October 2026 • Plan: Enterprise Multi-Branching, Business Intelligence & Actions";
                    rtbTermsText.Rtf = GetTenantCTermsRtf();
                    break;

                default:
                    lblCurrentTierTitle.Text = "DentalCare System General Terms of Service";
                    lblEffectiveDate.Text = "Effective Date: October 2026 • Applicable To: Dental Staff, Dentists & Practice Administrators";
                    rtbTermsText.Rtf = GetGeneralTermsRtf();
                    break;
            }
        }

        private string GetSuperAdminTermsRtf()
        {
            return @"{\rtf1\ansi\deff0
{\colortbl ;\red15\green23\blue42;\red2\green132\blue199;\red71\green85\blue105;\red220\green38\blue38;}
\b\fs24\cf2 MASTER SUPER ADMIN SYSTEM ADMINISTRATION TERMS & GOVERNANCE POLICY\b0\fs18\par
\cf3 Version 3.4 • DentalCare Enterprise Multi-Tenant Platform\par\par

\b\cf1 1. MASTER OPERATIONAL AUTHORITY AND ROOTS RESPONSIBILITIES\b0\par
The Master Super Administrator is granted overarching supervisory authority over the entire multi-tenant infrastructure, database telemetry, subscription tiers, and system administrative modules. Access to root-level configurations requires adherence to high-assurance security practices, multi-factor authentication, and strict non-disclosure of tenant confidential records.\par\par

\b\cf1 2. TENANT ISOLATION GUARANTEE AND DATA BOUNDARY INTEGRITY\b0\par
The Super Admin agrees to enforce and maintain logical and physical tenant boundary isolation. Tenant A, Tenant B, and Tenant C proprietary patient datasets, financial billing records, and clinical logs must remain encrypted at rest and in transit. Super Administrators shall not export, decrypt, or share tenant-specific records without written authorization or statutory subpoena compliance.\par\par

\b\cf1 3. SUBSCRIPTION ALLOCATION AND MODULE ACCESS CONTROLS\b0\par
The Super Admin is responsible for:
  \bullet Provisioning and renewing subscription plans for Tenant A (Main Transaction, Data Collection), Tenant B (Business Intelligence, Actions), and Tenant C (Branching, Business Intelligence, Actions).
  \bullet Ensuring that tenants access only their subscribed modules and tier allotments.
  \bullet Sending timely notification advisories to tenant administrators via SMS and Email channels.\par\par

\b\cf1 4. PLATFORM AUDITABILITY AND MAINTENANCE DISCLOSURES\b0\par
All configuration overrides, role assignments, subscription modifications, and maintenance tasks performed in the Admin Panel are logged with immutable cryptographic timestamps. Scheduled maintenance that impacts tenant availability must be communicated at least 48 hours in advance through the built-in notification dispatch system.\par\par

\b\cf1 5. LIMITATION OF LIABILITY AND ROOT INTEGRITY\b0\par
The Super Administrator shall not exploit root credentials for competitive intelligence or unauthorized modification of clinic financial audits. Violation of these terms warrants immediate administrative revocation and legal audit review.\par
}";
        }

        private string GetTenantATermsRtf()
        {
            return @"{\rtf1\ansi\deff0
{\colortbl ;\red15\green23\blue42;\red245\green158\blue11;\red71\green85\blue105;}
\b\fs24\cf2 TENANT A (CORE TIER) SUBSCRIPTION TERMS & CONDITIONS\b0\fs18\par
\cf3 Plan: Core Transactions & Clinical Data Collection • Billing: ₱4,999.00 / Month\par\par

\b\cf1 1. SUBSCRIBED MODULE SCOPE & FEATURE ACCESS\b0\par
Under the Tenant A Core Subscription Plan, the subscriber is explicitly authorized to access and utilize the following features:
  \bullet \b Main Transaction:\b0 Full CRUD capabilities for Patient Appointments, Clinical Treatments, and Billing Invoices (including PDF generation).
  \bullet \b Data Collection:\b0 Comprehensive patient profiling, medical histories, tooth charting records, and the full Dental Services Catalog.
Access to higher tier modules (such as Business Intelligence, Action Directives, and Multi-Branch Management) is restricted unless the tenant upgrades their subscription tier.\par\par

\b\cf1 2. PATIENT DATA PRIVACY AND MEDICAL RECORDS STANDARDS\b0\par
Tenant A warrants that all collected patient records, medical histories, and personal health data entered into the Data Collection module comply with national health data privacy laws and HIPAA security guidelines. Tenant A retains sole data ownership over their clinical transactions.\par\par

\b\cf1 3. TRANSACTION PROCESSING LIMITS AND USAGE FAIR USE\b0\par
Tenant A is licensed for single-clinic operational transaction throughput. High-volume automated script insertion outside normal clinic transactions is strictly prohibited. Standard daily database backups are provided automatically by the platform.\par\par

\b\cf1 4. BILLING, PAYMENT SCHEDULE, AND RENEWALS\b0\par
Subscription fees are billed monthly at ₱4,999.00. Failure to remit payment within 15 calendar days following the billing date may result in account status change to 'PastDue'. Renewal reminders and account notices will be transmitted to the registered contact phone and email.\par\par

\b\cf1 5. TERMINATION AND DATA EXPORT RIGHTS\b0\par
Upon termination of the Tenant A subscription, the subscriber is entitled to a 30-day grace period to export all patient profiles, treatment histories, and billing invoice PDFs in standard formats.\par
}";
        }

        private string GetTenantBTermsRtf()
        {
            return @"{\rtf1\ansi\deff0
{\colortbl ;\red15\green23\blue42;\red99\green102\blue241;\red71\green85\blue105;}
\b\fs24\cf2 TENANT B (PRO TIER) SUBSCRIPTION TERMS & CONDITIONS\b0\fs18\par
\cf3 Plan: Practice Intelligence & Operational Actions • Billing: ₱8,999.00 / Month\par\par

\b\cf1 1. SUBSCRIBED MODULE SCOPE & FEATURE ACCESS\b0\par
Under the Tenant B Pro Subscription Plan, the subscriber is explicitly authorized to access and utilize the following features:
  \bullet \b Business Intelligence:\b0 Executive revenue dashboards, doctor productivity analytics, treatment volume metrics, payment collection trends, and procedure category distributions.
  \bullet \b Actions:\b0 Workflow directive registry, priority clinical tasks, equipment maintenance tracking, and actionable compliance items.
Tenant B is optimized for practice management consulting, analytics oversight, and executive action supervision.\par\par

\b\cf1 2. BUSINESS INTELLIGENCE METRIC INTEGRITY & DATA PROCESSING\b0\par
Analytical computations and forecasting metrics provided by the Business Intelligence module are computed from verified transaction records. Tenant B acknowledges that BI projections are management advisory tools and do not constitute formal tax or fiduciary guarantees.\par\par

\b\cf1 3. CLINICAL ACTION DIRECTIVES AND ACCOUNTABILITY\b0\par
The Actions module provides clinical task delegation and priority tracking. Tenant B supervisors are responsible for verifying the fulfillment of urgent clinical directives, equipment servicing, and patient safety follow-ups initiated within their tenant workspace.\par\par

\b\cf1 4. INTELLECTUAL PROPERTY AND ANALYTICAL MODELS\b0\par
All algorithms, metric formulas, and dashboard visualizations provided by the Business Intelligence module remain the proprietary intellectual property of the platform. Tenant B retains complete ownership over their underlying data inputs.\par\par

\b\cf1 5. SUBSCRIPTION PRICING AND NOTIFICATION CHANNELS\b0\par
The monthly subscription fee is ₱8,999.00. Account notices, intelligence report digests, and renewal alerts will be delivered via the registered client phone number (SMS) and official email address.\par
}";
        }

        private string GetTenantCTermsRtf()
        {
            return @"{\rtf1\ansi\deff0
{\colortbl ;\red15\green23\blue42;\red236\green72\blue153;\red71\green85\blue105;}
\b\fs24\cf2 TENANT C (ENTERPRISE TIER) SUBSCRIPTION TERMS & CONDITIONS\b0\fs18\par
\cf3 Plan: Multi-Branching, Business Intelligence & Actions • Billing: ₱14,999.00 / Month\par\par

\b\cf1 1. SUBSCRIBED MODULE SCOPE & FEATURE ACCESS\b0\par
Under the Tenant C Enterprise Subscription Plan, the subscriber is granted full enterprise-tier access to:
  \bullet \b Branching:\b0 Multi-branch clinic network management, branch chair capacities, facility revenues, branch manager profiles, and cross-clinic coordination.
  \bullet \b Business Intelligence:\b0 Group-wide aggregated analytics, branch comparison metrics, doctor productivity, and executive financial reports.
  \bullet \b Actions:\b0 Enterprise-wide action directives, cross-branch compliance tasks, and urgent operational resolutions.\par\par

\b\cf1 2. MULTI-BRANCH DATA FEDERATION & CHAIR CAPACITY SLA\b0\par
Tenant C is licensed to provision and manage multiple dental clinic locations under a single enterprise tenancy. Data replication across branches is safeguarded by high-concurrency relational guarantees. The platform commits to 99.9% uptime SLA for all connected branch terminals.\par\par

\b\cf1 3. ENTERPRISE PRIORITY SUPPORT AND NOTIFICATION DISPATCH\b0\par
Tenant C receives priority technical support with a guaranteed 2-hour response window for critical alerts. Multi-channel broadcast notifications (SMS & Email) are enabled to inform all branch managers and clinic directors simultaneously.\par\par

\b\cf1 4. REGULATORY COMPLIANCE AND BRANCH AUDITABILITY\b0\par
Tenant C agrees that each registered branch adheres to local dental board standards and radiation safety protocols for dental imaging equipment. The Super Admin reserves the right to review branch operational status indicators for platform compliance.\par\par

\b\cf1 5. ENTERPRISE PRICING & PAYMENT TERMS\b0\par
The enterprise subscription rate is ₱14,999.00 per month, covering unlimited branches and centralized BI analytics. Payment is due upon monthly invoicing, with automatic renewal unless cancelled 30 days prior to contract expiration.\par
}";
        }

        private string GetGeneralTermsRtf()
        {
            return @"{\rtf1\ansi\deff0
{\colortbl ;\red15\green23\blue42;\red2\green132\blue199;\red71\green85\blue105;}
\b\fs24\cf2 GENERAL CLINICAL PRACTICE & USER TERMS OF SERVICE\b0\fs18\par
\cf3 DentalCare System • Clinical Practice Standards & Security Agreement\par\par

\b\cf1 1. USER RESPONSIBILITIES AND CREDENTIAL SECURITY\b0\par
All clinical users (Administrators, Dentists, Staff, and Assistants) must maintain the confidentiality of their login credentials. Sharing accounts is strictly prohibited to preserve audit trail integrity.\par\par

\b\cf1 2. CLINICAL RECORD INTEGRITY AND BILLING ACCURACY\b0\par
Staff and Dentists must ensure that treatment records, tooth designations, and billing entries accurately reflect dental procedures rendered. Billing invoices must be verified before generating PDF copies for patients.\par\par

\b\cf1 3. PATIENT APPOINTMENT REMINDER COMPLIANCE\b0\par
Appointment reminders sent via SMS or Email must adhere to patient communication consent preferences. Automated reminders must not contain sensitive medical diagnoses in open SMS text.\par
}";
        }
    }
}
