using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicWinForms.Views
{
    public class SystemAdminControl : UserControl
    {
        private DataGridView gridAudit = null!;
        private Label lblTotalRecords = null!;
        private Label lblDbStatus = null!;
        private Label lblActiveTenants = null!;
        private ComboBox cmbModuleFilter = null!;

        public SystemAdminControl()
        {
            InitializeComponent();
            LoadSystemMetrics();
            LoadAuditLogs();
        }

        private void InitializeComponent()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Padding = new Padding(20);
            this.AutoScroll = true;

            var lblTitle = new Label
            {
                Text = "Master System Administration & Admin Panel",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(20, 15),
                AutoSize = true
            };

            var lblSub = new Label
            {
                Text = "Super Admin system diagnostics, multi-tenant infrastructure, database telemetry, and security audit logs",
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(22, 45),
                AutoSize = true
            };

            // Metrics Cards Panel
            var metricsPanel = new TableLayoutPanel
            {
                Location = new Point(20, 75),
                Size = new Size(1120, 95),
                ColumnCount = 4,
                RowCount = 1,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            metricsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));

            var card1 = CreateCard("DATABASE STATUS", "Connected (Healthy)", Color.FromArgb(16, 185, 129), out lblDbStatus);
            var card2 = CreateCard("TOTAL TRANSACTIONS", "265+ Records", Color.FromArgb(2, 132, 199), out lblTotalRecords);
            var card3 = CreateCard("ACTIVE TENANTS", "3 Multi-Tenants", Color.FromArgb(139, 92, 246), out lblActiveTenants);
            var card4 = CreateAdminActionCard();

            metricsPanel.Controls.Add(card1, 0, 0);
            metricsPanel.Controls.Add(card2, 1, 0);
            metricsPanel.Controls.Add(card3, 2, 0);
            metricsPanel.Controls.Add(card4, 3, 0);

            // Audit Logs Section Header
            var toolbar = new Panel
            {
                Location = new Point(20, 180),
                Size = new Size(1120, 48),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblAuditTitle = new Label
            {
                Text = "Security & Operational Audit Trail",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(12, 13),
                AutoSize = true
            };

            var lblFilter = new Label
            {
                Text = "Module:",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Location = new Point(280, 14),
                AutoSize = true
            };

            cmbModuleFilter = new ComboBox
            {
                Location = new Point(340, 11),
                Size = new Size(160, 26),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9F)
            };
            cmbModuleFilter.Items.AddRange(new object[] { "All Modules", "System", "Billing", "Appointments", "Tenants", "Subscriptions", "Patients", "Security" });
            cmbModuleFilter.SelectedIndex = 0;
            cmbModuleFilter.SelectedIndexChanged += (s, e) => LoadAuditLogs();

            var btnRefresh = new Button
            {
                Text = "Refresh Audit",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 65, 85),
                BackColor = Color.FromArgb(241, 245, 249),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(515, 9),
                Size = new Size(120, 30),
                Cursor = Cursors.Hand
            };
            btnRefresh.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            btnRefresh.Click += (s, e) => { LoadSystemMetrics(); LoadAuditLogs(); };

            var btnAddLog = new Button
            {
                Text = "+ Log System Event",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(645, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnAddLog.FlatAppearance.BorderSize = 0;
            btnAddLog.Click += (s, e) => ShowAddLogDialog();

            var btnClearLogs = new Button
            {
                Text = "Delete Selected Log",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(239, 68, 68),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(805, 9),
                Size = new Size(150, 30),
                Cursor = Cursors.Hand
            };
            btnClearLogs.FlatAppearance.BorderSize = 0;
            btnClearLogs.Click += (s, e) => DeleteSelectedLog();

            var btnAddTenant = new Button
            {
                Text = "+ Add Tenant",
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(16, 185, 129),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(965, 9),
                Size = new Size(130, 30),
                Cursor = Cursors.Hand
            };
            btnAddTenant.FlatAppearance.BorderSize = 0;
            btnAddTenant.Click += (s, e) =>
            {
                if (TenantsControl.ShowAddTenantDialog(this.FindForm()))
                {
                    LoadSystemMetrics();
                    LoadAuditLogs();
                }
            };

            toolbar.Controls.AddRange(new Control[] { lblAuditTitle, lblFilter, cmbModuleFilter, btnRefresh, btnAddLog, btnClearLogs, btnAddTenant });

            // Audit Grid
            gridAudit = new DataGridView
            {
                Location = new Point(20, 238),
                Size = new Size(1120, 420),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                AllowUserToAddRows = false
            };

            gridAudit.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            gridAudit.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridAudit.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridAudit.EnableHeadersVisualStyles = false;
            gridAudit.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            gridAudit.RowTemplate.Height = 28;

            this.Controls.AddRange(new Control[] { lblTitle, lblSub, metricsPanel, toolbar, gridAudit });
        }

        private Panel CreateCard(string title, string value, Color accentColor, out Label lblVal)
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                BorderStyle = BorderStyle.FixedSingle
            };

            var topBar = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = accentColor };
            var lblT = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(12, 12),
                AutoSize = true
            };
            lblVal = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Color.FromArgb(15, 23, 42),
                Location = new Point(12, 34),
                AutoSize = true
            };

            p.Controls.Add(lblVal);
            p.Controls.Add(lblT);
            p.Controls.Add(topBar);
            return p;
        }

        private Panel CreateAdminActionCard()
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Margin = new Padding(4),
                BorderStyle = BorderStyle.FixedSingle
            };

            var topBar = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = Color.FromArgb(245, 158, 11) };

            var btnSeed = new Button
            {
                Text = "Database Maintenance & Reseed",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(245, 158, 11),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(10, 24),
                Size = new Size(230, 42),
                Cursor = Cursors.Hand
            };
            btnSeed.FlatAppearance.BorderSize = 0;
            btnSeed.Click += (s, e) =>
            {
                if (MessageBox.Show("Verify and ensure full database seed data (200+ clinical transactions)?", "Database Maintenance", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        using var db = DbContextFactory.Create();
                        db.Database.EnsureCreated();
                        LoadSystemMetrics();
                        LoadAuditLogs();
                        MessageBox.Show("Database status verified! 200+ transactions and tenant subscriptions are active.", "System Administration", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Maintenance error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            };

            p.Controls.Add(btnSeed);
            p.Controls.Add(topBar);
            return p;
        }

        private void LoadSystemMetrics()
        {
            try
            {
                using var db = DbContextFactory.Create();
                int apts = db.Appointments.Count();
                int trts = db.TreatmentRecords.Count();
                int invs = db.BillingInvoices.Count();
                int totalTx = apts + trts + invs;

                lblTotalRecords.Text = $"{totalTx} Transactions";
                int tenantCount = db.Tenants.Count();
                lblActiveTenants.Text = $"{tenantCount} Tenants (A, B, C)";
                lblDbStatus.Text = "Connected (Healthy)";
            }
            catch (Exception ex)
            {
                lblDbStatus.Text = "Offline / " + ex.Message.Substring(0, Math.Min(15, ex.Message.Length));
            }
        }

        private void LoadAuditLogs()
        {
            try
            {
                using var db = DbContextFactory.Create();
                string filter = cmbModuleFilter.SelectedItem?.ToString() ?? "All Modules";

                var query = db.AuditLogs.AsQueryable();
                if (filter != "All Modules")
                {
                    query = query.Where(a => a.Module == filter);
                }

                var list = query
                    .OrderByDescending(a => a.Timestamp)
                    .Take(100)
                    .Select(a => new
                    {
                        Id = a.Id,
                        Timestamp = a.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"),
                        User = a.UserName,
                        Module = a.Module,
                        Action = a.Action,
                        Details = a.Details
                    })
                    .ToList();

                gridAudit.DataSource = list;
                if (gridAudit.Columns["Id"] != null) gridAudit.Columns["Id"].Visible = false;
            }
            catch { }
        }

        private void ShowAddLogDialog()
        {
            using var dlg = new Form
            {
                Text = "Log System Operational Event",
                Size = new Size(460, 360),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            var lblMod = new Label { Text = "Module Category:", Location = new Point(20, 20), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var cmbMod = new ComboBox { Location = new Point(20, 42), Size = new Size(400, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMod.Items.AddRange(new object[] { "System", "Billing", "Appointments", "Tenants", "Subscriptions", "Patients", "Security" });
            cmbMod.SelectedIndex = 0;

            var lblAct = new Label { Text = "Action Code:", Location = new Point(20, 80), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtAct = new TextBox { Location = new Point(20, 102), Size = new Size(400, 26), Text = "ConfigUpdate", Font = new Font("Segoe UI", 9.5F) };

            var lblDet = new Label { Text = "Event Details / Audit Message:", Location = new Point(20, 140), AutoSize = true, Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            var txtDet = new TextBox { Location = new Point(20, 162), Size = new Size(400, 60), Multiline = true, Font = new Font("Segoe UI", 9.5F), Text = "SuperAdmin verified practice and multi-tenant security status." };

            var btnSave = new Button
            {
                Text = "Save Audit Entry",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(2, 132, 199),
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 245),
                Size = new Size(400, 38),
                DialogResult = DialogResult.OK
            };
            btnSave.FlatAppearance.BorderSize = 0;

            dlg.Controls.AddRange(new Control[] { lblMod, cmbMod, lblAct, txtAct, lblDet, txtDet, btnSave });

            if (dlg.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(txtAct.Text))
            {
                using var db = DbContextFactory.Create();
                db.AuditLogs.Add(new AuditLog
                {
                    UserName = Session.CurrentUser?.Email ?? "superadmin@dentalclinic.com",
                    Module = cmbMod.SelectedItem?.ToString() ?? "System",
                    Action = txtAct.Text.Trim(),
                    Details = txtDet.Text.Trim(),
                    Timestamp = DateTime.UtcNow
                });
                db.SaveChanges();
                LoadAuditLogs();
            }
        }

        private void DeleteSelectedLog()
        {
            if (gridAudit.SelectedRows.Count == 0 || gridAudit.SelectedRows[0].Cells["Id"].Value == null) return;
            int logId = Convert.ToInt32(gridAudit.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Delete this audit log record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using var db = DbContextFactory.Create();
                var log = db.AuditLogs.FirstOrDefault(l => l.Id == logId);
                if (log != null)
                {
                    db.AuditLogs.Remove(log);
                    db.SaveChanges();
                    LoadAuditLogs();
                }
            }
        }
    }
}
