using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using DentalClinicSystem.Data;
using DentalClinicSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace DentalClinicWinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Initialize database schema and ensure seed data (200+ transactions & multi-tenants)
            try
            {
                InitializeDatabaseAndSeed();
            }
            catch (Exception ex)
            {
                // Fallback attempt with EnsureCreated
                try
                {
                    using var db = DbContextFactory.Create();
                    db.Database.EnsureCreated();
                }
                catch { }
            }

            Application.Run(new MainForm());
        }

        private static void InitializeDatabaseAndSeed()
        {
            var services = new ServiceCollection();
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(DbContextFactory.ConnectionString));

            services.AddIdentityCore<ApplicationUser>(options =>
            {
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireUppercase = false;
                options.Password.RequiredLength = 6;
            })
            .AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<ApplicationDbContext>();

            services.AddLogging();

            var serviceProvider = services.BuildServiceProvider();

            // Run database migration and seed
            using (var scope = serviceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                try
                {
                    context.Database.Migrate();
                }
                catch
                {
                    context.Database.EnsureCreated();
                }
            }

            // Seed with all roles, users, and 200+ transactions
            DbInitializer.SeedAsync(serviceProvider).GetAwaiter().GetResult();
        }
    }
}
