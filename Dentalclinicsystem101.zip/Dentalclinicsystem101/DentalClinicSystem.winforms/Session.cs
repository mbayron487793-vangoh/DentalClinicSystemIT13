using System;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms
{
    public static class Session
    {
        public static ApplicationUser? CurrentUser { get; set; }
        public static string RoleName { get; set; } = "Guest";

        public static bool IsLoggedIn => CurrentUser != null;
        public static bool IsSuperAdmin => RoleName.Equals("SuperAdmin", StringComparison.OrdinalIgnoreCase);
        public static bool IsAdmin => RoleName.Equals("Admin", StringComparison.OrdinalIgnoreCase);
        public static bool IsDentist => RoleName.Equals("Dentist", StringComparison.OrdinalIgnoreCase);
        public static bool IsStaff => RoleName.Equals("Staff", StringComparison.OrdinalIgnoreCase);
        public static bool IsTenantA => RoleName.Equals("TenantA", StringComparison.OrdinalIgnoreCase) || RoleName.Equals("Tenant A", StringComparison.OrdinalIgnoreCase);
        public static bool IsTenantB => RoleName.Equals("TenantB", StringComparison.OrdinalIgnoreCase) || RoleName.Equals("Tenant B", StringComparison.OrdinalIgnoreCase);
        public static bool IsTenantC => RoleName.Equals("TenantC", StringComparison.OrdinalIgnoreCase) || RoleName.Equals("Tenant C", StringComparison.OrdinalIgnoreCase);
        public static bool IsTenant => IsTenantA || IsTenantB || IsTenantC;

        public static void SetUser(ApplicationUser user, string role)
        {
            CurrentUser = user;
            RoleName = role;
        }

        public static void Logout()
        {
            CurrentUser = null;
            RoleName = "Guest";
        }
    }
}
