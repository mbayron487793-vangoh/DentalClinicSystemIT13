using System;
using DentalClinicSystem.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace DentalClinicWinForms
{
    public static class DbContextFactory
    {
        public static string ConnectionString { get; set; } =
            "Server=(localdb)\\mssqllocaldb;Database=DentalClinicDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";

        public static ApplicationDbContext Create()
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseSqlServer(ConnectionString);
            optionsBuilder.ConfigureWarnings(w => w.Ignore(RelationalEventId.PendingModelChangesWarning));
            return new ApplicationDbContext(optionsBuilder.Options);
        }
    }
}
