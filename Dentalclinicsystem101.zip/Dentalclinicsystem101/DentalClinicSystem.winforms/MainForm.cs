using System;
using System.Drawing;
using System.Windows.Forms;
using DentalClinicSystem.Models;
using DentalClinicWinForms.Views;

namespace DentalClinicWinForms
{
    public class MainForm : Form
    {
        private Panel sidebarPanel = null!;
        private Panel contentPanel = null!;
        private Panel userHeaderPanel = null!;
        private Label lblUserName = null!;
        private Label lblUserRole = null!;
        private FlowLayoutPanel navFlowPanel = null!;
        private Panel moduleTagPanel = null!;

        public MainForm()
        {
            InitializeComponent();
            ShowLoginScreen();
        }

        private void InitializeComponent()
        {
            this.Text = "DentalCare Clinical & Services System (Native Windows Desktop)";
            this.Size = new Size(1366, 768);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(241, 245, 249);

            // Sidebar Panel (Left)
            sidebarPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 268,
                BackColor = Color.FromArgb(15, 23, 42),
                Visible = false
            };

            // Brand Header
            var brandPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 70,
                BackColor = Color.FromArgb(10, 18, 36)
            };

            var lblBrand = new Label
            {
                Text = " DentalCare Pro",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(56, 189, 248),
                Location = new Point(16, 15),
                AutoSize = true
            };

            var lblSubBrand = new Label
            {
                Text = "Clinical & Services System",
                Font = new Font("Segoe UI", 8F, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(20, 42),
                AutoSize = true
            };

            brandPanel.Controls.Add(lblBrand);
            brandPanel.Controls.Add(lblSubBrand);

            // User Profile Header
            userHeaderPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 72,
                BackColor = Color.FromArgb(22, 33, 55),
                Padding = new Padding(15, 10, 15, 10)
            };

            lblUserName = new Label
            {
                Text = "User Name",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(15, 10),
                AutoSize = true
            };

            lblUserRole = new Label
            {
                Text = "ROLE",
                Font = new Font("Segoe UI", 7.5F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(139, 92, 246),
                Location = new Point(15, 34),
                Padding = new Padding(6, 2, 6, 2),
                AutoSize = true
            };

            // Module access tag
            moduleTagPanel = new Panel
            {
                Location = new Point(15, 52),
                Size = new Size(240, 0),
                BackColor = Color.Transparent
            };

            userHeaderPanel.Controls.Add(lblUserName);
            userHeaderPanel.Controls.Add(lblUserRole);
            userHeaderPanel.Controls.Add(moduleTagPanel);

            // Navigation Flow Panel
            navFlowPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(10)
            };

            // Logout Button at Bottom
            var btnLogout = new Button
            {
                Text = "  \u25ba  Logout",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(248, 113, 113),
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Dock = DockStyle.Bottom,
                Height = 45,
                TextAlign = ContentAlignment.MiddleLeft,
                Cursor = Cursors.Hand
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += (s, e) => { LogoutUser(); };

            sidebarPanel.Controls.Add(navFlowPanel);
            sidebarPanel.Controls.Add(userHeaderPanel);
            sidebarPanel.Controls.Add(brandPanel);
            sidebarPanel.Controls.Add(btnLogout);

            // Content Panel (Right)
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(241, 245, 249)
            };

            this.Controls.Add(contentPanel);
            this.Controls.Add(sidebarPanel);
        }

        private void ShowLoginScreen()
        {
            sidebarPanel.Visible = false;
            contentPanel.Controls.Clear();
            var loginControl = new LoginControl((user, role) =>
            {
                Session.SetUser(user, role);
                OnLoginSuccess();
            });
            contentPanel.Controls.Add(loginControl);
        }

        private void OnLoginSuccess()
        {
            lblUserName.Text = Session.CurrentUser?.FullName ?? Session.CurrentUser?.UserName;
            lblUserRole.Text = Session.RoleName.ToUpper();
            lblUserRole.BackColor = Session.RoleName switch
            {
                "SuperAdmin" => Color.FromArgb(220, 38, 38),
                "Admin" => Color.FromArgb(139, 92, 246),
                "Dentist" => Color.FromArgb(14, 165, 233),
                "Staff" => Color.FromArgb(16, 185, 129),
                "TenantA" or "Tenant A" => Color.FromArgb(245, 158, 11),
                "TenantB" or "Tenant B" => Color.FromArgb(99, 102, 241),
                "TenantC" or "Tenant C" => Color.FromArgb(236, 72, 153),
                _ => Color.Gray
            };

            BuildSidebarNavigation();
            sidebarPanel.Visible = true;

            // Default screen based on role / subscription tier
            if (Session.IsSuperAdmin || Session.IsTenant || Session.IsAdmin) LoadView(new TenantDashboardControl());
            else if (Session.IsDentist) LoadView(new PatientsControl());
            else if (Session.IsStaff) LoadView(new BillingControl());
            else LoadView(new BusinessIntelligenceControl());
        }

        private void BuildSidebarNavigation()
        {
            navFlowPanel.Controls.Clear();

            if (Session.RoleName == "SuperAdmin")
            {
                // MASTER / SUPER ADMIN modules: Admin Panel, Business Intelligence / Reports, Subscriptions, Tenants
                AddNavSection("MASTER (SUPER ADMIN)");
                AddNavButton("Dashboard", () => LoadView(new TenantDashboardControl()), true);
                AddNavButton("Admin Panel", () => LoadView(new SystemAdminControl()), false);
                AddNavButton("Business Intelligence", () => LoadView(new BusinessIntelligenceControl()), false);
                AddNavButton("Subscriptions", () => LoadView(new SubscriptionsControl()), false);
                AddNavButton("Tenants", () => LoadView(new TenantsControl()), false);
            }
            else if (Session.IsTenantC)
            {
                // TENANT C modules: Branching, Business Intelligence, Actions
                AddNavSection("TENANT C (ENTERPRISE)");
                AddNavButton("Dashboard", () => LoadView(new TenantDashboardControl()), true);
                AddNavButton("Branching", () => LoadView(new BranchingControl()), false);
                AddNavButton("Business Intelligence", () => LoadView(new BusinessIntelligenceControl()), false);
                AddNavButton("Actions", () => LoadView(new ActionsControl()), false);
            }
            else if (Session.IsTenantB)
            {
                // TENANT B modules: Business Intelligence, Actions
                AddNavSection("TENANT B (PRO TIER)");
                AddNavButton("Dashboard", () => LoadView(new TenantDashboardControl()), true);
                AddNavButton("Business Intelligence", () => LoadView(new BusinessIntelligenceControl()), false);
                AddNavButton("Actions", () => LoadView(new ActionsControl()), false);
            }
            else if (Session.IsTenantA)
            {
                // TENANT A modules: Main transaction, Data Collection
                AddNavSection("TENANT A (CORE TIER)");
                AddNavButton("Dashboard", () => LoadView(new TenantDashboardControl()), true);
                AddNavButton("Main transaction", () => LoadView(new MainTransactionsControl()), false);
                AddNavButton("Data Collection", () => LoadView(new DataCollectionControl()), false);
            }
            else if (Session.IsAdmin)
            {
                // CLINIC ADMIN modules: User Management, Business Intelligence, Sales Service, Promotion, Manage Dental Services, Manage Patient Records
                AddNavSection("ADMINISTRATOR");
                AddNavButton("Dashboard", () => LoadView(new TenantDashboardControl()), true);
                AddNavButton("User Management", () => LoadView(new UserManagementControl()), false);
                AddNavButton("Business Intelligence", () => LoadView(new BusinessIntelligenceControl()), false);
                AddNavButton("Sales Service", () => LoadView(new SalesControl()), false);
                AddNavButton("Promotion", () => LoadView(new PromotionsControl()), false);
                AddNavButton("Manage Dental Services", () => LoadView(new ServicesControl()), false);
                AddNavButton("Manage Patient Records", () => LoadView(new PatientsControl()), false);
            }
            else if (Session.IsDentist)
            {
                // DENTIST modules: View Patient Records, View Appointments, Manage Treatments Records, Track Treatment History
                AddNavSection("DENTIST");
                AddNavButton("View Patient Records", () => LoadView(new PatientsControl()), true);
                AddNavButton("View Appointments", () => LoadView(new AppointmentsControl()), false);
                AddNavButton("Manage Treatments Records", () => LoadView(new TreatmentsControl()), false);
                AddNavButton("Track Treatment History", () => LoadView(new TreatmentHistoryControl()), false);
            }
            else if (Session.IsStaff)
            {
                // STAFF modules: Manage Patient Records, Process Billing, Schedule Appointments, Send Appointment Reminders
                AddNavSection("STAFF");
                AddNavButton("Manage Patient Records", () => LoadView(new PatientsControl()), false);
                AddNavButton("Process Billing", () => LoadView(new BillingControl()), true);
                AddNavButton("Schedule Appointments", () => LoadView(new AppointmentsControl()), false);
                AddNavButton("Send Appointment Reminders", () => LoadView(new RemindersControl()), false);
            }
        }

        private void AddNavSection(string sectionTitle)
        {
            var lbl = new Label
            {
                Text = sectionTitle,
                Font = new Font("Segoe UI", 7.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(71, 85, 105),
                Size = new Size(246, 22),
                Margin = new Padding(0, 10, 0, 2),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0)
            };
            navFlowPanel.Controls.Add(lbl);
        }

        private void AddNavButton(string title, Action onClick, bool isDefault)
        {
            var btn = new Button
            {
                Text = "   " + title,
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = isDefault ? Color.White : Color.FromArgb(203, 213, 225),
                BackColor = isDefault ? Color.FromArgb(2, 100, 175) : Color.FromArgb(15, 23, 42),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(246, 40),
                Margin = new Padding(0, 1, 0, 1),
                TextAlign = ContentAlignment.MiddleLeft,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) =>
            {
                // Reset all buttons
                foreach (Control c in navFlowPanel.Controls)
                {
                    if (c is Button b)
                    {
                        b.BackColor = Color.FromArgb(15, 23, 42);
                        b.ForeColor = Color.FromArgb(203, 213, 225);
                        b.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
                    }
                }
                // Highlight active
                btn.BackColor = Color.FromArgb(2, 100, 175);
                btn.ForeColor = Color.White;
                btn.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
                onClick();
            };

            if (isDefault)
            {
                btn.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            }

            navFlowPanel.Controls.Add(btn);
        }

        private void LoadView(Control viewControl)
        {
            contentPanel.Controls.Clear();
            viewControl.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(viewControl);
        }

        private void LogoutUser()
        {
            Session.Logout();
            ShowLoginScreen();
        }
    }
}

