using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using DentalClinicSystem.Models;

namespace DentalClinicWinForms.Services
{
    public static class PdfInvoiceGenerator
    {
        public static string GenerateInvoicePdf(BillingInvoice invoice, string? outputPath = null)
        {
            if (outputPath == null)
            {
                var folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Invoices");
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
                outputPath = Path.Combine(folder, $"Invoice_{invoice.InvoiceNumber}_{DateTime.Now:yyyyMMddHHmmss}.pdf");
            }

            var sb = new StringBuilder();
            // PDF stream content (units in points: 72 points = 1 inch. Letter size = 612 x 792)
            var content = new StringBuilder();

            // Helpers for drawing in PDF stream
            // Primary colors
            // Dark Header bar (0, 51, 102) -> 0.05 0.20 0.40
            content.AppendLine("0.06 0.15 0.30 rg");
            content.AppendLine("36 710 540 50 re f"); // Header rectangle

            // Header text (White)
            content.AppendLine("BT /F2 18 Tf 1 1 1 rg 50 728 Td (DENTALCARE CLINICAL & SERVICES SYSTEM) Tj ET");
            content.AppendLine("BT /F1 9 Tf 0.8 0.9 1 rg 50 716 Td (Premier Dental Healthcare - Official Billing Invoice & Receipt) Tj ET");

            // Invoice Title & Status Badge
            content.AppendLine("BT /F2 16 Tf 0.1 0.15 0.25 rg 36 675 Td (INVOICE / CLINICAL STATEMENT) Tj ET");
            
            // Status tag
            string statusColor = invoice.Status == InvoiceStatus.Paid ? "0.08 0.6 0.3" : (invoice.Status == InvoiceStatus.PartiallyPaid ? "0.9 0.5 0.1" : "0.8 0.2 0.2");
            content.AppendLine($"{statusColor} rg");
            content.AppendLine("460 670 116 22 re f");
            content.AppendLine($"BT /F2 10 Tf 1 1 1 rg 472 676 Td (STATUS: {invoice.Status.ToString().ToUpper()}) Tj ET");

            // Horizontal line
            content.AppendLine("0.8 0.85 0.9 RG 1.5 w 36 660 m 576 660 l S");

            // Invoice Meta & Patient Details
            content.AppendLine("BT /F2 10 Tf 0.15 0.2 0.3 rg 36 640 Td (INVOICE DETAILS:) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 36 625 Td (Invoice Number: {EscapePdf(invoice.InvoiceNumber)}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 36 612 Td (Date of Issue: {invoice.InvoiceDate:MMMM dd, yyyy}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 36 599 Td (Due Date: {invoice.DueDate:MMMM dd, yyyy}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 36 586 Td (Created On: {invoice.CreatedAt:yyyy-MM-dd HH:mm}) Tj ET");

            // Patient Info Box (Right Side)
            content.AppendLine("BT /F2 10 Tf 0.15 0.2 0.3 rg 310 640 Td (PATIENT INFORMATION:) Tj ET");
            string patientName = invoice.Patient != null ? $"{invoice.Patient.FirstName} {invoice.Patient.LastName}" : "Valued Patient";
            string patientCode = invoice.Patient?.PatientCode ?? "PAT-N/A";
            string patientPhone = invoice.Patient?.Phone ?? "N/A";
            string patientEmail = invoice.Patient?.Email ?? "N/A";

            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 310 625 Td (Full Name: {EscapePdf(patientName)}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 310 612 Td (Patient Code: {EscapePdf(patientCode)}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 310 599 Td (Contact Phone: {EscapePdf(patientPhone)}) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.2 0.2 0.2 rg 310 586 Td (Email Address: {EscapePdf(patientEmail)}) Tj ET");

            // Table Header
            content.AppendLine("0.92 0.94 0.97 rg 36 545 540 22 re f");
            content.AppendLine("0.75 0.80 0.88 RG 1 w 36 545 540 22 re S");
            content.AppendLine("BT /F2 9.5 Tf 0.1 0.15 0.25 rg 46 552 Td (SERVICE / PROCEDURE DESCRIPTION) Tj ET");
            content.AppendLine("BT /F2 9.5 Tf 0.1 0.15 0.25 rg 380 552 Td (QTY) Tj ET");
            content.AppendLine("BT /F2 9.5 Tf 0.1 0.15 0.25 rg 430 552 Td (UNIT PRICE) Tj ET");
            content.AppendLine("BT /F2 9.5 Tf 0.1 0.15 0.25 rg 515 552 Td (TOTAL) Tj ET");

            // Line items
            int yPos = 525;
            if (invoice.Items != null && invoice.Items.Count > 0)
            {
                foreach (var item in invoice.Items)
                {
                    content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 46 {yPos} Td ({EscapePdf(item.Description)}) Tj ET");
                    content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 388 {yPos} Td ({item.Quantity}) Tj ET");
                    content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 430 {yPos} Td (${item.UnitPrice:N2}) Tj ET");
                    content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 515 {yPos} Td (${item.LineTotal:N2}) Tj ET");
                    content.AppendLine($"0.9 0.9 0.9 RG 0.5 w 36 {yPos - 5} m 576 {yPos - 5} l S");
                    yPos -= 22;
                }
            }
            else
            {
                content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 46 {yPos} Td (Comprehensive Clinical Treatment & Dental Services) Tj ET");
                content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 388 {yPos} Td (1) Tj ET");
                content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 430 {yPos} Td (${invoice.SubTotal:N2}) Tj ET");
                content.AppendLine($"BT /F1 9 Tf 0.15 0.15 0.15 rg 515 {yPos} Td (${invoice.SubTotal:N2}) Tj ET");
                content.AppendLine($"0.9 0.9 0.9 RG 0.5 w 36 {yPos - 5} m 576 {yPos - 5} l S");
                yPos -= 22;
            }

            // Summary Totals Box (Right aligned)
            int totalsY = yPos - 15;
            content.AppendLine($"0.96 0.97 0.99 rg 340 {totalsY - 95} 236 105 re f");
            content.AppendLine($"0.8 0.85 0.9 RG 1 w 340 {totalsY - 95} 236 105 re S");

            content.AppendLine($"BT /F1 9 Tf 0.3 0.3 0.3 rg 355 {totalsY - 15} Td (Subtotal:) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.1 0.1 0.1 rg 515 {totalsY - 15} Td (${invoice.SubTotal:N2}) Tj ET");

            content.AppendLine($"BT /F1 9 Tf 0.3 0.3 0.3 rg 355 {totalsY - 32} Td (Discount Applied:) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.1 0.6 0.2 rg 505 {totalsY - 32} Td (-${invoice.DiscountAmount:N2}) Tj ET");

            content.AppendLine($"BT /F1 9 Tf 0.3 0.3 0.3 rg 355 {totalsY - 49} Td (Tax / VAT (5%):) Tj ET");
            content.AppendLine($"BT /F1 9 Tf 0.1 0.1 0.1 rg 515 {totalsY - 49} Td (${invoice.TaxAmount:N2}) Tj ET");

            content.AppendLine($"0.75 0.8 0.85 RG 1 w 350 {totalsY - 58} m 565 {totalsY - 58} l S");

            content.AppendLine($"BT /F2 10.5 Tf 0.06 0.15 0.3 rg 355 {totalsY - 73} Td (Total Amount:) Tj ET");
            content.AppendLine($"BT /F2 10.5 Tf 0.06 0.15 0.3 rg 510 {totalsY - 73} Td (${invoice.TotalAmount:N2}) Tj ET");

            content.AppendLine($"BT /F1 9 Tf 0.1 0.5 0.2 rg 355 {totalsY - 88} Td (Amount Paid:) Tj ET");
            content.AppendLine($"BT /F2 9.5 Tf 0.1 0.5 0.2 rg 510 {totalsY - 88} Td (${invoice.AmountPaid:N2}) Tj ET");

            // Balance Due Callout
            int balanceY = totalsY - 130;
            if (invoice.BalanceDue > 0)
            {
                content.AppendLine($"0.98 0.92 0.92 rg 340 {balanceY} 236 28 re f");
                content.AppendLine($"0.85 0.3 0.3 RG 1 w 340 {balanceY} 236 28 re S");
                content.AppendLine($"BT /F2 10 Tf 0.7 0.1 0.1 rg 355 {balanceY + 9} Td (BALANCE DUE:) Tj ET");
                content.AppendLine($"BT /F2 11 Tf 0.7 0.1 0.1 rg 505 {balanceY + 9} Td (${invoice.BalanceDue:N2}) Tj ET");
            }
            else
            {
                content.AppendLine($"0.92 0.98 0.93 rg 340 {balanceY} 236 28 re f");
                content.AppendLine($"0.2 0.7 0.3 RG 1 w 340 {balanceY} 236 28 re S");
                content.AppendLine($"BT /F2 10 Tf 0.1 0.5 0.2 rg 355 {balanceY + 9} Td (BALANCE DUE:) Tj ET");
                content.AppendLine($"BT /F2 11 Tf 0.1 0.5 0.2 rg 505 {balanceY + 9} Td ($0.00 PAID) Tj ET");
            }

            // Payment History / Notes
            content.AppendLine($"BT /F2 10 Tf 0.15 0.2 0.3 rg 36 {totalsY - 20} Td (PAYMENT & REMARKS:) Tj ET");
            content.AppendLine($"BT /F1 8.5 Tf 0.3 0.3 0.3 rg 36 {totalsY - 36} Td (Payment Terms: Net Due Upon Clinical Service) Tj ET");
            content.AppendLine($"BT /F1 8.5 Tf 0.3 0.3 0.3 rg 36 {totalsY - 50} Td (Accepted Methods: Cash, Credit Card, GCash, Health Insurance) Tj ET");
            string invoiceNotes = !string.IsNullOrEmpty(invoice.Notes) ? invoice.Notes : "Thank you for trusting DentalCare.";
            content.AppendLine($"BT /F1 8.5 Tf 0.4 0.4 0.4 rg 36 {totalsY - 64} Td (Note: {EscapePdf(invoiceNotes)}) Tj ET");

            // Footer
            content.AppendLine("0.8 0.85 0.9 RG 1 w 36 60 m 576 60 l S");
            content.AppendLine("BT /F1 8 Tf 0.4 0.45 0.5 rg 36 45 Td (DentalCare Clinic - 100 Pine Crest Blvd, Suite 24, New York, NY - Tel: +1 (555) 010-0001 - Email: support@dentalcare.com) Tj ET");
            content.AppendLine("BT /F1 7.5 Tf 0.5 0.55 0.6 rg 36 32 Td (This document is a computer-generated official billing invoice. Valid without physical signature.) Tj ET");

            string streamData = content.ToString();
            byte[] streamBytes = Encoding.ASCII.GetBytes(streamData);

            // Construct PDF document objects
            var objects = new List<string>();
            objects.Add("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj");
            objects.Add("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj");
            objects.Add("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj");
            objects.Add($"4 0 obj\n<< /Length {streamBytes.Length} >>\nstream\n{streamData}\nendstream\nendobj");
            objects.Add("5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj");
            objects.Add("6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj");

            using var fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write);
            using var writer = new StreamWriter(fs, Encoding.ASCII);

            writer.Write("%PDF-1.4\n");
            writer.Flush();

            var offsets = new List<long>();
            offsets.Add(0); // dummy for index 0

            for (int i = 0; i < objects.Count; i++)
            {
                offsets.Add(fs.Position);
                writer.Write(objects[i] + "\n");
                writer.Flush();
            }

            long xrefOffset = fs.Position;
            writer.Write("xref\n");
            writer.Write($"0 {objects.Count + 1}\n");
            writer.Write("0000000000 65535 f \n");
            for (int i = 1; i <= objects.Count; i++)
            {
                writer.Write($"{offsets[i]:D10} 00000 n \n");
            }

            writer.Write("trailer\n");
            writer.Write($"<< /Size {objects.Count + 1} /Root 1 0 R >>\n");
            writer.Write("startxref\n");
            writer.Write($"{xrefOffset}\n");
            writer.Write("%%EOF\n");
            writer.Flush();

            return outputPath;
        }

        public static void OpenPdf(string filePath)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = filePath,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show($"Could not automatically open PDF viewer: {ex.Message}\nSaved location: {filePath}", "PDF Saved", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
            }
        }

        private static string EscapePdf(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)");
        }
    }
}
