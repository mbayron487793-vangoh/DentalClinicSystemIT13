using System;
using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class Tenant
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string TenantName { get; set; } = string.Empty;

        [Required, MaxLength(30)]
        public string TenantCode { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string SubscriptionTier { get; set; } = "Tenant A"; // "Tenant A", "Tenant B", "Tenant C"

        [Required, MaxLength(100)]
        public string ContactEmail { get; set; } = string.Empty;

        [Required, MaxLength(30)]
        public string ContactPhone { get; set; } = string.Empty;

        [MaxLength(250)]
        public string Address { get; set; } = string.Empty;

        [MaxLength(30)]
        public string Status { get; set; } = "Active"; // Active, Suspended, Trial

        public int BranchesCount { get; set; } = 1;
        public int ActiveUsersCount { get; set; } = 5;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
