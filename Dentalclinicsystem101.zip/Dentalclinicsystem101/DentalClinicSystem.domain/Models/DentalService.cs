using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DentalClinicSystem.Models
{
    public class DentalService
    {
        public int Id { get; set; }

        [Required, MaxLength(20)]
        [Display(Name = "Service Code")]
        public string ServiceCode { get; set; } = string.Empty; // e.g. DNT-CLN, DNT-EXT

        [Required, MaxLength(100)]
        [Display(Name = "Service Name")]
        public string Name { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        [Display(Name = "Category")]
        public string Category { get; set; } = "General"; // Preventive, Restorative, Cosmetic, Orthodontics, Surgery, Periodontics, Endodontics

        [MaxLength(500)]
        public string? Description { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Range(0, 100000)]
        [Display(Name = "Standard Price ($)")]
        public decimal StandardPrice { get; set; }

        [Display(Name = "Duration (Minutes)")]
        [Range(10, 360)]
        public int EstimatedDurationMinutes { get; set; } = 30;

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
        public virtual ICollection<TreatmentRecord> TreatmentRecords { get; set; } = new List<TreatmentRecord>();
        public virtual ICollection<InvoiceItem> InvoiceItems { get; set; } = new List<InvoiceItem>();
    }
}
