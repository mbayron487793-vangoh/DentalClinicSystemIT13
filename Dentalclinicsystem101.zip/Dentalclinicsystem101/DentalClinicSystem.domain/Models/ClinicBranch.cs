using System;
using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class ClinicBranch
    {
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string BranchCode { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string BranchName { get; set; } = string.Empty;

        [MaxLength(100)]
        public string CityLocation { get; set; } = string.Empty;

        [MaxLength(200)]
        public string Address { get; set; } = string.Empty;

        [MaxLength(30)]
        public string PhoneNumber { get; set; } = string.Empty;

        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [MaxLength(100)]
        public string HeadDentistOrManager { get; set; } = string.Empty;

        public int DentalChairsCount { get; set; } = 4;
        public decimal MonthlyRevenue { get; set; } = 0m;
        public bool IsActive { get; set; } = true;

        [MaxLength(50)]
        public string AssignedTenantTier { get; set; } = "Tenant C";

        public DateTime EstablishedDate { get; set; } = DateTime.UtcNow;
    }
}
