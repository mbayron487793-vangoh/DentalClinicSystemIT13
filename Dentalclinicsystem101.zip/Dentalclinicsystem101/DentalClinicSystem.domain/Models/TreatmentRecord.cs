using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DentalClinicSystem.Models
{
    public class TreatmentRecord
    {
        public int Id { get; set; }

        [Required, MaxLength(30)]
        [Display(Name = "Treatment #")]
        public string RecordNumber { get; set; } = string.Empty; // e.g. TRT-2024-0001

        [Required]
        [Display(Name = "Patient")]
        public int PatientId { get; set; }
        public virtual Patient? Patient { get; set; }

        [Required]
        [Display(Name = "Dentist")]
        public string DentistId { get; set; } = string.Empty;
        public virtual ApplicationUser? Dentist { get; set; }

        public int? AppointmentId { get; set; }
        public virtual Appointment? Appointment { get; set; }

        [Required]
        [Display(Name = "Dental Service")]
        public int ServiceId { get; set; }
        public virtual DentalService? DentalService { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Treatment Date")]
        public DateTime TreatmentDate { get; set; } = DateTime.UtcNow.Date;

        [Required, MaxLength(100)]
        [Display(Name = "Tooth / Area")]
        public string ToothNumber { get; set; } = "General / All Teeth"; // e.g. Tooth #14 (Maxillary Left 1st Molar), Tooth #18, Upper Arch, All

        [Required, MaxLength(250)]
        [Display(Name = "Clinical Diagnosis")]
        public string Diagnosis { get; set; } = string.Empty;

        [Required, MaxLength(2000)]
        [Display(Name = "Procedure Executed / Clinical Notes")]
        public string ProcedureNotes { get; set; } = string.Empty;

        [MaxLength(1000)]
        [Display(Name = "Prescription & Medication")]
        public string? Prescriptions { get; set; } // e.g. Amoxicillin 500mg tid x 7d; Ibuprofen 400mg prn

        [DataType(DataType.Date)]
        [Display(Name = "Next Follow-Up Date")]
        public DateTime? NextFollowUpDate { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Treatment Cost ($)")]
        public decimal Cost { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual BillingInvoice? BillingInvoice { get; set; }
    }
}
