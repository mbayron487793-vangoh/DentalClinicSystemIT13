using System;
using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class SystemAction
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string ActionTitle { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string ActionCategory { get; set; } = "Clinical Task"; // Clinical Task, Workflow Approval, Emergency Protocol, Inventory Request

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        [MaxLength(20)]
        public string Priority { get; set; } = "Normal"; // Urgent, High, Normal, Low

        [MaxLength(30)]
        public string Status { get; set; } = "Pending"; // Pending, In Progress, Approved, Completed, Cancelled

        [MaxLength(100)]
        public string AssignedTo { get; set; } = string.Empty;

        [MaxLength(100)]
        public string RequestedBy { get; set; } = string.Empty;

        [MaxLength(50)]
        public string TargetTenantTier { get; set; } = "Tenant B / C";

        public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(2);
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
