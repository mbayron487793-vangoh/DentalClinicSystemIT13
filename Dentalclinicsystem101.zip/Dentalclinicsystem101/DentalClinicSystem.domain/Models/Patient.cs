using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class Patient
    {
        public int Id { get; set; }

        [Required, MaxLength(20)]
        [Display(Name = "Patient Code")]
        public string PatientCode { get; set; } = string.Empty; // e.g. PAT-1001

        [Required, MaxLength(50)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Display(Name = "Full Name")]
        public string FullName => $"{FirstName} {LastName}";

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        public DateTime DateOfBirth { get; set; }

        [Required, MaxLength(10)]
        public string Gender { get; set; } = "Male"; // Male, Female, Other

        [Required, MaxLength(20)]
        [Phone]
        [Display(Name = "Phone Number")]
        public string Phone { get; set; } = string.Empty;

        [EmailAddress, MaxLength(100)]
        public string? Email { get; set; }

        [MaxLength(200)]
        public string? Address { get; set; }

        [MaxLength(100)]
        [Display(Name = "Emergency Contact")]
        public string? EmergencyContact { get; set; }

        [MaxLength(10)]
        [Display(Name = "Blood Type")]
        public string? BloodType { get; set; } // O+, A+, B+, AB+, etc.

        [MaxLength(500)]
        public string? Allergies { get; set; } // Penicillin, Latex, Local Anesthetic, etc.

        [MaxLength(1000)]
        [Display(Name = "Medical History Notes")]
        public string? MedicalHistoryNotes { get; set; } // Hypertension, Diabetes, Asthma, None

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        // Navigation
        public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
        public virtual ICollection<TreatmentRecord> TreatmentRecords { get; set; } = new List<TreatmentRecord>();
        public virtual ICollection<BillingInvoice> BillingInvoices { get; set; } = new List<BillingInvoice>();
    }
}
