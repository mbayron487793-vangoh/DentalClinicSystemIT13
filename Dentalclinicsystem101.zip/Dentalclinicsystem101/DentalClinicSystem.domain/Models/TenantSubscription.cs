using System;
using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class TenantSubscription
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string TenantName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string SubscriptionTier { get; set; } = "Tenant A"; // Tenant A, Tenant B, Tenant C

        [Required, MaxLength(100)]
        public string PlanName { get; set; } = string.Empty;

        public decimal MonthlyPrice { get; set; }

        [MaxLength(20)]
        public string BillingCycle { get; set; } = "Monthly"; // Monthly, Annual

        public DateTime StartDate { get; set; } = DateTime.UtcNow;
        public DateTime EndDate { get; set; } = DateTime.UtcNow.AddYears(1);

        [MaxLength(30)]
        public string Status { get; set; } = "Active"; // Active, PastDue, Cancelled

        [MaxLength(100)]
        public string ContactEmail { get; set; } = string.Empty;

        [MaxLength(30)]
        public string ContactPhone { get; set; } = string.Empty;

        public DateTime? LastInformedDate { get; set; }

        [MaxLength(200)]
        public string LastNotificationStatus { get; set; } = "None";

        [MaxLength(500)]
        public string AllowedModulesSummary { get; set; } = string.Empty;
    }
}
