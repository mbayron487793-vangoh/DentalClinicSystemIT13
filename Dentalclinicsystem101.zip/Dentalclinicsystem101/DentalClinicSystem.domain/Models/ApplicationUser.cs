using Microsoft.AspNetCore.Identity;

namespace DentalClinicSystem.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FullName { get; set; } = string.Empty;
        public string RoleName { get; set; } = string.Empty; // SuperAdmin, Admin, Staff, Dentist
        public string? Specialization { get; set; } // e.g. Orthodontics, General Dentistry, Oral Surgery
        public string? LicenseNumber { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime HireDate { get; set; } = DateTime.UtcNow;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual ICollection<Appointment> DentistAppointments { get; set; } = new List<Appointment>();
        public virtual ICollection<TreatmentRecord> DentistTreatments { get; set; } = new List<TreatmentRecord>();
    }
}
