using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public enum ReminderChannel
    {
        SMS,
        Email,
        WhatsApp,
        PhoneCall
    }

    public enum ReminderStatus
    {
        Pending,
        Sent,
        Delivered,
        Failed
    }

    public class AppointmentReminder
    {
        public int Id { get; set; }

        [Required]
        public int AppointmentId { get; set; }
        public virtual Appointment? Appointment { get; set; }

        [Required]
        public int PatientId { get; set; }
        public virtual Patient? Patient { get; set; }

        [Required]
        [Display(Name = "Channel")]
        public ReminderChannel Channel { get; set; } = ReminderChannel.SMS;

        [Required]
        [Display(Name = "Recipient Contact")]
        public string RecipientContact { get; set; } = string.Empty; // phone or email

        [Required, MaxLength(500)]
        [Display(Name = "Message Content")]
        public string MessageContent { get; set; } = string.Empty;

        [Display(Name = "Scheduled Time")]
        public DateTime ScheduledTime { get; set; } = DateTime.UtcNow;

        [Display(Name = "Sent Time")]
        public DateTime? SentTime { get; set; }

        [Required]
        [Display(Name = "Status")]
        public ReminderStatus Status { get; set; } = ReminderStatus.Pending;

        [MaxLength(200)]
        public string? DeliveryNote { get; set; }
    }
}
