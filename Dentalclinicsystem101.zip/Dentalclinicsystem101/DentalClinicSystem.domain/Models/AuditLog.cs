using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public class AuditLog
    {
        public int Id { get; set; }

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        [Required, MaxLength(100)]
        public string UserName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string Action { get; set; } = string.Empty; // Create, Update, Delete, Login, Payment, ReminderSent

        [Required, MaxLength(50)]
        public string Module { get; set; } = string.Empty; // Patients, Appointments, Treatments, Billing, Services, Users

        [MaxLength(1000)]
        public string Details { get; set; } = string.Empty;

        [MaxLength(50)]
        public string? IpAddress { get; set; }
    }
}
