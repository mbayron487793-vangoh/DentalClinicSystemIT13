using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DentalClinicSystem.Models
{
    public enum PaymentMethod
    {
        Cash,
        CreditCard,
        DebitCard,
        Insurance,
        GCash,
        BankTransfer
    }

    public class Payment
    {
        public int Id { get; set; }

        [Required, MaxLength(30)]
        [Display(Name = "Payment Ref #")]
        public string PaymentReference { get; set; } = string.Empty; // e.g. PAY-2024-0001

        [Required]
        [Display(Name = "Invoice")]
        public int InvoiceId { get; set; }
        public virtual BillingInvoice? Invoice { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        [Display(Name = "Payment Date")]
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Range(0.01, 1000000)]
        [Display(Name = "Amount ($)")]
        public decimal Amount { get; set; }

        [Required]
        [Display(Name = "Payment Method")]
        public PaymentMethod Method { get; set; } = PaymentMethod.Cash;

        [MaxLength(100)]
        [Display(Name = "Transaction / Check / Approval Ref")]
        public string? TransactionReference { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }

        public string? ReceivedByUserId { get; set; }
        public virtual ApplicationUser? ReceivedByUser { get; set; }
    }
}
