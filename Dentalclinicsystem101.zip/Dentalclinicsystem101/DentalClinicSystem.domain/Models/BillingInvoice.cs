using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DentalClinicSystem.Models
{
    public enum InvoiceStatus
    {
        Unpaid,
        PartiallyPaid,
        Paid,
        Cancelled
    }

    public class BillingInvoice
    {
        public int Id { get; set; }

        [Required, MaxLength(30)]
        [Display(Name = "Invoice #")]
        public string InvoiceNumber { get; set; } = string.Empty; // e.g. INV-2024-0001

        [Required]
        [Display(Name = "Patient")]
        public int PatientId { get; set; }
        public virtual Patient? Patient { get; set; }

        public int? AppointmentId { get; set; }
        public virtual Appointment? Appointment { get; set; }

        public int? TreatmentRecordId { get; set; }
        public virtual TreatmentRecord? TreatmentRecord { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Invoice Date")]
        public DateTime InvoiceDate { get; set; } = DateTime.UtcNow.Date;

        [DataType(DataType.Date)]
        [Display(Name = "Due Date")]
        public DateTime DueDate { get; set; } = DateTime.UtcNow.Date.AddDays(7);

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Sub Total ($)")]
        public decimal SubTotal { get; set; }

        public int? PromotionId { get; set; }
        public virtual Promotion? Promotion { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Discount ($)")]
        public decimal DiscountAmount { get; set; } = 0;

        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Tax / VAT ($)")]
        public decimal TaxAmount { get; set; } = 0;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Total Amount ($)")]
        public decimal TotalAmount { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Amount Paid ($)")]
        public decimal AmountPaid { get; set; } = 0;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Balance Due ($)")]
        public decimal BalanceDue { get; set; }

        [Required]
        [Display(Name = "Status")]
        public InvoiceStatus Status { get; set; } = InvoiceStatus.Unpaid;

        [MaxLength(500)]
        public string? Notes { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual ICollection<InvoiceItem> Items { get; set; } = new List<InvoiceItem>();
        public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
    }
}
