using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DentalClinicSystem.Models
{
    public enum DiscountType
    {
        Percentage,
        FixedAmount
    }

    public class Promotion
    {
        public int Id { get; set; }

        [Required, MaxLength(30)]
        [Display(Name = "Promo Code")]
        public string PromoCode { get; set; } = string.Empty; // e.g. SMILE20, SUMMER50

        [Required, MaxLength(100)]
        [Display(Name = "Promotion Title")]
        public string Title { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        [Required]
        [Display(Name = "Discount Type")]
        public DiscountType DiscountType { get; set; } = DiscountType.Percentage;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Discount Value")]
        public decimal DiscountValue { get; set; } // e.g. 15 for 15% or 50.00 for $50 off

        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; } = DateTime.UtcNow.Date;

        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; } = DateTime.UtcNow.Date.AddMonths(1);

        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Min Spend ($)")]
        public decimal MinSpend { get; set; } = 0;

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual ICollection<BillingInvoice> AppliedInvoices { get; set; } = new List<BillingInvoice>();
    }
}
