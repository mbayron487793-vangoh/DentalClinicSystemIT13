using System.ComponentModel.DataAnnotations;

namespace DentalClinicSystem.Models
{
    public enum AppointmentStatus
    {
        Scheduled,
        Confirmed,
        InProgress,
        Completed,
        Cancelled,
        NoShow
    }

    public class Appointment
    {
        public int Id { get; set; }

        [Required, MaxLength(30)]
        [Display(Name = "Appointment #")]
        public string AppointmentNumber { get; set; } = string.Empty; // e.g. APT-2024-0001

        [Required]
        [Display(Name = "Patient")]
        public int PatientId { get; set; }
        public virtual Patient? Patient { get; set; }

        [Required]
        [Display(Name = "Dentist")]
        public string DentistId { get; set; } = string.Empty;
        public virtual ApplicationUser? Dentist { get; set; }

        [Required]
        [Display(Name = "Service")]
        public int ServiceId { get; set; }
        public virtual DentalService? DentalService { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Appointment Date")]
        public DateTime AppointmentDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Start Time")]
        public TimeSpan StartTime { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "End Time")]
        public TimeSpan EndTime { get; set; }

        [Required]
        [Display(Name = "Status")]
        public AppointmentStatus Status { get; set; } = AppointmentStatus.Scheduled;

        [MaxLength(250)]
        [Display(Name = "Reason / Symptoms")]
        public string? ReasonForVisit { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }

        [Display(Name = "Reminder Sent")]
        public bool ReminderSent { get; set; } = false;

        [Display(Name = "Reminder Sent At")]
        public DateTime? ReminderSentAt { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual ICollection<AppointmentReminder> Reminders { get; set; } = new List<AppointmentReminder>();
        public virtual TreatmentRecord? TreatmentRecord { get; set; }
        public virtual BillingInvoice? BillingInvoice { get; set; }
    }
}
