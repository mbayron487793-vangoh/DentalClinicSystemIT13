﻿namespace DentalClinicSystem.domain
{
    public class Class1
    {
    }
}
