﻿namespace DentalClinicSystem.infrastructure
{
    public class Class1
    {
    }
}
