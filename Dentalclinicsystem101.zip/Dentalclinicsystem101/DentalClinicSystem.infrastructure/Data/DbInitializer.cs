using DentalClinicSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace DentalClinicSystem.Data
{
    public static class DbInitializer
    {
        public static async Task SeedAsync(IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            // Ensure database and migrations are applied
            try
            {
                await context.Database.MigrateAsync();
            }
            catch
            {
                await context.Database.EnsureCreatedAsync();
            }

            // 1. Seed Roles
            string[] roles = new[] { "SuperAdmin", "Admin", "Staff", "Dentist", "TenantA", "TenantB", "TenantC" };
            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            // 2. Seed Users
            var superAdminEmail = "superadmin@dentalclinic.com";
            var superAdmin = await userManager.FindByEmailAsync(superAdminEmail);
            if (superAdmin == null)
            {
                superAdmin = new ApplicationUser
                {
                    UserName = superAdminEmail,
                    Email = superAdminEmail,
                    FullName = "Super Administrator",
                    RoleName = "SuperAdmin",
                    PhoneNumber = "+1 (555) 010-0001",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddYears(-3)
                };
                await userManager.CreateAsync(superAdmin, "Admin@123456");
                await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");
            }

            var adminEmail = "admin@dentalclinic.com";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);
            if (adminUser == null)
            {
                adminUser = new ApplicationUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    FullName = "Elena Rostova (Clinic Director)",
                    RoleName = "Admin",
                    PhoneNumber = "+1 (555) 010-0002",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddYears(-2)
                };
                await userManager.CreateAsync(adminUser, "Admin@123456");
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            var staffEmail = "staff@dentalclinic.com";
            var staffUser = await userManager.FindByEmailAsync(staffEmail);
            if (staffUser == null)
            {
                staffUser = new ApplicationUser
                {
                    UserName = staffEmail,
                    Email = staffEmail,
                    FullName = "Jessica Sanchez (Front Desk)",
                    RoleName = "Staff",
                    PhoneNumber = "+1 (555) 010-0003",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddMonths(-14)
                };
                await userManager.CreateAsync(staffUser, "Staff@123456");
                await userManager.AddToRoleAsync(staffUser, "Staff");
            }

            // Dentists
            var dentist1Email = "dr.smith@dentalclinic.com";
            var dentist1 = await userManager.FindByEmailAsync(dentist1Email);
            if (dentist1 == null)
            {
                dentist1 = new ApplicationUser
                {
                    UserName = dentist1Email,
                    Email = dentist1Email,
                    FullName = "Dr. Alexander Smith, DDS",
                    RoleName = "Dentist",
                    Specialization = "Orthodontics & Implantology",
                    LicenseNumber = "DDS-NY-84920",
                    PhoneNumber = "+1 (555) 010-0004",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddYears(-4)
                };
                await userManager.CreateAsync(dentist1, "Dentist@123456");
                await userManager.AddToRoleAsync(dentist1, "Dentist");
            }

            var dentist2Email = "dr.sarah@dentalclinic.com";
            var dentist2 = await userManager.FindByEmailAsync(dentist2Email);
            if (dentist2 == null)
            {
                dentist2 = new ApplicationUser
                {
                    UserName = dentist2Email,
                    Email = dentist2Email,
                    FullName = "Dr. Sarah Jenkins, DMD",
                    RoleName = "Dentist",
                    Specialization = "Cosmetic & Restorative Dentistry",
                    LicenseNumber = "DMD-NY-77312",
                    PhoneNumber = "+1 (555) 010-0005",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddYears(-3)
                };
                await userManager.CreateAsync(dentist2, "Dentist@123456");
                await userManager.AddToRoleAsync(dentist2, "Dentist");
            }

            var dentist3Email = "dr.david@dentalclinic.com";
            var dentist3 = await userManager.FindByEmailAsync(dentist3Email);
            if (dentist3 == null)
            {
                dentist3 = new ApplicationUser
                {
                    UserName = dentist3Email,
                    Email = dentist3Email,
                    FullName = "Dr. David Miller, DDS",
                    RoleName = "Dentist",
                    Specialization = "Endodontics & Oral Surgery",
                    LicenseNumber = "DDS-NY-91204",
                    PhoneNumber = "+1 (555) 010-0006",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddYears(-2)
                };
                await userManager.CreateAsync(dentist3, "Dentist@123456");
                await userManager.AddToRoleAsync(dentist3, "Dentist");
            }

            // Tenant Accounts (Tenant A, Tenant B, Tenant C)
            var tenantAEmail = "tenanta@dentalclinic.com";
            var tenantA = await userManager.FindByEmailAsync(tenantAEmail);
            if (tenantA == null)
            {
                tenantA = new ApplicationUser
                {
                    UserName = tenantAEmail,
                    Email = tenantAEmail,
                    FullName = "Tenant A Client (City Dental Center)",
                    RoleName = "TenantA",
                    PhoneNumber = "+1 (555) 019-1001",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddMonths(-10)
                };
                await userManager.CreateAsync(tenantA, "Tenant@123456");
                await userManager.AddToRoleAsync(tenantA, "TenantA");
            }

            var tenantBEmail = "tenantb@dentalclinic.com";
            var tenantB = await userManager.FindByEmailAsync(tenantBEmail);
            if (tenantB == null)
            {
                tenantB = new ApplicationUser
                {
                    UserName = tenantBEmail,
                    Email = tenantBEmail,
                    FullName = "Tenant B Client (Smiles & Ortho Clinic)",
                    RoleName = "TenantB",
                    PhoneNumber = "+1 (555) 019-1002",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddMonths(-8)
                };
                await userManager.CreateAsync(tenantB, "Tenant@123456");
                await userManager.AddToRoleAsync(tenantB, "TenantB");
            }

            var tenantCEmail = "tenantc@dentalclinic.com";
            var tenantC = await userManager.FindByEmailAsync(tenantCEmail);
            if (tenantC == null)
            {
                tenantC = new ApplicationUser
                {
                    UserName = tenantCEmail,
                    Email = tenantCEmail,
                    FullName = "Tenant C Client (Metro Dental Enterprise Network)",
                    RoleName = "TenantC",
                    PhoneNumber = "+1 (555) 019-1003",
                    EmailConfirmed = true,
                    IsActive = true,
                    HireDate = DateTime.UtcNow.AddMonths(-6)
                };
                await userManager.CreateAsync(tenantC, "Tenant@123456");
                await userManager.AddToRoleAsync(tenantC, "TenantC");
            }

            // 3. Seed Dental Services
            if (!await context.DentalServices.AnyAsync())
            {
                var services = new List<DentalService>
                {
                    new DentalService { ServiceCode = "DNT-EXAM", Name = "Comprehensive Oral Exam & Digital X-Rays", Category = "Preventive", Description = "Full mouth radiographic and visual examination, periodontal probing, and cancer screening.", StandardPrice = 85.00m, EstimatedDurationMinutes = 30 },
                    new DentalService { ServiceCode = "DNT-CLN", Name = "Adult Dental Prophylaxis (Cleaning)", Category = "Preventive", Description = "Removal of dental plaque and tartar, ultrasonic scaling and surface stain polishing.", StandardPrice = 120.00m, EstimatedDurationMinutes = 45 },
                    new DentalService { ServiceCode = "DNT-SRP", Name = "Deep Scaling & Root Planing (Per Quad)", Category = "Periodontics", Description = "Therapeutic subgingival root debridement for periodontal gum disease management.", StandardPrice = 220.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-FL1", Name = "Composite Resin Filling (1-Surface)", Category = "Restorative", Description = "Tooth-colored direct bonded composite restoration for cavities or minor fractures.", StandardPrice = 150.00m, EstimatedDurationMinutes = 40 },
                    new DentalService { ServiceCode = "DNT-FL2", Name = "Composite Resin Filling (Multi-Surface)", Category = "Restorative", Description = "Multi-surface aesthetic composite restoration with anatomical contouring.", StandardPrice = 210.00m, EstimatedDurationMinutes = 50 },
                    new DentalService { ServiceCode = "DNT-RCT", Name = "Root Canal Therapy (Molar/Premolar)", Category = "Endodontics", Description = "Endodontic extirpation, mechanical instrumentation, disinfectant irrigation and warm gutta-percha obturation.", StandardPrice = 820.00m, EstimatedDurationMinutes = 90 },
                    new DentalService { ServiceCode = "DNT-CRW", Name = "Full Porcelain / Zirconia Crown", Category = "Restorative", Description = "High-strength monolithic zirconia or lithium disilicate porcelain crown restoration.", StandardPrice = 950.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-EXT", Name = "Simple Tooth Extraction", Category = "Surgery", Description = "Uncomplicated surgical removal of non-restorable tooth under local anesthesia.", StandardPrice = 160.00m, EstimatedDurationMinutes = 35 },
                    new DentalService { ServiceCode = "DNT-WIS", Name = "Impacted Wisdom Tooth Surgical Removal", Category = "Surgery", Description = "Surgical extraction of bony impacted third molar with osteotomy and suturing.", StandardPrice = 480.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-WHT", Name = "In-Office Laser Teeth Whitening", Category = "Cosmetic", Description = "Power bleaching using hydrogen peroxide activated by blue LED light for up to 8 shades brighter.", StandardPrice = 380.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-VNR", Name = "Porcelain Cosmetic Veneer", Category = "Cosmetic", Description = "Custom laboratory fabricated porcelain veneer for cosmetic smile enhancement.", StandardPrice = 850.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-IMP", Name = "Titanium Dental Implant Placement", Category = "Surgery", Description = "Surgical osteotomy and precision insertion of biocompatible titanium implant fixture.", StandardPrice = 1750.00m, EstimatedDurationMinutes = 90 },
                    new DentalService { ServiceCode = "DNT-ORT", Name = "Orthodontic Clear Aligner Initial Setup", Category = "Orthodontics", Description = "Digital 3D intraoral scanning, simulation treatment plan and first aligner set fitting.", StandardPrice = 1200.00m, EstimatedDurationMinutes = 60 },
                    new DentalService { ServiceCode = "DNT-GRD", Name = "Custom Night Guard / Bruxism Appliance", Category = "General", Description = "Dual-laminate customized occlusal splint for protection against nocturnal grinding.", StandardPrice = 320.00m, EstimatedDurationMinutes = 30 }
                };
                await context.DentalServices.AddRangeAsync(services);
                await context.SaveChangesAsync();
            }

            // 4. Seed Promotions
            if (!await context.Promotions.AnyAsync())
            {
                var promotions = new List<Promotion>
                {
                    new Promotion { PromoCode = "WELCOME20", Title = "20% New Patient Discount", Description = "20% off comprehensive exam and cleaning for first-time visitors.", DiscountType = DiscountType.Percentage, DiscountValue = 20, StartDate = DateTime.UtcNow.AddMonths(-6), EndDate = DateTime.UtcNow.AddMonths(6), MinSpend = 100 },
                    new Promotion { PromoCode = "WHITEN50", Title = "$50 Off Laser Whitening", Description = "Save $50 on in-office laser cosmetic teeth whitening.", DiscountType = DiscountType.FixedAmount, DiscountValue = 50, StartDate = DateTime.UtcNow.AddMonths(-4), EndDate = DateTime.UtcNow.AddMonths(4), MinSpend = 300 },
                    new Promotion { PromoCode = "SMILE15", Title = "15% Family Dental Care", Description = "15% discount for family preventative appointments.", DiscountType = DiscountType.Percentage, DiscountValue = 15, StartDate = DateTime.UtcNow.AddMonths(-3), EndDate = DateTime.UtcNow.AddMonths(5), MinSpend = 200 },
                    new Promotion { PromoCode = "IMPLANT100", Title = "$100 Off Dental Implant", Description = "Instant $100 deduction on surgical implant placements.", DiscountType = DiscountType.FixedAmount, DiscountValue = 100, StartDate = DateTime.UtcNow.AddMonths(-5), EndDate = DateTime.UtcNow.AddMonths(3), MinSpend = 1000 },
                    new Promotion { PromoCode = "SENIOR10", Title = "10% Senior Smiles Discount", Description = "10% reduction for patient treatments aged 60 and older.", DiscountType = DiscountType.Percentage, DiscountValue = 10, StartDate = DateTime.UtcNow.AddMonths(-12), EndDate = DateTime.UtcNow.AddYears(1), MinSpend = 50 }
                };
                await context.Promotions.AddRangeAsync(promotions);
                await context.SaveChangesAsync();
            }

            // 5. Seed Patients (60 distinct realistic patients)
            if (!await context.Patients.AnyAsync())
            {
                var patientsList = new List<Patient>();
                var firstNames = new[] { "Michael", "Emily", "James", "Sophia", "William", "Olivia", "Benjamin", "Emma", "Lucas", "Ava",
                                         "Henry", "Mia", "Alexander", "Isabella", "Daniel", "Charlotte", "Matthew", "Amelia", "Ethan", "Harper",
                                         "David", "Evelyn", "Joseph", "Abigail", "Samuel", "Emily", "Sebastian", "Elizabeth", "Gabriel", "Sofia",
                                         "Carter", "Avery", "Jayden", "Ella", "John", "Scarlett", "Owen", "Grace", "Dylan", "Chloe",
                                         "Luke", "Camila", "Anthony", "Penelope", "Isaac", "Riley", "Oliver", "Layla", "Jack", "Lillian",
                                         "Julian", "Nora", "Levi", "Zoey", "Christopher", "Mila", "Joshua", "Aubrey", "Andrew", "Hannah" };

                var lastNames = new[] { "Johnson", "Smith", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
                                        "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
                                        "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson" };

                var allergiesList = new[] { "None", "None", "None", "Penicillin", "Latex", "Local Anesthetic", "Sulfa drugs", "Aspirin", "Codeine", "None" };
                var bloodTypes = new[] { "O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-" };
                var medicalNotes = new[] { "No significant medical issues reported.", "Mild seasonal allergies. Non-smoker.", "Controlled hypertension on ACE inhibitors.", "Type 2 Diabetes Mellitus (HbA1c 6.8).", "Asthma (uses Albuterol inhaler prn).", "Mitral valve prolapse (no premedication required).", "Taking baby aspirin 81mg daily.", "History of dental anxiety." };

                var rnd = new Random(42);

                for (int i = 0; i < 60; i++)
                {
                    var fn = firstNames[i % firstNames.Length];
                    var ln = lastNames[i % lastNames.Length];
                    var gender = (i % 2 == 0) ? "Male" : "Female";
                    var age = rnd.Next(18, 72);
                    var dob = DateTime.UtcNow.AddYears(-age).AddDays(-rnd.Next(1, 365));
                    var phone = $"+1 (555) {rnd.Next(200, 999):D3}-{rnd.Next(1000, 9999):D4}";
                    var email = $"{fn.ToLower()}.{ln.ToLower()}{rnd.Next(10, 99)}@gmail.com";

                    patientsList.Add(new Patient
                    {
                        PatientCode = $"PAT-{1000 + i + 1}",
                        FirstName = fn,
                        LastName = ln,
                        Gender = gender,
                        DateOfBirth = dob,
                        Phone = phone,
                        Email = email,
                        Address = $"{rnd.Next(100, 9999)} Pine Crest Blvd, Suite {rnd.Next(1, 40)}, New York, NY",
                        EmergencyContact = $"{ln} Family - {phone}",
                        BloodType = bloodTypes[rnd.Next(bloodTypes.Length)],
                        Allergies = allergiesList[rnd.Next(allergiesList.Length)],
                        MedicalHistoryNotes = medicalNotes[rnd.Next(medicalNotes.Length)],
                        CreatedAt = DateTime.UtcNow.AddMonths(-rnd.Next(4, 18)),
                        IsActive = true
                    });
                }

                await context.Patients.AddRangeAsync(patientsList);
                await context.SaveChangesAsync();
            }

            // 6. Seed >200 Transactions (Appointments, Treatments, Billing Invoices, Payments, Reminders)
            if (!await context.Appointments.AnyAsync())
            {
                var allPatients = await context.Patients.ToListAsync();
                var allServices = await context.DentalServices.ToListAsync();
                var allDentists = new[] { dentist1, dentist2, dentist3 };
                var allPromotions = await context.Promotions.ToListAsync();

                var rnd = new Random(101);
                var teethPool = new[] { "Tooth #3 (Maxillary Molar)", "Tooth #8 (Central Incisor)", "Tooth #9 (Central Incisor)",
                                        "Tooth #14 (Maxillary Molar)", "Tooth #19 (Mandibular 1st Molar)", "Tooth #30 (Mandibular 1st Molar)",
                                        "Tooth #18 (Mandibular 2nd Molar)", "Tooth #31 (Mandibular 2nd Molar)", "Tooth #4 (Premolar)",
                                        "Tooth #12 (Premolar)", "Upper Arch (Quadrant 1-2)", "Lower Arch (Quadrant 3-4)", "Full Dentition" };

                var diagnoses = new[] {
                    "Dental caries with dentin involvement.",
                    "Symptomatic irreversible pulpitis.",
                    "Moderate chronic generalized periodontitis.",
                    "Enamel wear and localized extrinsic staining.",
                    "Chipped incisal edge due to masticatory trauma.",
                    "Impacted lower third molar with recurrent pericoronitis.",
                    "Defective amalgam restoration with recurrent microleakage.",
                    "Severe tooth discoloration requiring laser whitening.",
                    "Missing lower first molar, indicated for implant placement.",
                    "Nocturnal bruxism with secondary temporomandibular joint tension."
                };

                var procedures = new[] {
                    "Administered 2% Lidocaine with 1:100k epi. Excavated decayed tissue, placed composite bonded restoration, cured and polished occlusion.",
                    "Completed full mouth scaling and ultrasonic root debridement. Subgingival irrigation with chlorhexidine 0.12%. Patient tolerated well.",
                    "Root canal biomechanical preparation completed under rubber dam isolation. Irrigated with NaOCl, obturated with gutta-percha and AH Plus sealer.",
                    "Tooth prepped for full zirconia crown. Dual-arch polyvinyl siloxane impression taken, temporary acrylic crown cemented with temp-bond.",
                    "Surgical atraumatic extraction performed. Hemostasis achieved using surgical gauze and gel foam. Post-op instructions given.",
                    "In-office blue LED laser whitening applied in three 15-minute cycles. Final shade recorded at B1.",
                    "Implant osteotomy prepared under copious saline cooling. 4.3 x 11.5mm titanium fixture torqued to 35 Ncm. Cover screw placed.",
                    "Comprehensive examination, bitewing x-rays evaluated, oral hygiene index calculated. Prophylaxis polishing completed."
                };

                var prescriptions = new[] {
                    "Amoxicillin 500mg - Take 1 capsule three times daily for 7 days.",
                    "Ibuprofen 600mg - Take 1 tablet every 6 hours as needed for discomfort.",
                    "Chlorhexidine Gluconate 0.12% Oral Rinse - Swish 15ml twice daily after brushing.",
                    "Acetaminophen 500mg - Take 1-2 tablets every 6 hours as needed for mild pain.",
                    "Clindamycin 300mg - Take 1 capsule four times daily for 7 days (Penicillin allergic).",
                    "None required. Routine post-operative oral hygiene recommended."
                };

                int appointmentCounter = 1;
                int treatmentCounter = 1;
                int invoiceCounter = 1;
                int paymentCounter = 1;

                var appointmentsList = new List<Appointment>();
                var remindersList = new List<AppointmentReminder>();
                var treatmentsList = new List<TreatmentRecord>();
                var invoicesList = new List<BillingInvoice>();
                var invoiceItemsList = new List<InvoiceItem>();
                var paymentsList = new List<Payment>();

                // Generate 220 Historical Completed/Active Transactions over past 8 months
                for (int i = 0; i < 220; i++)
                {
                    var patient = allPatients[rnd.Next(allPatients.Count)];
                    var dentist = allDentists[rnd.Next(allDentists.Length)];
                    var service = allServices[rnd.Next(allServices.Count)];

                    // Past dates spread across past 240 days
                    var daysAgo = rnd.Next(2, 240);
                    var aptDate = DateTime.UtcNow.Date.AddDays(-daysAgo);
                    var hour = rnd.Next(8, 16);
                    var startTime = new TimeSpan(hour, (rnd.Next(0, 2) * 30), 0);
                    var endTime = startTime.Add(TimeSpan.FromMinutes(service.EstimatedDurationMinutes));

                    var appointment = new Appointment
                    {
                        AppointmentNumber = $"APT-2024-{appointmentCounter:D4}",
                        PatientId = patient.Id,
                        DentistId = dentist.Id,
                        ServiceId = service.Id,
                        AppointmentDate = aptDate,
                        StartTime = startTime,
                        EndTime = endTime,
                        Status = AppointmentStatus.Completed,
                        ReasonForVisit = $"Scheduled {service.Name}",
                        Notes = "Patient arrived on time, completed clinical procedure.",
                        ReminderSent = true,
                        ReminderSentAt = aptDate.AddDays(-1).AddHours(10),
                        CreatedAt = aptDate.AddDays(-rnd.Next(3, 14))
                    };
                    appointmentsList.Add(appointment);

                    // Add Reminder for this appointment
                    remindersList.Add(new AppointmentReminder
                    {
                        Appointment = appointment,
                        PatientId = patient.Id,
                        Channel = (i % 3 == 0) ? ReminderChannel.SMS : ((i % 3 == 1) ? ReminderChannel.Email : ReminderChannel.WhatsApp),
                        RecipientContact = (i % 3 == 1 && !string.IsNullOrEmpty(patient.Email)) ? patient.Email : patient.Phone,
                        MessageContent = $"Reminder: Your dental appointment with {dentist.FullName} for {service.Name} is confirmed for {aptDate:MM/dd/yyyy} at {startTime:hh\\:mm}.",
                        ScheduledTime = aptDate.AddDays(-1).AddHours(9),
                        SentTime = aptDate.AddDays(-1).AddHours(9).AddMinutes(5),
                        Status = ReminderStatus.Delivered,
                        DeliveryNote = "Delivered successfully"
                    });

                    // Add Treatment Record for this completed appointment
                    var treatment = new TreatmentRecord
                    {
                        RecordNumber = $"TRT-2024-{treatmentCounter:D4}",
                        PatientId = patient.Id,
                        DentistId = dentist.Id,
                        Appointment = appointment,
                        ServiceId = service.Id,
                        TreatmentDate = aptDate,
                        ToothNumber = teethPool[rnd.Next(teethPool.Length)],
                        Diagnosis = diagnoses[rnd.Next(diagnoses.Length)],
                        ProcedureNotes = procedures[rnd.Next(procedures.Length)],
                        Prescriptions = prescriptions[rnd.Next(prescriptions.Length)],
                        NextFollowUpDate = aptDate.AddMonths(rnd.Next(3, 6)),
                        Cost = service.StandardPrice,
                        CreatedAt = aptDate.AddHours(hour + 1)
                    };
                    treatmentsList.Add(treatment);

                    // Add Billing Invoice
                    decimal subTotal = service.StandardPrice;
                    decimal discount = 0;
                    Promotion? promo = null;

                    // Some transactions use promotions
                    if (i % 4 == 0)
                    {
                        promo = allPromotions[rnd.Next(allPromotions.Count)];
                        if (subTotal >= promo.MinSpend)
                        {
                            discount = promo.DiscountType == DiscountType.Percentage
                                ? Math.Round(subTotal * (promo.DiscountValue / 100m), 2)
                                : promo.DiscountValue;
                        }
                    }

                    decimal tax = Math.Round((subTotal - discount) * 0.05m, 2); // 5% clinic tax
                    decimal totalAmount = Math.Max(0, (subTotal - discount) + tax);

                    // Most past invoices are fully paid, a few are partial/unpaid for realistic BI reporting
                    decimal paidAmount = totalAmount;
                    InvoiceStatus status = InvoiceStatus.Paid;

                    if (i % 18 == 0)
                    {
                        paidAmount = Math.Round(totalAmount * 0.5m, 2);
                        status = InvoiceStatus.PartiallyPaid;
                    }
                    else if (i % 30 == 0)
                    {
                        paidAmount = 0;
                        status = InvoiceStatus.Unpaid;
                    }

                    var invoice = new BillingInvoice
                    {
                        InvoiceNumber = $"INV-2024-{invoiceCounter:D4}",
                        PatientId = patient.Id,
                        Appointment = appointment,
                        TreatmentRecord = treatment,
                        InvoiceDate = aptDate,
                        DueDate = aptDate.AddDays(7),
                        SubTotal = subTotal,
                        Promotion = promo,
                        DiscountAmount = discount,
                        TaxAmount = tax,
                        TotalAmount = totalAmount,
                        AmountPaid = paidAmount,
                        BalanceDue = totalAmount - paidAmount,
                        Status = status,
                        Notes = promo != null ? $"Applied promotion: {promo.PromoCode}" : "Standard dental billing",
                        CreatedAt = aptDate.AddHours(hour + 1)
                    };
                    invoicesList.Add(invoice);

                    // Add Invoice line item
                    invoiceItemsList.Add(new InvoiceItem
                    {
                        Invoice = invoice,
                        ServiceId = service.Id,
                        Description = service.Name,
                        UnitPrice = service.StandardPrice,
                        Quantity = 1,
                        LineTotal = service.StandardPrice
                    });

                    // Add Payment record if paid
                    if (paidAmount > 0)
                    {
                        var methods = new[] { PaymentMethod.CreditCard, PaymentMethod.Cash, PaymentMethod.GCash, PaymentMethod.Insurance, PaymentMethod.DebitCard };
                        paymentsList.Add(new Payment
                        {
                            PaymentReference = $"PAY-2024-{paymentCounter:D4}",
                            Invoice = invoice,
                            PaymentDate = aptDate.AddHours(hour + 1).AddMinutes(15),
                            Amount = paidAmount,
                            Method = methods[rnd.Next(methods.Length)],
                            TransactionReference = $"TXN-{rnd.Next(100000, 999999)}",
                            Notes = "Payment cleared at front desk",
                            ReceivedByUserId = staffUser.Id
                        });
                        paymentCounter++;
                    }

                    appointmentCounter++;
                    treatmentCounter++;
                    invoiceCounter++;
                }

                // Add 30 Current & Upcoming appointments (Today & Future 14 days)
                for (int j = 0; j < 30; j++)
                {
                    var patient = allPatients[rnd.Next(allPatients.Count)];
                    var dentist = allDentists[rnd.Next(allDentists.Length)];
                    var service = allServices[rnd.Next(allServices.Count)];

                    var dayOffset = rnd.Next(0, 14); // 0 = today, up to 14 days in future
                    var aptDate = DateTime.UtcNow.Date.AddDays(dayOffset);
                    var hour = rnd.Next(8, 17);
                    var startTime = new TimeSpan(hour, (rnd.Next(0, 2) * 30), 0);
                    var endTime = startTime.Add(TimeSpan.FromMinutes(service.EstimatedDurationMinutes));

                    var aptStatus = (dayOffset == 0 && j % 3 == 0)
                        ? AppointmentStatus.InProgress
                        : (j % 5 == 0 ? AppointmentStatus.Confirmed : AppointmentStatus.Scheduled);

                    var futureApt = new Appointment
                    {
                        AppointmentNumber = $"APT-2024-{appointmentCounter:D4}",
                        PatientId = patient.Id,
                        DentistId = dentist.Id,
                        ServiceId = service.Id,
                        AppointmentDate = aptDate,
                        StartTime = startTime,
                        EndTime = endTime,
                        Status = aptStatus,
                        ReasonForVisit = $"Scheduled {service.Name}",
                        Notes = "Upcoming dental appointment",
                        ReminderSent = (dayOffset <= 1),
                        ReminderSentAt = (dayOffset <= 1) ? DateTime.UtcNow.AddHours(-2) : null,
                        CreatedAt = DateTime.UtcNow.AddDays(-rnd.Next(1, 5))
                    };
                    appointmentsList.Add(futureApt);

                    if (dayOffset <= 1)
                    {
                        remindersList.Add(new AppointmentReminder
                        {
                            Appointment = futureApt,
                            PatientId = patient.Id,
                            Channel = ReminderChannel.SMS,
                            RecipientContact = patient.Phone,
                            MessageContent = $"Hi {patient.FirstName}, your dental visit with {dentist.FullName} is scheduled on {aptDate:MMM dd} at {startTime:hh\\:mm}. Please arrive 10 min early.",
                            ScheduledTime = DateTime.UtcNow.AddHours(-2),
                            SentTime = DateTime.UtcNow.AddHours(-2),
                            Status = ReminderStatus.Sent,
                            DeliveryNote = "SMS sent to carrier"
                        });
                    }

                    appointmentCounter++;
                }

                // Add 15 Cancelled or No-Show appointments for realistic KPI rates
                for (int k = 0; k < 15; k++)
                {
                    var patient = allPatients[rnd.Next(allPatients.Count)];
                    var dentist = allDentists[rnd.Next(allDentists.Length)];
                    var service = allServices[rnd.Next(allServices.Count)];
                    var daysAgo = rnd.Next(3, 90);
                    var aptDate = DateTime.UtcNow.Date.AddDays(-daysAgo);

                    var aptStatus = (k % 2 == 0) ? AppointmentStatus.Cancelled : AppointmentStatus.NoShow;
                    appointmentsList.Add(new Appointment
                    {
                        AppointmentNumber = $"APT-2024-{appointmentCounter:D4}",
                        PatientId = patient.Id,
                        DentistId = dentist.Id,
                        ServiceId = service.Id,
                        AppointmentDate = aptDate,
                        StartTime = new TimeSpan(10, 0, 0),
                        EndTime = new TimeSpan(11, 0, 0),
                        Status = aptStatus,
                        ReasonForVisit = $"Consultation - {service.Name}",
                        Notes = aptStatus == AppointmentStatus.Cancelled ? "Patient called to cancel due to schedule conflict." : "Patient failed to attend scheduled slot.",
                        ReminderSent = true,
                        ReminderSentAt = aptDate.AddDays(-1),
                        CreatedAt = aptDate.AddDays(-5)
                    });
                    appointmentCounter++;
                }

                // Save all generated records
                await context.Appointments.AddRangeAsync(appointmentsList);
                await context.AppointmentReminders.AddRangeAsync(remindersList);
                await context.TreatmentRecords.AddRangeAsync(treatmentsList);
                await context.BillingInvoices.AddRangeAsync(invoicesList);
                await context.InvoiceItems.AddRangeAsync(invoiceItemsList);
                await context.Payments.AddRangeAsync(paymentsList);

                // Add System Audit Logs
                var auditLogs = new List<AuditLog>
                {
                    new AuditLog { UserName = superAdminEmail, Action = "DatabaseSeed", Module = "System", Details = "Initialized dental clinic database with clinical services, roles, and 200+ transactional seed records.", Timestamp = DateTime.UtcNow.AddHours(-1) },
                    new AuditLog { UserName = adminEmail, Action = "ConfigUpdate", Module = "Promotions", Details = "Verified seasonal promotion campaigns and service price schedules.", Timestamp = DateTime.UtcNow.AddHours(-1) },
                    new AuditLog { UserName = staffEmail, Action = "BatchReminder", Module = "Appointments", Details = "Triggered scheduled reminder notifications to upcoming patients.", Timestamp = DateTime.UtcNow.AddMinutes(-30) }
                };
                await context.AuditLogs.AddRangeAsync(auditLogs);

                await context.SaveChangesAsync();
            }

            // 7. Seed Tenants (Tenant A, Tenant B, Tenant C)
            if (!await context.Tenants.AnyAsync())
            {
                var tenants = new List<Tenant>
                {
                    new Tenant
                    {
                        TenantCode = "TNT-A001",
                        TenantName = "Tenant A - City Care Dental Clinic",
                        SubscriptionTier = "Tenant A",
                        ContactEmail = "tenanta@dentalclinic.com",
                        ContactPhone = "+1 (555) 019-1001",
                        Address = "101 Downtown Plaza, Suite 300, New York, NY",
                        Status = "Active",
                        BranchesCount = 1,
                        ActiveUsersCount = 4,
                        CreatedAt = DateTime.UtcNow.AddMonths(-10)
                    },
                    new Tenant
                    {
                        TenantCode = "TNT-B002",
                        TenantName = "Tenant B - Smiles & Orthodontics Center",
                        SubscriptionTier = "Tenant B",
                        ContactEmail = "tenantb@dentalclinic.com",
                        ContactPhone = "+1 (555) 019-1002",
                        Address = "450 Broadway Ave, 2nd Floor, New York, NY",
                        Status = "Active",
                        BranchesCount = 2,
                        ActiveUsersCount = 8,
                        CreatedAt = DateTime.UtcNow.AddMonths(-8)
                    },
                    new Tenant
                    {
                        TenantCode = "TNT-C003",
                        TenantName = "Tenant C - Metro Premier Dental Network",
                        SubscriptionTier = "Tenant C",
                        ContactEmail = "tenantc@dentalclinic.com",
                        ContactPhone = "+1 (555) 019-1003",
                        Address = "800 Lexington Avenue, Tower 1, New York, NY",
                        Status = "Active",
                        BranchesCount = 4,
                        ActiveUsersCount = 25,
                        CreatedAt = DateTime.UtcNow.AddMonths(-6)
                    }
                };
                await context.Tenants.AddRangeAsync(tenants);
                await context.SaveChangesAsync();
            }

            // 8. Seed Tenant Subscriptions
            if (!await context.Subscriptions.AnyAsync())
            {
                var subs = new List<TenantSubscription>
                {
                    new TenantSubscription
                    {
                        TenantName = "Tenant A - City Care Dental Clinic",
                        SubscriptionTier = "Tenant A",
                        PlanName = "Tenant A: Core Transactions & Clinical Data",
                        MonthlyPrice = 4999.00m,
                        BillingCycle = "Monthly",
                        StartDate = DateTime.UtcNow.AddMonths(-10),
                        EndDate = DateTime.UtcNow.AddMonths(2),
                        Status = "Active",
                        ContactPhone = "+1 (555) 019-1001",
                        ContactEmail = "tenanta@dentalclinic.com",
                        LastInformedDate = DateTime.UtcNow.AddDays(-5),
                        LastNotificationStatus = "Dispatched via Phone SMS",
                        AllowedModulesSummary = "Main transaction, Data Collection"
                    },
                    new TenantSubscription
                    {
                        TenantName = "Tenant B - Smiles & Orthodontics Center",
                        SubscriptionTier = "Tenant B",
                        PlanName = "Tenant B: Business Intelligence & Actions",
                        MonthlyPrice = 8999.00m,
                        BillingCycle = "Monthly",
                        StartDate = DateTime.UtcNow.AddMonths(-8),
                        EndDate = DateTime.UtcNow.AddMonths(4),
                        Status = "Active",
                        ContactPhone = "+1 (555) 019-1002",
                        ContactEmail = "tenantb@dentalclinic.com",
                        LastInformedDate = DateTime.UtcNow.AddDays(-2),
                        LastNotificationStatus = "Dispatched via Email",
                        AllowedModulesSummary = "Business Intelligence, Actions"
                    },
                    new TenantSubscription
                    {
                        TenantName = "Tenant C - Metro Premier Dental Network",
                        SubscriptionTier = "Tenant C",
                        PlanName = "Tenant C: Enterprise Multi-Branching & BI",
                        MonthlyPrice = 14999.00m,
                        BillingCycle = "Monthly",
                        StartDate = DateTime.UtcNow.AddMonths(-6),
                        EndDate = DateTime.UtcNow.AddMonths(6),
                        Status = "Active",
                        ContactPhone = "+1 (555) 019-1003",
                        ContactEmail = "tenantc@dentalclinic.com",
                        LastInformedDate = DateTime.UtcNow.AddDays(-1),
                        LastNotificationStatus = "Dispatched via Phone SMS & Email",
                        AllowedModulesSummary = "Branching, Business Intelligence, Actions"
                    }
                };
                await context.Subscriptions.AddRangeAsync(subs);
                await context.SaveChangesAsync();
            }

            // 9. Seed Clinic Branches (Tenant C Multi-Branching)
            if (!await context.Branches.AnyAsync())
            {
                var branches = new List<ClinicBranch>
                {
                    new ClinicBranch
                    {
                        BranchCode = "BRN-NYC-01",
                        BranchName = "Metro Premier - Manhattan Flagship Clinic",
                        CityLocation = "Manhattan, NY",
                        Address = "800 Lexington Ave, Suites 401-408",
                        PhoneNumber = "+1 (555) 018-7711",
                        Email = "manhattan@metropremier.com",
                        HeadDentistOrManager = "Dr. Alexander Smith, DDS",
                        DentalChairsCount = 8,
                        MonthlyRevenue = 450000.00m,
                        IsActive = true,
                        AssignedTenantTier = "Tenant C"
                    },
                    new ClinicBranch
                    {
                        BranchCode = "BRN-NYC-02",
                        BranchName = "Metro Premier - Brooklyn Heights Branch",
                        CityLocation = "Brooklyn, NY",
                        Address = "120 Montague Street, 3rd Floor",
                        PhoneNumber = "+1 (555) 018-7722",
                        Email = "brooklyn@metropremier.com",
                        HeadDentistOrManager = "Dr. Sarah Jenkins, DMD",
                        DentalChairsCount = 5,
                        MonthlyRevenue = 320000.00m,
                        IsActive = true,
                        AssignedTenantTier = "Tenant C"
                    },
                    new ClinicBranch
                    {
                        BranchCode = "BRN-NYC-03",
                        BranchName = "Metro Premier - Queens Pediatric & Family Center",
                        CityLocation = "Queens, NY",
                        Address = "70-20 Austin Street, Forest Hills",
                        PhoneNumber = "+1 (555) 018-7733",
                        Email = "queens@metropremier.com",
                        HeadDentistOrManager = "Dr. David Miller, DDS",
                        DentalChairsCount = 4,
                        MonthlyRevenue = 280000.00m,
                        IsActive = true,
                        AssignedTenantTier = "Tenant C"
                    },
                    new ClinicBranch
                    {
                        BranchCode = "BRN-NYC-04",
                        BranchName = "Metro Premier - Staten Island Express Care",
                        CityLocation = "Staten Island, NY",
                        Address = "260 Richmond Avenue",
                        PhoneNumber = "+1 (555) 018-7744",
                        Email = "statenisland@metropremier.com",
                        HeadDentistOrManager = "Dr. Elena Rostova",
                        DentalChairsCount = 3,
                        MonthlyRevenue = 230000.00m,
                        IsActive = true,
                        AssignedTenantTier = "Tenant C"
                    }
                };
                await context.Branches.AddRangeAsync(branches);
                await context.SaveChangesAsync();
            }

            // 10. Seed System Actions (Tenant B and Tenant C Actions)
            if (!await context.SystemActions.AnyAsync())
            {
                var actions = new List<SystemAction>
                {
                    new SystemAction
                    {
                        ActionTitle = "Clinical Implant Case Review & 3D CBCT Approval",
                        ActionCategory = "Clinical Task",
                        Priority = "Urgent",
                        Status = "Pending",
                        AssignedTo = "Dr. Alexander Smith, DDS",
                        RequestedBy = "Dr. Sarah Jenkins",
                        Description = "Evaluate mandibular bone density scan for Patient Michael Johnson prior to immediate load titanium fixture insertion.",
                        TargetTenantTier = "Tenant B / C",
                        DueDate = DateTime.UtcNow.AddDays(1),
                        CreatedAt = DateTime.UtcNow.AddHours(-8)
                    },
                    new SystemAction
                    {
                        ActionTitle = "Autoclave Sterilization Spore Test Compliance Audit",
                        ActionCategory = "Workflow Approval",
                        Priority = "High",
                        Status = "In Progress",
                        AssignedTo = "Jessica Sanchez (Staff)",
                        RequestedBy = "Elena Rostova (Clinic Director)",
                        Description = "Complete weekly biological spore test on all operatory autoclaves and log digital certification for state compliance.",
                        TargetTenantTier = "Tenant B / C",
                        DueDate = DateTime.UtcNow.AddDays(2),
                        CreatedAt = DateTime.UtcNow.AddHours(-14)
                    },
                    new SystemAction
                    {
                        ActionTitle = "Composite Resin & Anesthetic Cartridge Reorder Approval",
                        ActionCategory = "Inventory Request",
                        Priority = "Normal",
                        Status = "Approved",
                        AssignedTo = "Elena Rostova",
                        RequestedBy = "Dr. David Miller",
                        Description = "Approve wholesale dental supply requisition order #ORD-4491 for 2% Lidocaine and Filtek Supreme composites.",
                        TargetTenantTier = "Tenant B / C",
                        DueDate = DateTime.UtcNow.AddDays(3),
                        CreatedAt = DateTime.UtcNow.AddDays(-1)
                    },
                    new SystemAction
                    {
                        ActionTitle = "Patient Post-Op Antibiotic Follow-Up Protocol",
                        ActionCategory = "Patient Care Followup",
                        Priority = "Normal",
                        Status = "Completed",
                        AssignedTo = "Jessica Sanchez (Staff)",
                        RequestedBy = "Dr. Alexander Smith",
                        Description = "Conduct 48-hour phone check-in with patient Sophia Williams after surgical wisdom tooth extraction.",
                        TargetTenantTier = "Tenant B / C",
                        DueDate = DateTime.UtcNow.AddDays(-1),
                        CreatedAt = DateTime.UtcNow.AddDays(-3)
                    }
                };
                await context.SystemActions.AddRangeAsync(actions);
                await context.SaveChangesAsync();
            }
        }
    }
}
