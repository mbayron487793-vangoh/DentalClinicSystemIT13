using DentalClinicSystem.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Patient> Patients { get; set; } = null!;
        public DbSet<DentalService> DentalServices { get; set; } = null!;
        public DbSet<Promotion> Promotions { get; set; } = null!;
        public DbSet<Appointment> Appointments { get; set; } = null!;
        public DbSet<AppointmentReminder> AppointmentReminders { get; set; } = null!;
        public DbSet<TreatmentRecord> TreatmentRecords { get; set; } = null!;
        public DbSet<BillingInvoice> BillingInvoices { get; set; } = null!;
        public DbSet<InvoiceItem> InvoiceItems { get; set; } = null!;
        public DbSet<Payment> Payments { get; set; } = null!;
        public DbSet<AuditLog> AuditLogs { get; set; } = null!;
        public DbSet<Tenant> Tenants { get; set; } = null!;
        public DbSet<TenantSubscription> Subscriptions { get; set; } = null!;
        public DbSet<ClinicBranch> Branches { get; set; } = null!;
        public DbSet<SystemAction> SystemActions { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.ConfigureWarnings(w => w.Ignore(Microsoft.EntityFrameworkCore.Diagnostics.RelationalEventId.PendingModelChangesWarning));
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Appointment Relationships
            builder.Entity<Appointment>()
                .HasOne(a => a.Patient)
                .WithMany(p => p.Appointments)
                .HasForeignKey(a => a.PatientId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Appointment>()
                .HasOne(a => a.Dentist)
                .WithMany(u => u.DentistAppointments)
                .HasForeignKey(a => a.DentistId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Appointment>()
                .HasOne(a => a.DentalService)
                .WithMany(s => s.Appointments)
                .HasForeignKey(a => a.ServiceId)
                .OnDelete(DeleteBehavior.Restrict);

            // TreatmentRecord Relationships
            builder.Entity<TreatmentRecord>()
                .HasOne(t => t.Patient)
                .WithMany(p => p.TreatmentRecords)
                .HasForeignKey(t => t.PatientId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<TreatmentRecord>()
                .HasOne(t => t.Dentist)
                .WithMany(u => u.DentistTreatments)
                .HasForeignKey(t => t.DentistId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<TreatmentRecord>()
                .HasOne(t => t.DentalService)
                .WithMany(s => s.TreatmentRecords)
                .HasForeignKey(t => t.ServiceId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<TreatmentRecord>()
                .HasOne(t => t.Appointment)
                .WithOne(a => a.TreatmentRecord)
                .HasForeignKey<TreatmentRecord>(t => t.AppointmentId)
                .OnDelete(DeleteBehavior.SetNull);

            // BillingInvoice Relationships
            builder.Entity<BillingInvoice>()
                .HasOne(b => b.Patient)
                .WithMany(p => p.BillingInvoices)
                .HasForeignKey(b => b.PatientId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<BillingInvoice>()
                .HasOne(b => b.Appointment)
                .WithOne(a => a.BillingInvoice)
                .HasForeignKey<BillingInvoice>(b => b.AppointmentId)
                .OnDelete(DeleteBehavior.SetNull);

            builder.Entity<BillingInvoice>()
                .HasOne(b => b.TreatmentRecord)
                .WithOne(t => t.BillingInvoice)
                .HasForeignKey<BillingInvoice>(b => b.TreatmentRecordId)
                .OnDelete(DeleteBehavior.SetNull);

            builder.Entity<BillingInvoice>()
                .HasOne(b => b.Promotion)
                .WithMany(p => p.AppliedInvoices)
                .HasForeignKey(b => b.PromotionId)
                .OnDelete(DeleteBehavior.SetNull);

            // InvoiceItem Relationships
            builder.Entity<InvoiceItem>()
                .HasOne(i => i.Invoice)
                .WithMany(inv => inv.Items)
                .HasForeignKey(i => i.InvoiceId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<InvoiceItem>()
                .HasOne(i => i.DentalService)
                .WithMany(s => s.InvoiceItems)
                .HasForeignKey(i => i.ServiceId)
                .OnDelete(DeleteBehavior.SetNull);

            // Payment Relationships
            builder.Entity<Payment>()
                .HasOne(p => p.Invoice)
                .WithMany(inv => inv.Payments)
                .HasForeignKey(p => p.InvoiceId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Payment>()
                .HasOne(p => p.ReceivedByUser)
                .WithMany()
                .HasForeignKey(p => p.ReceivedByUserId)
                .OnDelete(DeleteBehavior.SetNull);

            // AppointmentReminder Relationships
            builder.Entity<AppointmentReminder>()
                .HasOne(r => r.Appointment)
                .WithMany(a => a.Reminders)
                .HasForeignKey(r => r.AppointmentId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<AppointmentReminder>()
                .HasOne(r => r.Patient)
                .WithMany()
                .HasForeignKey(r => r.PatientId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
